var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name4 in all)
    __defProp(target, name4, { get: all[name4], enumerable: true });
};

// server/purchasing.ts
import { z } from "zod";
var purchaseSchema;
var init_purchasing = __esm({
  "server/purchasing.ts"() {
    "use strict";
    purchaseSchema = z.object({ productId: z.uuid().nullable(), manufacturer: z.string().trim().max(200), partNumber: z.string().trim().max(200), noSubstitutions: z.boolean() }).strict().refine((v) => Boolean(v.manufacturer) === Boolean(v.partNumber), "Supply both manufacturer and part number.").refine((v) => !v.noSubstitutions || Boolean(v.manufacturer && v.partNumber), "No Substitutions requires manufacturer and part number.");
  }
});

// server/contracts.ts
import { z as z2 } from "zod";
var unit, text, date, quantity, candidate, line, mrfForm, draftBody, importRow, csvColumns, ApiError;
var init_contracts = __esm({
  "server/contracts.ts"() {
    "use strict";
    init_purchasing();
    unit = z2.enum(["EA", "FT", "STICK", "BOX", "ROLL", "PAIR"]);
    text = z2.string().trim().min(1).max(2e3);
    date = z2.iso.date();
    quantity = z2.string().regex(/^(?:\d{1,12}(?:\.\d{1,6})?|\.\d{1,6})$/).refine((value) => Number(value) > 0);
    candidate = z2.object({
      id: z2.string().max(100),
      description: text,
      specs: z2.array(z2.string().max(500)).max(30),
      verification: z2.enum(["provisional", "reviewed"]).optional(),
      productUnit: unit,
      source: z2.enum(["verified_fixture", "ai_fixture", "verified"]),
      category: z2.enum(["conduit", "screw", "tape", "general"])
    });
    line = z2.object({
      id: z2.uuid(),
      taskCode: z2.string().trim().max(16).optional(),
      quantity,
      requestedUnit: unit,
      description: text,
      rawInput: z2.object({ quantity, description: text, requestedUnit: unit }).strict(),
      candidate: candidate.nullable(),
      source: z2.enum(["verified_fixture", "ai_fixture", "user_description", "verified"]),
      purchasing: purchaseSchema.optional(),
      deliveryMode: z2.enum(["inherit", "override"]),
      overrideDate: date.nullable()
    }).strict().superRefine((value, context) => {
      if (value.deliveryMode === "inherit" !== (value.overrideDate === null)) context.addIssue({ code: "custom", message: "Inherited lines cannot have an override; overridden lines require a date." });
      if (value.source === "user_description" !== (value.candidate === null)) context.addIssue({ code: "custom", message: "Candidate/source mismatch." });
      if (value.candidate && value.source !== value.candidate.source) context.addIssue({ code: "custom", message: "Candidate/source mismatch." });
    });
    mrfForm = z2.object({ workArea: z2.string().trim().max(200), packagingMethod: z2.string().trim().min(1).max(200).default("Standard"), specialPackagingInstructions: z2.string().trim().max(2e3), defaultTaskCode: z2.string().trim().max(16), deliveryInstructions: z2.string().trim().max(2e3), purchasingNotes: z2.string().trim().max(2e3) }).strict();
    draftBody = z2.object({
      projectId: z2.string().regex(/^[a-zA-Z0-9._-]{1,64}$/),
      name: z2.string().trim().min(1).max(120).optional(),
      deliveryDate: date,
      foremanId: z2.string().trim().min(1).max(64).nullable().optional(),
      form: mrfForm.optional(),
      lines: z2.array(line).max(500),
      version: z2.number().int().nonnegative()
    }).strict().refine((value) => new Set(value.lines.map((item2) => item2.id)).size === value.lines.length, "Duplicate line identifiers");
    importRow = z2.object({
      schema_version: z2.literal("1"),
      external_key: z2.string().regex(/^[\w.-]{1,100}$/),
      description: text,
      aliases_json: z2.string().max(1e4),
      requested_uom: unit,
      product_uom: unit,
      manufacturer: z2.string().max(200),
      manufacturer_part_number: z2.string().max(200),
      specifications_json: z2.string().max(1e4),
      conversion_basis_json: z2.string().max(1e4),
      source_url: z2.string().max(2e3),
      verification_basis: text,
      dataset_kind: z2.enum(["fixture", "reviewed"])
    }).strict();
    csvColumns = Object.keys(importRow.shape);
    ApiError = class extends Error {
      constructor(status, message) {
        super(message);
        this.status = status;
      }
      status;
    };
  }
});

// server/image-assets.ts
var image_assets_exports = {};
__export(image_assets_exports, {
  BlobImageAssets: () => BlobImageAssets,
  FileImageAssets: () => FileImageAssets,
  imageHash: () => imageHash,
  imageKey: () => imageKey,
  normalizeImage: () => normalizeImage
});
import { createHash as createHash12 } from "node:crypto";
import { mkdir, readFile, writeFile, stat } from "node:fs/promises";
import { join } from "node:path";
import sharp from "sharp";
import { ContainerClient } from "@azure/storage-blob";
import { ManagedIdentityCredential } from "@azure/identity";
function imageKey(tenant, material, hash2) {
  if (!/^[\da-f-]{36}$/i.test(material) || !/^[\da-f]{64}$/.test(hash2)) throw new Error("Invalid image storage identifier.");
  return `${imageHash(Buffer.from(tenant))}/${material.toLowerCase()}/${hash2}.webp`;
}
function safeKey(key3) {
  if (!/^[\da-f]{64}\/[\da-f-]{36}\/[\da-f]{64}\.webp$/.test(key3)) throw new Error("Invalid image key.");
  return key3;
}
async function normalizeImage(bytes) {
  if (!bytes.length || bytes.length > 5 * 1024 * 1024) throw new ApiError(400, "Upload one image of at most 5 MB.");
  try {
    const decoder = sharp(bytes, { limitInputPixels: 16e6, failOn: "warning" });
    const metadata = await decoder.metadata();
    if (!["jpeg", "png", "webp"].includes(metadata.format ?? "") || (metadata.pages ?? 1) !== 1) throw new Error("Unsupported image");
    const normalized = await decoder.rotate().resize({ width: 1024, height: 1024, fit: "inside", withoutEnlargement: true }).webp({ quality: 85 }).toBuffer();
    if (normalized.length > 2 * 1024 * 1024) throw new Error("Normalized image too large");
    return { bytes: normalized, hash: imageHash(normalized) };
  } catch {
    throw new ApiError(400, "Use a valid, single-frame JPEG, PNG or WebP image up to 16 megapixels. SVG, animation and corrupt files are not accepted.");
  }
}
var imageHash, FileImageAssets, BlobImageAssets;
var init_image_assets = __esm({
  "server/image-assets.ts"() {
    "use strict";
    init_contracts();
    imageHash = (bytes) => createHash12("sha256").update(bytes).digest("hex");
    FileImageAssets = class {
      constructor(root2) {
        this.root = root2;
      }
      root;
      async put(key3, bytes) {
        const path = join(this.root, safeKey(key3));
        await mkdir(join(path, ".."), { recursive: true, mode: 448 });
        try {
          await writeFile(path, bytes, { flag: "wx", mode: 384 });
        } catch (error) {
          if (!(error && typeof error === "object" && "code" in error && error.code === "EEXIST")) throw error;
          if (imageHash(await readFile(path)) !== imageHash(bytes)) throw new Error("Existing image content mismatch.");
        }
      }
      async get(key3) {
        const path = join(this.root, safeKey(key3));
        if ((await stat(path)).size > 2 * 1024 * 1024) throw new Error("Stored image exceeds limit.");
        const bytes = await readFile(path);
        if (!key3.endsWith(`${imageHash(bytes)}.webp`)) throw new Error("Stored image checksum mismatch.");
        return bytes;
      }
    };
    BlobImageAssets = class {
      container;
      constructor(account, credential = new ManagedIdentityCredential()) {
        if (!/^[a-z0-9]{3,24}$/.test(account)) throw new Error("Explicit Azure storage account is required.");
        this.container = new ContainerClient(`https://${account}.blob.core.windows.net/catalog-images`, credential);
      }
      async put(key3, bytes) {
        const blob = this.container.getBlockBlobClient(safeKey(key3));
        try {
          await blob.uploadData(bytes, { conditions: { ifNoneMatch: "*" }, blobHTTPHeaders: { blobContentType: "image/webp" }, metadata: { sha256: imageHash(bytes) } });
        } catch (error) {
          if (!(error && typeof error === "object" && "statusCode" in error && [409, 412].includes(Number(error.statusCode)))) throw error;
          if (imageHash(await this.get(key3)) !== imageHash(bytes)) throw new Error("Existing blob checksum mismatch.");
        }
      }
      async get(key3) {
        const blob = this.container.getBlockBlobClient(safeKey(key3));
        const properties = await blob.getProperties();
        if (!properties.contentLength || properties.contentLength > 2 * 1024 * 1024) throw new Error("Stored image exceeds limit.");
        const bytes = await blob.downloadToBuffer();
        if (!key3.endsWith(`${imageHash(bytes)}.webp`)) throw new Error("Stored blob checksum mismatch.");
        return bytes;
      }
    };
  }
});

// scripts/publication-import/run.ts
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve, join as join2, dirname } from "node:path";
import { execFileSync } from "node:child_process";
import { createHash as createHash14, randomUUID as randomUUID16 } from "node:crypto";
import sql2 from "mssql";
import { AzureCliCredential } from "@azure/identity";
import { ContainerClient as ContainerClient2, StorageSharedKeyCredential } from "@azure/storage-blob";

// src/image-selection.ts
function selectImage(rows, productId) {
  const normalized = (value) => value ? String(value).toLowerCase() : null;
  const ordered = [...rows].sort((a, b) => String(b.reviewed_at ?? "").localeCompare(String(a.reviewed_at ?? "")) || String(a.id ?? "").localeCompare(String(b.id ?? "")));
  return (productId ? ordered.find((row2) => normalized(row2.product_id) === productId.toLowerCase()) : void 0) ?? ordered.find((row2) => !row2.product_id) ?? (!productId ? ordered[0] : void 0);
}

// server/site-accounts.ts
init_contracts();
import { createHash, randomBytes, randomUUID as randomUUID2, scrypt as rawScrypt, timingSafeEqual } from "node:crypto";
import { z as z4 } from "zod";

// server/workforce.ts
init_contracts();
import { randomUUID } from "node:crypto";
import { z as z3 } from "zod";
var jobRoles = ["CompanyAdmin", "Superintendent", "GeneralForeman", "Foreman"];
var id = z3.string().regex(/^[a-zA-Z0-9._-]{1,64}$/).transform((v) => v.toLowerCase());
var short = z3.string().trim().max(200);
var reason = z3.string().trim().min(10).max(2e3);
function* q(text4, ...values) {
  return yield { text: text4, values };
}
var details = (r) => JSON.parse(String(r.details || "{}"));
function* manager(p) {
  const root2 = p.roles.includes("Admin");
  const profile = (yield* q("SELECT * FROM user_profiles WHERE tenant=@p0 AND oid=@p1", p.tenant, p.oid))[0];
  if (!root2 && profile?.access_role !== "CompanyAdmin") throw new ApiError(403, "Company administrator access required.");
  return { root: root2, company: String(profile?.company_id ?? "main") };
}
function* seed(p) {
  if (!(yield* q("SELECT id FROM companies WHERE tenant=@p0 AND id=@p1", p.tenant, "main")).length) yield* q("INSERT INTO companies(tenant,id,name,active,details,version) VALUES(@p0,@p1,@p2,1,@p3,1)", p.tenant, "main", "My company", "{}");
  const assignments = yield* q("SELECT DISTINCT project FROM memberships WHERE tenant=@p0", p.tenant);
  for (const [job, name4, number3] of [["riverside", "Riverside Office Complex", "24-1187"], ["northside", "Northside Service Center", "24-1204"]]) if (assignments.some((a) => a.project === job) && !(yield* q("SELECT id FROM jobs WHERE tenant=@p0 AND id=@p1", p.tenant, job)).length) yield* q("INSERT INTO jobs(tenant,id,company_id,number,name,status,details,version) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,1)", p.tenant, job, "main", number3, name4, "active", JSON.stringify({ legacy: true }));
}
function* audit(p, target, before, after, why) {
  yield* q("INSERT INTO user_access_changes(id,tenant,oid,before_json,after_json,reason,actor,created_at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7)", randomUUID(), p.tenant, target, JSON.stringify(before ?? { registered: false }), JSON.stringify(after), why, p.oid, (/* @__PURE__ */ new Date()).toISOString());
}
function* scoped(p, company) {
  const m = yield* manager(p);
  if (!m.root && company !== m.company) throw new ApiError(404, "Company record not found.");
}
function* assignedJobs(p) {
  yield* seed(p);
  const rows = yield* q("SELECT j.*,m.job_role,m.supervisor_oid,m.top_level FROM jobs j JOIN memberships m ON m.tenant=j.tenant AND m.project=j.id JOIN companies c ON c.tenant=j.tenant AND c.id=j.company_id WHERE j.tenant=@p0 AND m.owner=@p1 AND j.status='active' AND c.active=1 ORDER BY j.name,j.id", p.tenant, p.oid);
  return { records: rows.map((r) => ({ id: r.id, name: r.name, number: r.number, details: details(r), companyId: r.company_id, role: r.job_role ?? "Foreman", supervisorId: r.supervisor_oid, topLevel: Boolean(r.top_level) })) };
}
function* workforce(p, action, data) {
  if (action === "assigned-jobs") return yield* assignedJobs(p);
  const m = yield* manager(p);
  yield* seed(p);
  if (action === "directory") {
    const companies = yield* q("SELECT * FROM companies WHERE tenant=@p0 ORDER BY name", p.tenant), jobs = yield* q("SELECT * FROM jobs WHERE tenant=@p0 ORDER BY name", p.tenant), users = yield* q("SELECT u.*,p.company_id,p.access_role,p.details,c.email,c.password_hash FROM application_users u LEFT JOIN user_profiles p ON p.tenant=u.tenant AND p.oid=u.oid LEFT JOIN site_credentials c ON c.tenant=u.tenant AND c.oid=u.oid WHERE u.tenant=@p0 ORDER BY u.display_name,u.oid", p.tenant), members = yield* q("SELECT * FROM memberships WHERE tenant=@p0", p.tenant);
    const visible = users.filter((u) => m.root || (u.company_id ?? "main") === m.company);
    return { root: m.root, companyId: m.company, companies: companies.filter((c) => m.root || c.id === m.company).map((c) => ({ ...c, active: Boolean(c.active), details: details(c) })), jobs: jobs.filter((j) => m.root || j.company_id === m.company).map((j) => ({ ...j, details: details(j) })), users: visible.map((u) => ({ oid: u.oid, displayName: u.display_name, active: Boolean(u.active), version: Number(u.version), companyId: u.company_id ?? "main", accessRole: u.entra_admin && u.role_limit !== "Foreman" ? "Admin" : u.access_role ?? "Member", details: { email: "", phone: "", title: "", employeeNumber: "", ...details(u) }, signIn: u.email ? "site" : "microsoft", email: u.email ?? details(u).email ?? "", status: !u.active ? "suspended" : u.email && !u.password_hash ? "invited" : "active", seenAt: u.seen_at, assignments: members.filter((a) => a.owner === u.oid).map((a) => ({ jobId: a.project, role: a.job_role ?? "Foreman", supervisorId: a.supervisor_oid ?? null, topLevel: Boolean(a.top_level) })) })) };
  }
  if (action === "company-save") {
    if (!m.root) throw new ApiError(403, "System administrator required to manage companies.");
    const v = z3.object({ id: id.optional(), name: short.min(1), active: z3.boolean(), details: z3.object({ phone: short.optional(), email: z3.string().trim().max(254).optional(), address: z3.string().trim().max(1e3).optional() }).strict(), version: z3.number().int().nonnegative(), reason }).strict().parse(data), key3 = v.id ?? randomUUID();
    const prior = (yield* q("SELECT * FROM companies WHERE tenant=@p0 AND id=@p1", p.tenant, key3))[0];
    if (Number(prior?.version ?? 0) !== v.version) throw new ApiError(409, "Company changed. Reload before saving.");
    if (!v.active && key3 === m.company) throw new ApiError(409, "You cannot deactivate your own administrator company.");
    if (!v.active && (yield* q("SELECT id FROM jobs WHERE tenant=@p0 AND company_id=@p1 AND status='active'", p.tenant, key3)).length) throw new ApiError(409, "Archive active company jobs before deactivating the company.");
    if (prior) yield* q("UPDATE companies SET name=@p0,active=@p1,details=@p2,version=version+1 WHERE tenant=@p3 AND id=@p4", v.name, Number(v.active), JSON.stringify(v.details), p.tenant, key3);
    else yield* q("INSERT INTO companies(tenant,id,name,active,details,version) VALUES(@p0,@p1,@p2,@p3,@p4,1)", p.tenant, key3, v.name, Number(v.active), JSON.stringify(v.details));
    yield* audit(p, "company:" + key3, prior, v, v.reason);
    return { id: key3 };
  }
  if (action === "job-save") {
    const v = z3.object({ id: id.optional(), companyId: id, number: z3.string().trim().min(1).max(80), name: short.min(1), status: z3.enum(["active", "archived"]), details: z3.object({ deliveryContactName: short.optional(), deliveryContactPhone: short.optional(), purchasingAgentName: short.optional(), purchasingAgentEmail: z3.string().trim().max(254).optional(), receivingHours: short.optional(), deliveryInstructions: z3.string().trim().max(2e3).optional(), address: z3.string().trim().max(1e3).optional(), startDate: z3.iso.date().or(z3.literal("")).optional(), endDate: z3.iso.date().or(z3.literal("")).optional() }).strict(), version: z3.number().int().nonnegative(), reason }).strict().parse(data);
    yield* scoped(p, v.companyId);
    const company = (yield* q("SELECT active FROM companies WHERE tenant=@p0 AND id=@p1", p.tenant, v.companyId))[0];
    if (!company?.active) throw new ApiError(400, "Choose an active company.");
    if (v.details.startDate && v.details.endDate && v.details.endDate < v.details.startDate) throw new ApiError(400, "Job end date must follow its start date.");
    const key3 = v.id ?? randomUUID(), prior = (yield* q("SELECT * FROM jobs WHERE tenant=@p0 AND id=@p1", p.tenant, key3))[0];
    if (prior) yield* scoped(p, String(prior.company_id));
    if (prior && prior.company_id !== v.companyId) throw new ApiError(409, "A job cannot move between companies.");
    if (Number(prior?.version ?? 0) !== v.version) throw new ApiError(409, "Job changed. Reload before saving.");
    const duplicate = (yield* q("SELECT id FROM jobs WHERE tenant=@p0 AND company_id=@p1 AND LOWER(number)=LOWER(@p2)", p.tenant, v.companyId, v.number))[0];
    if (duplicate && duplicate.id !== key3) throw new ApiError(409, "That company already has this job number.");
    if (prior) yield* q("UPDATE jobs SET name=@p0,number=@p1,status=@p2,details=@p3,version=version+1 WHERE tenant=@p4 AND id=@p5", v.name, v.number, v.status, JSON.stringify(v.details), p.tenant, key3);
    else yield* q("INSERT INTO jobs(tenant,id,company_id,number,name,status,details,version) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,1)", p.tenant, key3, v.companyId, v.number, v.name, v.status, JSON.stringify(v.details));
    yield* audit(p, "job:" + key3, prior, v, v.reason);
    return { id: key3 };
  }
  if (action === "workforce-save") {
    const v = z3.object({ oid: id, displayName: short.min(1), active: z3.boolean(), companyId: id, accessRole: z3.enum(["Member", "CompanyAdmin"]), details: z3.object({ email: z3.email().max(254).or(z3.literal("")), phone: short, title: short, employeeNumber: short }).strict(), assignments: z3.array(z3.object({ jobId: id, role: z3.enum(jobRoles), supervisorId: id.nullable(), topLevel: z3.boolean() }).strict()).max(200), version: z3.number().int().nonnegative(), reason }).strict().parse(data);
    yield* scoped(p, v.companyId);
    const prior = (yield* q("SELECT u.*,p.company_id,p.access_role FROM application_users u LEFT JOIN user_profiles p ON p.tenant=u.tenant AND p.oid=u.oid WHERE u.tenant=@p0 AND u.oid=@p1", p.tenant, v.oid))[0];
    if (prior) yield* scoped(p, String(prior.company_id ?? "main"));
    if (prior?.company_id && prior.company_id !== v.companyId) throw new ApiError(409, "Users cannot move companies; remove access and invite a separate company account.");
    if (Number(prior?.version ?? 0) !== v.version) throw new ApiError(409, "User changed. Reload before saving.");
    if (prior?.entra_admin && !m.root) throw new ApiError(403, "Only a system administrator can change this account.");
    if (!m.root && (v.accessRole === "CompanyAdmin" || prior?.access_role === "CompanyAdmin")) throw new ApiError(403, "Only a system administrator can assign or change company administrators.");
    if (v.oid === p.oid && !v.active) throw new ApiError(409, "You cannot deactivate your own account.");
    if (!m.root && v.oid === p.oid) throw new ApiError(409, "Ask another administrator to change your own permissions.");
    if (!(yield* q("SELECT id FROM companies WHERE tenant=@p0 AND id=@p1 AND active=1", p.tenant, v.companyId)).length) throw new ApiError(400, "Choose an active company.");
    if (new Set(v.assignments.map((a) => a.jobId)).size !== v.assignments.length) throw new ApiError(400, "Assign each job once.");
    if (prior && !prior.company_id && v.companyId !== "main" && (yield* q("SELECT id FROM drafts WHERE tenant=@p0 AND owner=@p1", p.tenant, v.oid)).length) throw new ApiError(409, "Existing MRFs require retaining this user company association.");
    const credential = (yield* q("SELECT email FROM site_credentials WHERE tenant=@p0 AND oid=@p1", p.tenant, v.oid))[0];
    if (credential && String(credential.email).toLowerCase() !== v.details.email.toLowerCase()) throw new ApiError(409, "Site sign-in email cannot be changed through contact editing.");
    if (v.details.email) {
      const profiles = yield* q("SELECT oid,details FROM user_profiles WHERE tenant=@p0", p.tenant);
      if (profiles.some((profile) => profile.oid !== v.oid && String(details(profile).email ?? "").toLowerCase() === v.details.email.toLowerCase())) throw new ApiError(409, "Another user already has that email address.");
    }
    const allMembers = yield* q("SELECT * FROM memberships WHERE tenant=@p0", p.tenant);
    for (const a of v.assignments) {
      const job = (yield* q("SELECT * FROM jobs WHERE tenant=@p0 AND id=@p1", p.tenant, a.jobId))[0];
      if (!job || job.company_id !== v.companyId) throw new ApiError(400, "Every job must belong to the user company.");
      if (job.status !== "active" && !allMembers.some((x) => x.owner === v.oid && x.project === a.jobId)) throw new ApiError(400, "New assignments require an active job.");
      if (a.topLevel && a.supervisorId) throw new ApiError(400, "A top-level assignment cannot also report to another person.");
      if (v.active && !a.topLevel && !a.supervisorId) throw new ApiError(400, "Select a supervisor or explicitly designate this assignment top-level.");
      if (a.supervisorId === v.oid) throw new ApiError(400, "A user cannot report to themselves.");
      if (a.supervisorId) {
        const supervisor = (yield* q("SELECT u.active,p.company_id FROM application_users u LEFT JOIN user_profiles p ON p.tenant=u.tenant AND p.oid=u.oid WHERE u.tenant=@p0 AND u.oid=@p1", p.tenant, a.supervisorId))[0];
        if (!supervisor || v.active && !supervisor.active || (supervisor.company_id ?? "main") !== v.companyId || !allMembers.some((x) => x.owner === a.supervisorId && x.project === a.jobId)) throw new ApiError(400, "Supervisor must be active and assigned to the same job and company.");
        let cursor = a.supervisorId;
        const visited = /* @__PURE__ */ new Set([v.oid]);
        while (cursor) {
          if (visited.has(cursor)) throw new ApiError(400, "Reporting relationships cannot contain a cycle.");
          visited.add(cursor);
          cursor = allMembers.find((x) => x.owner === cursor && x.project === a.jobId)?.supervisor_oid ?? null;
        }
      }
    }
    for (const old of allMembers.filter((a) => a.owner === v.oid)) {
      const dependents = allMembers.filter((a) => a.project === old.project && a.supervisor_oid === v.oid);
      if (dependents.length && !v.assignments.some((a) => a.jobId === old.project)) throw new ApiError(409, "Reassign this supervisor\u2019s direct reports before removing their job access.");
    }
    const before = { user: prior, assignments: allMembers.filter((a) => a.owner === v.oid) }, now3 = (/* @__PURE__ */ new Date()).toISOString();
    if (prior) yield* q("UPDATE application_users SET display_name=@p0,active=@p1,version=version+1 WHERE tenant=@p2 AND oid=@p3", v.displayName, Number(v.active), p.tenant, v.oid);
    else yield* q("INSERT INTO application_users(tenant,oid,display_name,active,role_limit,entra_admin,version,created_at) VALUES(@p0,@p1,@p2,@p3,NULL,0,1,@p4)", p.tenant, v.oid, v.displayName, Number(v.active), now3);
    if ((yield* q("SELECT oid FROM user_profiles WHERE tenant=@p0 AND oid=@p1", p.tenant, v.oid)).length) yield* q("UPDATE user_profiles SET access_role=@p0,details=@p1 WHERE tenant=@p2 AND oid=@p3", v.accessRole, JSON.stringify(v.details), p.tenant, v.oid);
    else yield* q("INSERT INTO user_profiles(tenant,oid,company_id,access_role,details) VALUES(@p0,@p1,@p2,@p3,@p4)", p.tenant, v.oid, v.companyId, v.accessRole, JSON.stringify(v.details));
    yield* q("DELETE FROM memberships WHERE tenant=@p0 AND owner=@p1", p.tenant, v.oid);
    for (const a of v.assignments) yield* q("INSERT INTO memberships(tenant,owner,project,job_role,supervisor_oid,top_level) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", p.tenant, v.oid, a.jobId, a.role, a.supervisorId, Number(a.topLevel));
    if (!v.active) {
      yield* q("DELETE FROM account_sessions WHERE tenant=@p0 AND oid=@p1", p.tenant, v.oid);
      yield* q("DELETE FROM account_tokens WHERE tenant=@p0 AND oid=@p1", p.tenant, v.oid);
    }
    yield* audit(p, v.oid, before, v, v.reason);
    return { oid: v.oid };
  }
  if (action === "revoke-sessions") {
    const v = z3.object({ oid: id, reason }).strict().parse(data);
    const u = (yield* q("SELECT p.company_id,u.entra_admin FROM application_users u LEFT JOIN user_profiles p ON p.tenant=u.tenant AND p.oid=u.oid WHERE u.tenant=@p0 AND u.oid=@p1", p.tenant, v.oid))[0];
    if (!u) throw new ApiError(404, "User not found.");
    yield* scoped(p, String(u.company_id ?? "main"));
    if (u.entra_admin && !m.root) throw new ApiError(403, "System administrator required.");
    yield* q("DELETE FROM account_sessions WHERE tenant=@p0 AND oid=@p1", p.tenant, v.oid);
    yield* audit(p, v.oid, null, { action: "site sessions revoked" }, v.reason);
    return { ok: true, microsoft: "Microsoft sessions are managed by your Microsoft administrator." };
  }
  throw new ApiError(404, "User management operation not found.");
}

// server/site-accounts.ts
var now = () => (/* @__PURE__ */ new Date()).toISOString();
var passwordSchema = z4.string().min(12, "Use at least 12 characters.").max(128, "Use no more than 128 characters.").refine((p) => !["passwordpassword", "123456789012", "abcdefghijkl"].includes(p.toLowerCase()), "Choose a less common password.");
function* q2(text4, ...values) {
  return yield { text: text4, values };
}
function* record(p, target, action) {
  yield* q2("INSERT INTO user_access_changes(id,tenant,oid,before_json,after_json,reason,actor,created_at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7)", randomUUID2(), p.tenant, target, "{}", JSON.stringify({ action }), action, p.oid, now());
}
function* accountAction(tenant, action, data, p) {
  if (action === "credential") return (yield* q2("SELECT c.*,u.active FROM site_credentials c JOIN application_users u ON u.tenant=c.tenant AND u.oid=c.oid WHERE c.tenant=@p0 AND c.email=@p1", tenant, data.email))[0] ?? null;
  if (action === "attempt") {
    yield* q2("DELETE FROM account_limits WHERE tenant=@p0 AND expires_at<=@p1", tenant, now());
    const current = (yield* q2("SELECT * FROM account_limits WHERE tenant=@p0 AND email=@p1", tenant, data.email))[0];
    if (current && String(current.expires_at) > now() && Number(current.attempts) >= 15) throw new ApiError(429, "Too many attempts. Wait 15 minutes before trying again.");
    if (current && String(current.expires_at) > now()) yield* q2("UPDATE account_limits SET attempts=attempts+1 WHERE tenant=@p0 AND email=@p1", tenant, data.email);
    else {
      yield* q2("DELETE FROM account_limits WHERE tenant=@p0 AND email=@p1", tenant, data.email);
      yield* q2("INSERT INTO account_limits(tenant,email,attempts,expires_at) VALUES(@p0,@p1,1,@p2)", tenant, data.email, new Date(Date.now() + 15 * 60 * 1e3).toISOString());
    }
    return { ok: true };
  }
  if (action === "session-create") {
    const row2 = (yield* q2("SELECT c.*,u.active FROM site_credentials c JOIN application_users u ON u.tenant=c.tenant AND u.oid=c.oid WHERE c.tenant=@p0 AND c.oid=@p1", tenant, data.oid))[0];
    if (!row2?.active || row2.password_hash !== data.expectedHash) throw new ApiError(401, "Email or password is incorrect.");
    yield* q2("DELETE FROM account_limits WHERE tenant=@p0 AND email=@p1", tenant, row2.email);
    yield* q2("DELETE FROM account_sessions WHERE tenant=@p0 AND (expires_at<@p1 OR oid=@p2)", tenant, now(), row2.oid);
    yield* q2("INSERT INTO account_sessions(tenant,token_hash,oid,credential_version,expires_at) VALUES(@p0,@p1,@p2,@p3,@p4)", tenant, data.hash, row2.oid, row2.version, new Date(Date.now() + 8 * 60 * 60 * 1e3).toISOString());
    return { ok: true };
  }
  if (action === "session") {
    const r = (yield* q2("SELECT s.oid,u.display_name FROM account_sessions s JOIN site_credentials c ON c.tenant=s.tenant AND c.oid=s.oid AND c.version=s.credential_version JOIN application_users u ON u.tenant=s.tenant AND u.oid=s.oid WHERE s.tenant=@p0 AND s.token_hash=@p1 AND s.expires_at>@p2 AND u.active=1", tenant, data.hash, now()))[0];
    if (!r) throw new ApiError(401, "Sign in to continue.");
    return { tenant, oid: String(r.oid), roles: ["Foreman"], displayName: String(r.display_name) };
  }
  if (action === "logout") {
    yield* q2("DELETE FROM account_sessions WHERE tenant=@p0 AND token_hash=@p1", tenant, data.hash);
    return { ok: true };
  }
  if (action === "issue-link") {
    if (!p) throw new ApiError(403, "Administrator required.");
    const m = yield* manager(p), v = z4.object({ oid: z4.string().min(1).max(64), kind: z4.enum(["invite", "reset"]), email: z4.email().max(254).optional(), hash: z4.string().length(64) }).strict().parse(data);
    const user = (yield* q2("SELECT u.*,p.company_id FROM application_users u LEFT JOIN user_profiles p ON p.tenant=u.tenant AND p.oid=u.oid WHERE u.tenant=@p0 AND u.oid=@p1", tenant, v.oid))[0];
    if (!user || !m.root && (user.company_id ?? "main") !== m.company) throw new ApiError(404, "User not found.");
    if (!user.active) throw new ApiError(400, "Activate the user before issuing a link.");
    if (user.entra_admin) throw new ApiError(400, "Microsoft administrators must use Microsoft account recovery.");
    const credential = (yield* q2("SELECT * FROM site_credentials WHERE tenant=@p0 AND oid=@p1", tenant, v.oid))[0];
    if (!credential) {
      if (v.kind !== "invite" || !v.email) throw new ApiError(400, "Invite this user with an email address first.");
      const email = v.email.toLowerCase();
      if ((yield* q2("SELECT oid FROM site_credentials WHERE tenant=@p0 AND email=@p1", tenant, email)).length) throw new ApiError(409, "This email already has a site account.");
      yield* q2("INSERT INTO site_credentials(tenant,oid,email,password_hash,version) VALUES(@p0,@p1,@p2,NULL,1)", tenant, v.oid, email);
    } else if (v.kind === "invite" && credential.password_hash) throw new ApiError(409, "Account is already registered; use password reset.");
    yield* q2("DELETE FROM account_tokens WHERE tenant=@p0 AND oid=@p1", tenant, v.oid);
    yield* q2("INSERT INTO account_tokens(tenant,token_hash,oid,kind,expires_at) VALUES(@p0,@p1,@p2,@p3,@p4)", tenant, v.hash, v.oid, v.kind, new Date(Date.now() + (v.kind === "invite" ? 72 * 60 : 30) * 60 * 1e3).toISOString());
    yield* record(p, v.oid, v.kind === "invite" ? "Site invitation issued" : "Password reset link issued");
    return { email: String(credential?.email ?? v.email).toLowerCase() };
  }
  if (action === "revoke-invitation") {
    if (!p) throw new ApiError(403, "Administrator required.");
    const m = yield* manager(p), u = (yield* q2("SELECT company_id FROM user_profiles WHERE tenant=@p0 AND oid=@p1", tenant, data.oid))[0];
    if (!u || !m.root && u.company_id !== m.company) throw new ApiError(404, "User not found.");
    yield* q2("DELETE FROM account_tokens WHERE tenant=@p0 AND oid=@p1", tenant, data.oid);
    yield* record(p, data.oid, "Outstanding invitation and reset links revoked");
    return { ok: true };
  }
  if (action === "token-info" || action === "password-set") {
    const r = (yield* q2("SELECT t.*,u.display_name,u.active,c.email FROM account_tokens t JOIN application_users u ON u.tenant=t.tenant AND u.oid=t.oid JOIN site_credentials c ON c.tenant=t.tenant AND c.oid=t.oid WHERE t.tenant=@p0 AND t.token_hash=@p1 AND t.expires_at>@p2", tenant, data.hash, now()))[0];
    if (!r?.active || !["invite", "reset"].includes(r.kind)) throw new ApiError(400, "This link has expired or was already used. Request a new link.");
    if (action === "token-info") return { name: r.display_name, email: r.email, kind: r.kind };
    yield* q2("UPDATE site_credentials SET password_hash=@p0,version=version+1 WHERE tenant=@p1 AND oid=@p2", data.passwordHash, tenant, r.oid);
    yield* q2("DELETE FROM account_tokens WHERE tenant=@p0 AND oid=@p1", tenant, r.oid);
    yield* q2("DELETE FROM account_sessions WHERE tenant=@p0 AND oid=@p1", tenant, r.oid);
    yield* q2("DELETE FROM account_limits WHERE tenant=@p0 AND email=@p1", tenant, r.email);
    yield* record({ tenant, oid: r.oid, roles: ["Foreman"] }, r.oid, r.kind === "invite" ? "Site account registered" : "Password reset completed");
    return { ok: true };
  }
  if (action === "self-reset") {
    const c = (yield* q2("SELECT c.oid FROM site_credentials c JOIN application_users u ON u.tenant=c.tenant AND u.oid=c.oid WHERE c.tenant=@p0 AND c.email=@p1 AND u.active=1 AND c.password_hash IS NOT NULL", tenant, data.email))[0];
    if (!c) return { found: false };
    yield* q2("DELETE FROM account_tokens WHERE tenant=@p0 AND oid=@p1", tenant, c.oid);
    yield* q2("INSERT INTO account_tokens(tenant,token_hash,oid,kind,expires_at) VALUES(@p0,@p1,@p2,@p3,@p4)", tenant, data.hash, c.oid, "reset", new Date(Date.now() + 30 * 60 * 1e3).toISOString());
    return { found: true };
  }
  throw new ApiError(404, "Account operation not found.");
}

// server/mrf-foreman.ts
init_contracts();
function* foremanRoster(p, project2) {
  const membership = yield { text: "SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", values: [p.tenant, p.oid, project2] };
  if (!membership.length) throw new ApiError(404, "Project not found.");
  const rows = yield { text: "SELECT u.oid,u.display_name FROM application_users u JOIN memberships m ON m.tenant=u.tenant AND m.owner=u.oid WHERE u.tenant=@p0 AND m.project=@p1 AND u.active=1 ORDER BY u.display_name,u.oid", values: [p.tenant, project2] };
  return { selfId: p.oid, users: rows.map((row2) => ({ id: String(row2.oid).toLowerCase(), name: String(row2.display_name) })) };
}
function* resolveForeman(p, project2, id2) {
  id2 = id2.toLowerCase();
  const users = yield { text: "SELECT u.oid,u.display_name,u.active,m.project FROM application_users u LEFT JOIN memberships m ON m.tenant=u.tenant AND m.owner=u.oid AND m.project=@p2 WHERE u.tenant=@p0 AND u.oid=@p1", values: [p.tenant, id2, project2] };
  const user = users[0];
  if (!user && id2 === p.oid.toLowerCase()) return { id: id2, name: p.displayName ?? p.oid };
  if (!user || !user.active || !user.project) throw new ApiError(400, "Choose an active registered foreman assigned to this job.");
  return { id: id2, name: String(user.display_name) };
}

// server/research-selection.ts
init_contracts();
import { z as z21 } from "zod";

// src/catalog-research.ts
import { z as z5 } from "zod";
var text2 = z5.string().trim().min(1).max(500);
var url = z5.url().max(2e3).refine((v) => {
  const u = new URL(v);
  return u.protocol === "https:" && !u.username && !u.password;
}, "Use a public HTTPS source URL.");
var productDetailsSchema = z5.record(z5.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,39}$/), z5.union([z5.string().max(4e3), z5.number().finite()])).refine((value) => Object.keys(value).length <= 40);
var researchCandidate = z5.object({ externalKey: text2.max(100), category: z5.enum(["conduit", "bracket", "box", "general"]), productUnit: z5.enum(["EA", "FT", "STICK", "BOX", "ROLL", "PAIR"]), attributes: z5.record(z5.string(), z5.union([z5.string(), z5.number()])), productDetails: productDetailsSchema.optional(), manufacturer: text2.max(200), partNumber: text2.max(200), title: text2, sourceUrl: url, verificationBasis: z5.string().trim().min(10).max(2e3), phrases: z5.array(text2).min(1).max(40) }).strict();
var researchResults = z5.object({ scope: z5.string().trim().max(2e3), coverageNotes: z5.string().trim().min(1).max(4e3), items: z5.array(researchCandidate).min(1).max(100) }).strict();
var researchDraftResults = researchResults.extend({ coverageNotes: z5.string().max(4e3), items: z5.array(researchCandidate.extend({ externalKey: z5.string().max(100), manufacturer: z5.string().max(200), partNumber: z5.string().max(200), title: z5.string().max(500), sourceUrl: z5.string().max(2e3), verificationBasis: z5.string().max(2e3), phrases: z5.array(z5.string().max(500)).max(40) })).min(1).max(100) });
var researchFields = { conduit: ["diameterIn", "material", "type", "schedule", "lengthIn", "endConnection"], bracket: ["minSpanIn", "maxSpanIn", "mounting", "material", "nominalSpacing"], box: ["type", "widthIn", "heightIn", "depthIn", "material", "knockouts"], general: ["type", "specification"] };

// src/measurements.ts
function parseInches(input2) {
  const fractions = { "\xBC": "1/4", "\xBD": "1/2", "\xBE": "3/4", "\u215B": "1/8", "\u215C": "3/8", "\u215D": "5/8", "\u215E": "7/8" };
  const value = input2.trim().replace(/[¼½¾⅛⅜⅝⅞]/g, (c) => " " + fractions[c]).replace(/\s+/g, " ").trim().replace(/\s*["″]$/, "").trim();
  if (/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(value)) {
    const number3 = Number(value);
    if (Number.isFinite(number3) && number3 > 0) return number3;
  }
  const fraction = /^(?:(\d+)\s+)?(\d+)\s*\/\s*(\d+)$/.exec(value);
  if (fraction) {
    const whole = Number(fraction[1] ?? 0), numerator = Number(fraction[2]), denominator = Number(fraction[3]);
    if (Number.isSafeInteger(whole) && Number.isSafeInteger(numerator) && Number.isSafeInteger(denominator) && denominator > 0 && numerator > 0 && (!fraction[1] || numerator < denominator)) {
      const number3 = whole + numerator / denominator;
      if (Number.isFinite(number3) && number3 > 0) return number3;
    }
  }
  throw new Error("Enter a positive inch measurement, such as 15.75 or 15 3/4. Other units are not converted.");
}
function formatInches(value) {
  const number3 = Number(value);
  if (!Number.isFinite(number3) || number3 < 0) return String(value);
  const whole = Math.floor(number3), numerator = Math.round((number3 - whole) * 64);
  if (Math.abs(number3 - (whole + numerator / 64)) > 1e-8) return String(value);
  if (numerator === 0) return String(whole);
  if (numerator === 64) return String(whole + 1);
  const gcd = (a, b) => b ? gcd(b, a % b) : a;
  const divisor = gcd(numerator, 64);
  return `${whole ? whole + " " : ""}${numerator / divisor}/${64 / divisor}`;
}

// server/material-search-constraints.ts
var measurement = "(?:\\d+(?:[ -]\\d+\\/\\d+|\\/\\d+|\\.\\d+)?|[\xBC\xBD\xBE])";
var number = (v) => {
  try {
    return parseInches(v.replace(/^(\d+)-(\d+\/\d+)$/, "$1 $2"));
  } catch {
    return NaN;
  }
};
function matchesPhysicalSearch(query4, a) {
  const q6 = query4.toLowerCase();
  const radius = q6.match(new RegExp(`(${measurement})\\s*(?:inches|inch|in\\b|["\u2033])?\\s*(?:radius|rad\\b)`));
  if (radius && (a.radiusIn == null || number(radius[1]) !== Number(a.radiusIn))) return false;
  const angle = q6.match(/(\d+(?:\.\d+)?)\s*(?:°|deg(?:ree)?s?\b)/) ?? q6.match(/\b(90|60|45|30|22\.5|15|11\.25|5)\s*(?:elbow|ell|bend|sweep)\b/);
  if (angle && (a.angleDeg == null || Number(angle[1]) !== Number(a.angleDeg))) return false;
  if (/\bstandard radius\b/.test(q6) && a.radiusClass && a.radiusClass !== "standard") return false;
  const type = String(a.type ?? "").toLowerCase();
  if (/\b(?:female adapter|female adaptor|fa)\b/.test(q6) && !type.includes("female")) return false;
  if (/\b(?:male adapter|male adaptor|ma)\b/.test(q6) && !/^male /.test(type)) return false;
  if (/\b(?:repair|slip) coupling\b/.test(q6) && !/(?:repair|without center stop)/.test(type)) return false;
  if (/\b(?:standard|center[- ]stop) coupling\b|coupling with (?:center )?stop/.test(q6) && !/with center stop/.test(type)) return false;
  const reducer = q6.match(new RegExp(`(${measurement})\\s*(?:inches|inch|in\\b|["\u2033])?\\s*[x\xD7]\\s*(${measurement})\\s*(?:inches|inch|in\\b|["\u2033])?`));
  if (reducer && (a.sizeAIn != null || a.sizeBIn != null)) {
    const requested = [number(reducer[1]), number(reducer[2])].sort((x, y) => y - x);
    if (requested[0] !== Number(a.sizeAIn) || requested[1] !== Number(a.sizeBIn)) return false;
  }
  if (a.compatibleSizesIn) {
    const requested = q6.match(new RegExp(`(${measurement})\\s*(?:inches|inch|in\\b|["\u2033])`));
    if (requested && !String(a.compatibleSizesIn).split(",").map(Number).includes(number(requested[1]))) return false;
  }
  return true;
}
function sizeQueryWithoutRadius(query4) {
  return query4.replace(new RegExp(`${measurement}\\s*(?:inches|inch|in\\b|["\u2033])?\\s*(?:radius|rad\\b)`, "gi"), "");
}

// src/material-families.ts
var labels = { diameterIn: "Trade size (in)", lengthIn: "Stock length (in)", material: "Material", schedule: "Schedule", endConnection: "End configuration", sizeAIn: "End A trade size (in)", sizeBIn: "End B trade size (in)", connectionA: "End A connection", connectionB: "End B connection", angleDeg: "Bend angle (degrees)", radiusClass: "Radius classification", radiusIn: "Centerline radius (in)", widthIn: "Width (in)", heightIn: "Height (in)", depthIn: "Depth (in)", cover: "Cover configuration", mounting: "Mounting configuration", entries: "Entry configuration", rating: "Environmental rating", bodyType: "Body type", position: "Base / intermediate / other position", compatibleSizesIn: "Compatible trade sizes (comma-separated inches)", horizontalSpacingIn: "Horizontal center spacing (in)", verticalSpacingIn: "Vertical center spacing (in)", conduitCount: "Conduit count", system: "Spacer system / interface", volumeOz: "Container volume (US fl oz)", grade: "Product grade / application", specification: "Defining specifications" };
var fields = (keys) => keys.map((key3) => ({ key: key3, label: labels[key3] ?? key3, kind: key3.endsWith("In") && key3 !== "compatibleSizesIn" ? "inches" : ["angleDeg", "conduitCount", "volumeOz"].includes(key3) ? "number" : "text", required: true }));
function family(id2, name4, type, keys, pattern, category = "general", path = "Conduit & Raceway / PVC") {
  return { id: id2, name: name4, type, category, path, fields: fields(keys), identity: keys.filter((k) => k !== "radiusClass"), pattern };
}
var fitting = (id2, name4, type) => family(id2, name4, type, ["diameterIn", "material", "connectionA", "connectionB"], "{size} in. PVC " + type + ", {connectionA} \xD7 {connectionB}");
var materialFamilies = [
  family("pvc-conduit", "PVC conduit", "conduit", ["diameterIn", "material", "schedule", "lengthIn", "endConnection"], "{size} in. PVC conduit, Schedule {schedule}, {lengthFt} ft. length, {endConnection}", "conduit"),
  family("pvc-factory-bend", "PVC factory elbows and sweeps", "factory elbow", ["diameterIn", "material", "schedule", "angleDeg", "radiusClass", "radiusIn", "endConnection"], "{size} in. PVC factory elbow/sweep, Schedule {schedule}, {angle}\xB0, {radius} in. radius, {endConnection}"),
  ...[["pvc-male-adapter", "Male adapters", "male adapter"], ["pvc-female-adapter", "Female adapters", "female adapter"], ["pvc-box-adapter", "Box adapters", "box adapter"], ["pvc-repair-adapter", "Repair adapters", "repair adapter"], ["pvc-offset-adapter", "Offset adapters", "offset adapter"], ["pvc-coupling", "Center-stop couplings", "coupling with center stop"], ["pvc-repair-coupling", "Slip / repair couplings", "repair coupling without center stop"], ["pvc-long-coupling", "Long-line couplings", "long-line coupling"], ["pvc-split-coupling", "Split repair couplings", "split-sleeve repair coupling"], ["pvc-swedged-coupling", "Swedged couplings", "swedged coupling"], ["pvc-bell-coupling", "Bell connection couplings", "bell coupling"]].map(([id2, name4, type]) => fitting(id2, name4, type)),
  ...[["pvc-reducing-coupling", "Reducing couplings", "reducing coupling"], ["pvc-reducer-bushing", "Reducer bushings", "reducer bushing"], ["pvc-reducing-adapter", "Reducing adapters", "reducing adapter"], ["pvc-swedged-reducer", "Swedged reducers", "swedged reducer"], ["pvc-threaded-bushing", "Threaded reducing bushings", "threaded reducing bushing"]].map(([id2, name4, type]) => family(id2, name4, type, ["sizeAIn", "sizeBIn", "material", "connectionA", "connectionB"], "{sizeA} \xD7 {sizeB} in. PVC " + type + ", {connectionA} \xD7 {connectionB}")),
  family("pvc-expansion-coupling", "Expansion couplings", "expansion coupling", ["diameterIn", "material", "connectionA", "connectionB", "travelIn", "specification"], "{size} in. PVC expansion coupling, {travel} in. travel, {specification}"),
  family("pvc-box", "PVC boxes", "junction box", ["lengthIn", "widthIn", "depthIn", "material", "cover", "mounting", "entries", "rating"], "PVC {type}, {length} \xD7 {width} \xD7 {depth} in., {cover}, {entries}, {rating}", "box"),
  family("pvc-conduit-body", "PVC conduit bodies", "conduit body", ["diameterIn", "material", "bodyType", "cover", "entries", "rating"], "{size} in. PVC {bodyType} conduit body, {cover}, {entries}, {rating}"),
  family("duct-bank-spacer", "Duct-bank spacers", "duct-bank spacer", ["compatibleSizesIn", "horizontalSpacingIn", "verticalSpacingIn", "position", "conduitCount", "material", "system"], "{position} duct-bank spacer, {sizes} in. conduit, {horizontal} \xD7 {vertical} in. centers, {count}-way", "general", "Conduit & Raceway / Duct-bank accessories"),
  ...[["pvc-end-bell", "End bells", "end bell"], ["pvc-cap", "End caps and plugs", "end cap"], ["pvc-bushing", "Bushings", "bushing"], ["pvc-strap", "Straps and clamps", "conduit strap"], ["pvc-support", "Conduit supports", "conduit support"]].map(([id2, name4, type]) => family(id2, name4, type, ["diameterIn", "material", "specification"], "{size} in. PVC " + type + ", {specification}")),
  family("pvc-consumable", "PVC installation consumables", "installation consumable", ["material", "volumeOz", "grade", "specification"], "{type}, {volume} fl oz, {grade}, {specification}", "consumables"),
  family("generic-hardware", "Hardware / fasteners", "hardware", ["specification"], "{type}, {specification}", "hardware-fasteners", "Hardware & Fasteners"),
  family("generic-drill-bit", "Drill bits", "drill bit", ["specification"], "{type}, {specification}", "drill-bits", "Tools & Consumables"),
  family("generic-material", "Other generic materials", "material", ["specification"], "{type}, {specification}", "general", "Other materials")
];
var materialFamily = (id2) => materialFamilies.find((f) => f.id === id2);
function inferredFamily(a) {
  return materialFamily(a.familyId) ?? (a.category === "conduit" && String(a.material).toLowerCase() === "pvc" && String(a.type).toLowerCase() === "conduit" ? materialFamily("pvc-conduit") : void 0);
}

// server/material-family.ts
init_contracts();
var fail = (text4) => {
  throw new ApiError(400, text4);
};
function familyDescription(category, a) {
  if (!a.familyId) return;
  const f = materialFamily(a.familyId);
  if (!f) return fail("Choose a supported material family.");
  if (f.category !== category) fail("Family " + f.name + " requires category " + f.category + ".");
  if (a.configurationStatus && a.configurationStatus !== "confirmed") fail("Unconfirmed configurations must remain in the workbook for research; they cannot be published.");
  for (const field2 of f.fields) {
    const v = a[field2.key];
    if (v === void 0 || String(v).trim() === "") fail(field2.label + " is required for " + f.name + ".");
    if (field2.kind !== "text" && (typeof v !== "number" || !Number.isFinite(v) || v <= 0)) fail(field2.label + " must be a positive numeric value.");
  }
  if (!a.type) fail("Type / Name is required.");
  if (!["generic-hardware", "generic-drill-bit", "generic-material", "pvc-box", "pvc-consumable", "pvc-cap", "pvc-strap", "pvc-support"].includes(f.id) && String(a.type).toLowerCase() !== f.type) fail("Use Type / Name: " + f.type + ". Put alternate names in Search Phrases.");
  if (f.id.startsWith("pvc-") && !["pvc-strap", "pvc-support", "pvc-consumable"].includes(f.id) && String(a.material).toLowerCase() !== "pvc") fail("This family is for PVC. Choose another family for other construction materials.");
  if (a.schedule && !["40", "80"].includes(String(a.schedule))) fail("Initial PVC families support Schedule 40 or 80.");
  if (a.angleDeg && Number(a.angleDeg) > 180) fail("Bend angle must be at most 180 degrees.");
  if (a.radiusClass && !["standard", "long radius", "custom"].includes(String(a.radiusClass))) fail("Radius Class: use standard, long radius or custom.");
  if (a.sizeAIn && a.sizeBIn && Number(a.sizeAIn) <= Number(a.sizeBIn)) fail("Reducing fittings: End A must be the larger size; keep its connection paired with that size.");
  if (f.id === "duct-bank-spacer") {
    const sizes = String(a.compatibleSizesIn).split(",").map((s) => Number(s.trim()));
    if (sizes.some((n) => !Number.isFinite(n) || n <= 0) || new Set(sizes).size !== sizes.length) fail("Compatible sizes: use unique decimal inches separated by commas.");
    if (!Number.isInteger(a.conduitCount)) fail("Conduit count must be a positive whole number.");
  }
  const inch = (k) => formatInches(a[k]), size = () => `${inch("diameterIn")} in.`, ends = () => `${a.connectionA} \xD7 ${a.connectionB}`;
  switch (f.id) {
    case "pvc-conduit":
      return `${size()} PVC conduit, Schedule ${a.schedule}, ${Number(a.lengthIn) % 12 === 0 ? `${Number(a.lengthIn) / 12} ft.` : `${inch("lengthIn")} in.`} length, ${a.endConnection}`;
    case "pvc-factory-bend":
      return `${size()} PVC ${a.radiusClass === "standard" ? "factory elbow" : "sweep"}, Schedule ${a.schedule}, ${a.angleDeg}\xB0, ${a.radiusClass === "standard" ? "standard radius, " : ""}${inch("radiusIn")} in. radius, ${a.endConnection}`;
    case "pvc-box":
      return `PVC ${a.type}, ${inch("lengthIn")} \xD7 ${inch("widthIn")} \xD7 ${inch("depthIn")} in., ${a.cover}, ${a.mounting}, ${a.entries}, ${a.rating}`;
    case "pvc-conduit-body":
      return `${size()} PVC ${a.bodyType} conduit body, ${a.cover}, ${a.entries}, ${a.rating}`;
    case "duct-bank-spacer":
      return `${a.position} duct-bank spacer, ${a.compatibleSizesIn} in. conduit, ${inch("horizontalSpacingIn")} \xD7 ${inch("verticalSpacingIn")} in. centers, ${a.conduitCount}-way, ${a.material}, ${a.system}`;
    case "pvc-consumable":
      return `${a.type}, ${a.volumeOz} fl oz, ${a.grade}, ${a.specification}`;
  }
  if (a.sizeAIn) return `${inch("sizeAIn")} \xD7 ${inch("sizeBIn")} in. ${a.material} ${a.type}, ${ends()}`;
  if (a.connectionA) return `${size()} ${a.material} ${a.type}, ${ends()}${a.travelIn ? `, ${inch("travelIn")} in. travel` : ""}${a.specification ? `, ${a.specification}` : ""}`;
  return `${a.diameterIn ? size() + " " : ""}${a.material ? a.material + " " : ""}${a.type}, ${a.specification}`;
}
function familyIdentityFields(category, a) {
  const f = inferredFamily({ ...a, category });
  if (!f) return null;
  return new Set(Object.keys(a).filter((k) => !["familyId", "configurationStatus", "radiusClass"].includes(k) && (k !== "specification" || f.identity.includes(k))));
}

// server/material-workbook.ts
import { createHash as createHash4, randomUUID as randomUUID5 } from "node:crypto";
import { z as z9 } from "zod";

// server/catalog-workbook.ts
import readXlsxFile from "read-excel-file/node";
import { unzipSync, strFromU8 } from "fflate";
import { parse } from "csv-parse/sync";
init_contracts();

// src/material-workbook-format.ts
var materialWorkbookColumns = [
  ["Material Key", "key", 25],
  ["Description *", "description", 55],
  ["Category *", "category", 24],
  ["Material Family", "familyId", 28],
  ["Unit *", "unit", 10],
  ["Type / Name *", "type", 28],
  ["Defining Specifications", "specification", 65],
  ["Trade Size (in)", "diameterIn", 17],
  ["Length (in or ft)", "lengthIn", 18],
  ["Material", "material", 18],
  ["Schedule", "schedule", 12],
  ["End Connection", "endConnection", 20],
  ["Minimum Span (in)", "minSpanIn", 20],
  ["Maximum Span (in)", "maxSpanIn", 20],
  ["Mounting", "mounting", 24],
  ["Width (in)", "widthIn", 16],
  ["Height (in)", "heightIn", 16],
  ["Depth (in)", "depthIn", 16],
  ["Knockouts", "knockouts", 25],
  ["Finish", "finish", 24],
  ["Bend Angle (deg)", "angleDeg", 18],
  ["Radius Class", "radiusClass", 20],
  ["Centerline Radius (in)", "radiusIn", 24],
  ["End A Size (in)", "sizeAIn", 18],
  ["End B Size (in)", "sizeBIn", 18],
  ["End A Connection", "connectionA", 24],
  ["End B Connection", "connectionB", 24],
  ["Other Specifications", "extra", 50],
  ["Search Phrases", "phrases", 65],
  ["Image URL", "image", 45],
  ["Evidence URL", "source", 45],
  ["Notes", "notes", 55],
  ["Configuration Status", "configurationStatus", 24],
  ["Catalog Status", "status", 28]
];

// server/material-workbook.ts
init_contracts();

// server/material-categories.ts
init_contracts();
import { randomUUID as randomUUID3 } from "node:crypto";
import { z as z6 } from "zod";

// src/material-categories.ts
var labels2 = { type: "Type / name", specification: "Defining specifications", diameterIn: "Trade size (in)", lengthIn: "Length (in)", minSpanIn: "Min span (in)", maxSpanIn: "Max span (in)", widthIn: "Width (in)", heightIn: "Height (in)", depthIn: "Depth (in)", endConnection: "End connection", mounting: "Mounting", material: "Material", schedule: "Schedule", finish: "Finish", knockouts: "Knockouts" };
var sets = { general: ["type", "specification"], "hardware-fasteners": ["type", "specification"], "drill-bits": ["type", "specification"], consumables: ["type", "specification"], conduit: ["diameterIn", "material", "type", "schedule", "lengthIn", "endConnection"], bracket: ["minSpanIn", "maxSpanIn", "mounting", "material", "finish"], box: ["type", "widthIn", "heightIn", "depthIn", "material", "knockouts"] };
var builtinCategories = Object.entries(sets).map(([id2, keys]) => ({ id: id2, name: id2 === "hardware-fasteners" ? "Hardware / Fasteners" : id2 === "drill-bits" ? "Drill bits" : id2, version: 1, builtin: true, fields: keys.map((key3) => ({ key: key3, label: labels2[key3] ?? key3, type: key3.endsWith("In") ? "inches" : "text", required: key3 !== "finish" })) }));

// server/material-categories.ts
var field = z6.object({ key: z6.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,39}$/).refine((value) => !["type", "specification", "category", "recordOrigin", "unit", "description", "externalKey"].includes(value) && !/manufacturer|brand|vendor|partnumber|source|verification|price|usage|image/i.test(value), "Choose a material specification field name."), label: z6.string().trim().min(1).max(80), type: z6.enum(["text", "number", "inches"]), required: z6.boolean() }).strict();
function* materialCategories(p) {
  const rows = yield { text: "SELECT * FROM material_categories WHERE tenant=@p0 ORDER BY normalized,id", values: [p.tenant] };
  return [...builtinCategories, ...rows.map((row2) => ({ id: row2.id, name: row2.name, version: Number(row2.version), builtin: false, fields: [...builtinCategories[0].fields, ...JSON.parse(row2.fields_json)] }))];
}
function* saveCategory(p, data) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
  const input2 = z6.object({ id: z6.string().max(60).optional(), version: z6.number().int().positive().optional(), name: z6.string().trim().min(1).max(100), fields: z6.array(field).max(18) }).strict().parse(data);
  if (new Set(input2.fields.map((field2) => field2.key.toLowerCase())).size !== input2.fields.length) throw new ApiError(400, "Specification field names must be unique.");
  const all = yield* materialCategories(p), normalized = input2.name.normalize("NFKC").toLowerCase();
  if (all.some((category) => category.name.normalize("NFKC").toLowerCase() === normalized && category.id !== input2.id)) throw new ApiError(409, "A category with this name already exists.");
  let id2 = input2.id ?? "custom-" + randomUUID3();
  let version = 1;
  if (input2.id) {
    const old = all.find((category) => category.id === input2.id);
    if (!old || old.builtin) throw new ApiError(400, "Built-in categories cannot be changed here.");
    if (old.version !== input2.version) throw new ApiError(409, "Category changed. Reload categories before editing.");
    for (const previous of old.fields.filter((field2) => !["type", "specification"].includes(field2.key))) {
      const next = input2.fields.find((field2) => field2.key === previous.key);
      if (!next || next.type !== previous.type) throw new ApiError(400, "Existing field keys and types must be retained. Add fields or update their labels instead.");
    }
    version = old.version + 1;
    yield { text: "UPDATE material_categories SET name=@p0,normalized=@p1,fields_json=@p2,version=@p3 WHERE tenant=@p4 AND id=@p5", values: [input2.name, normalized, JSON.stringify(input2.fields), version, p.tenant, id2] };
  } else yield { text: "INSERT INTO material_categories(tenant,id,name,normalized,fields_json,version) VALUES(@p0,@p1,@p2,@p3,@p4,1)", values: [p.tenant, id2, input2.name, normalized, JSON.stringify(input2.fields)] };
  yield { text: "INSERT INTO audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", values: [randomUUID3(), p.tenant, p.oid, "catalog.category_saved", id2, (/* @__PURE__ */ new Date()).toISOString()] };
  return { id: id2, version, categories: yield* materialCategories(p) };
}
function* validateMaterialCategory(p, input2) {
  if (builtinCategories.some((category) => category.id === input2.category)) return;
  const definition = (yield* materialCategories(p)).find((category) => category.id === input2.category);
  if (!definition) throw new ApiError(400, "Unknown category. Add it under Materials \u2192 Manage categories first.");
  for (const field2 of definition.fields) {
    const value = input2.attributes[field2.key];
    if (field2.required && (value === void 0 || String(value).trim() === "")) throw new ApiError(400, field2.label + " is required for " + definition.name + ".");
    if (value !== void 0 && field2.type !== "text" && (typeof value !== "number" || !Number.isFinite(value) || field2.type === "inches" && value <= 0)) throw new ApiError(400, field2.label + " requires a " + (field2.type === "inches" ? "positive inch measurement" : "number") + ".");
  }
}

// server/research-pdf.ts
init_contracts();

// server/research-source.ts
init_contracts();
import { BlockList, isIP } from "node:net";
var blocked = new BlockList();
for (const [address, prefix] of [["0.0.0.0", 8], ["10.0.0.0", 8], ["100.64.0.0", 10], ["127.0.0.0", 8], ["169.254.0.0", 16], ["172.16.0.0", 12], ["192.0.0.0", 24], ["192.0.2.0", 24], ["192.168.0.0", 16], ["198.18.0.0", 15], ["198.51.100.0", 24], ["203.0.113.0", 24], ["224.0.0.0", 4], ["240.0.0.0", 4]]) blocked.addSubnet(address, prefix, "ipv4");
function publicSourceUrl(value) {
  let url4;
  try {
    url4 = new URL(value);
  } catch {
    throw new ApiError(400, "Use a complete public HTTPS manufacturer page URL.");
  }
  if (url4.protocol !== "https:" || url4.username || url4.password || url4.port && url4.port !== "443" || isIP(url4.hostname) || !url4.hostname.includes(".") || /\.(local|internal|localhost)$/i.test(url4.hostname)) throw new ApiError(400, "Use a public HTTPS manufacturer page without credentials or a custom port.");
  url4.hash = "";
  return url4;
}

// server/catalog-publication.ts
import { z as z7 } from "zod";
import { createHash as createHash2 } from "node:crypto";
var norm = (v) => v.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
function* publicationPlan(p, id2, version, items, selected, parse5) {
  const existing = yield { text: "SELECT id,external_key,active FROM materials WHERE tenant=@p0 ORDER BY id", values: [p.tenant] };
  const products = yield { text: "SELECT p.id,p.material_id,p.normalized_part,p.active,m.normalized FROM manufacturer_products p JOIN manufacturers m ON m.id=p.manufacturer_id AND m.tenant=p.tenant WHERE p.tenant=@p0 ORDER BY p.id", values: [p.tenant] };
  const byId = new Map(items.map((row2) => [row2.id, row2])), parsed = /* @__PURE__ */ new Map(), failures = /* @__PURE__ */ new Map(), resolved = /* @__PURE__ */ new Map(), memo = /* @__PURE__ */ new Map();
  const message = (e) => e instanceof z7.ZodError ? e.issues.slice(0, 3).map((i) => `${i.path.join(".")}: ${i.message}`).join("; ") : e instanceof Error ? e.message : "Invalid record.";
  function value(row2) {
    if (!parsed.has(row2.id)) parsed.set(row2.id, parse5(row2));
    return parsed.get(row2.id);
  }
  function* materialFor(key3) {
    const rows = items.filter((row3) => row3.kind === "material" && row3.state === "unpublished" && norm(row3.fields.externalKey ?? "") === norm(key3));
    if (rows.length) {
      const identities = rows.map((row3) => describeMaterial(value(row3)).identity);
      if (new Set(identities).size > 1) throw Error(`Material key ${key3} has conflicting specification rows.`);
      const ids2 = yield* visit(rows[0]);
      return { ids: ids2, target: resolved.get(rows[0].id) };
    }
    const row2 = existing.find((row3) => norm(row3.external_key) === norm(key3) && row3.active);
    if (!row2) throw Error(`Required material ${key3} is missing, deleted or needs review.`);
    return { ids: /* @__PURE__ */ new Set(), target: String(row2.id).toLowerCase() };
  }
  function* visit(row2) {
    if (memo.has(row2.id)) return new Set(memo.get(row2.id));
    if (failures.has(row2.id)) throw Error(failures.get(row2.id));
    try {
      const v = value(row2), ids2 = /* @__PURE__ */ new Set([row2.id]);
      if (row2.kind === "material") {
        const result = yield* createMaterial(p, v, true);
        const target = result.id ? String(result.id).toLowerCase() : "new:" + describeMaterial(v).identity;
        if (result.id && !existing.some((m) => String(m.id).toLowerCase() === target && m.active)) throw Error("Matching material is retired; review it before publishing.");
        resolved.set(row2.id, target);
      } else {
        const material = yield* materialFor(v.materialKey);
        for (const dep of material.ids) ids2.add(dep);
        resolved.set(row2.id, material.target);
        if (row2.kind === "product") {
          const prior = products.find((product) => manufacturerIdentity(product.normalized) === manufacturerIdentity(v.manufacturer) && product.normalized_part === norm(v.partNumber));
          if (prior && (!prior.active || String(prior.material_id).toLowerCase() !== material.target)) throw Error(`Manufacturer part ${v.manufacturer} ${v.partNumber} conflicts with a different or retired catalog product.`);
          const peers = items.filter((item2) => item2.kind === "product" && item2.state === "unpublished" && manufacturerIdentity(item2.fields.manufacturer ?? "") === manufacturerIdentity(v.manufacturer) && norm(item2.fields.partNumber ?? "") === norm(v.partNumber));
          for (const peer of peers) {
            if (peer.id === row2.id) continue;
            const linked = yield* materialFor(value(peer).materialKey);
            if (linked.target !== material.target) throw Error("One manufacturer part is assigned to different material specifications.");
          }
        }
        if (row2.kind === "image" && v.manufacturer) {
          const prior = products.find((product) => manufacturerIdentity(product.normalized) === manufacturerIdentity(v.manufacturer) && product.normalized_part === norm(v.partNumber) && product.active && String(product.material_id).toLowerCase() === material.target);
          if (!prior) {
            const product = items.find((item2) => item2.kind === "product" && item2.state === "unpublished" && manufacturerIdentity(item2.fields.manufacturer ?? "") === manufacturerIdentity(v.manufacturer) && norm(item2.fields.partNumber ?? "") === norm(v.partNumber));
            if (!product) throw Error(`Required manufacturer product ${v.manufacturer} ${v.partNumber} is missing or deleted.`);
            const dep = yield* visit(product);
            if (resolved.get(product.id) !== material.target) throw Error("Image manufacturer product belongs to a different material.");
            for (const required of dep) ids2.add(required);
          }
        }
      }
      memo.set(row2.id, ids2);
      return new Set(ids2);
    } catch (e) {
      const error = message(e);
      failures.set(row2.id, error);
      throw Error(error);
    }
  }
  const ready = /* @__PURE__ */ new Set(), held = [], selectedReady = [];
  for (const itemId of selected) {
    const row2 = byId.get(itemId);
    try {
      const closure = yield* visit(row2);
      selectedReady.push(itemId);
      for (const item2 of closure) ready.add(item2);
    } catch (e) {
      held.push({ id: itemId, sheet: row2.sheet, row: row2.row, reason: message(e) });
    }
  }
  const readyIds = [...ready].sort(), dependencies = readyIds.filter((item2) => !selected.includes(item2));
  const signature2 = JSON.stringify({ id: id2, version, selected: [...selected].sort(), readyIds, held, resolved: [...resolved].sort(([a], [b]) => a.localeCompare(b)) });
  return { planHash: createHash2("sha256").update(signature2).digest("hex"), readyIds, selectedReady: selectedReady.length, held, dependencies: dependencies.map((id3) => {
    const row2 = byId.get(id3);
    return { id: id3, sheet: row2.sheet, row: row2.row, kind: row2.kind, key: row2.fields.externalKey ?? row2.fields.materialKey };
  }), selectedCount: selected.length };
}

// server/catalog-inbox.ts
init_contracts();
import { createHash as createHash3, randomUUID as randomUUID4 } from "node:crypto";
import { z as z8 } from "zod";

// server/catalog-spreadsheet.ts
var materialColumns = ["diameterIn", "material", "type", "schedule", "lengthIn", "endConnection", "minSpanIn", "maxSpanIn", "mounting", "nominalSpacing", "widthIn", "heightIn", "depthIn", "knockouts", "specification"];
var numeric = /* @__PURE__ */ new Set(["diameterIn", "lengthIn", "minSpanIn", "maxSpanIn", "widthIn", "heightIn", "depthIn"]);
var fields2 = {
  material: ["displayDescription", "details", "kind", "externalKey", "category", "productUnit", "verification", "origin", "sourceUrl", "verificationBasis", ...materialColumns],
  product: ["kind", "materialKey", "manufacturer", "partNumber", "title", "sourceUrl", "verification", "origin", "details"],
  translation: ["kind", "materialKey", "phrase", "origin", "sourceUrl"],
  image: ["kind", "materialKey", "manufacturer", "partNumber", "sourceUrl", "rightsBasis"]
};
function spreadsheetRecord(kind, row2) {
  for (const column of Object.keys(row2)) if (!fields2[kind].includes(column) && !(kind === "material" && /^attribute\.[a-zA-Z][a-zA-Z0-9]{0,39}$/.test(column))) throw new Error(`Unexpected column ${column} for ${kind}. Keep the template headers unchanged.`);
  const result = {};
  for (const column of fields2[kind]) {
    if (column === "kind" || kind === "material" && materialColumns.includes(column)) continue;
    const value = row2[column]?.trim();
    if (value) result[column] = column === "details" ? JSON.parse(value) : value;
  }
  if (kind === "material" || kind === "product" || kind === "translation") result.origin = row2.origin?.trim() ?? "";
  if (kind === "material") {
    result.sourceUrl = row2.sourceUrl?.trim() ?? "";
    const attributes = {};
    for (const [column, cell] of Object.entries(row2)) {
      const value = cell.trim();
      if (!value) continue;
      if (materialColumns.includes(column)) {
        if (numeric.has(column)) {
          if (!/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(value) || !Number.isFinite(Number(value))) throw new Error(`${column}: use decimal inches, such as 15.75; enter no inch marks, fractions or formulas.`);
          attributes[column] = Number(value);
        } else attributes[column] = value;
      } else if (column.startsWith("attribute.")) {
        const name4 = column.slice(10);
        if (materialColumns.includes(name4)) throw new Error(`Use the ${name4} column instead of ${column}.`);
        const family2 = materialFamily(row2["attribute.familyId"]);
        const field2 = family2?.fields.find((f) => f.key === name4);
        attributes[name4] = field2 && field2.kind !== "text" ? Number(value) : value;
      }
    }
    result.attributes = attributes;
  }
  return result;
}

// server/catalog-inbox.ts
var fields3 = z8.record(z8.string().max(100), z8.string().max(2e4)).refine((v) => Object.keys(v).length <= 60);
var itemSchema = z8.object({ id: z8.uuid(), kind: z8.enum(["material", "product", "translation", "image"]), sheet: z8.string().max(100), row: z8.number().int().positive(), fields: fields3, state: z8.enum(["unpublished", "published", "deleted"]) }).strict();
var payloadSchema = z8.object({ filename: z8.string().trim().min(1).max(200), items: z8.array(itemSchema).min(1).max(2e3), research: z8.object({ scope: z8.string().max(2e3), coverageNotes: z8.string().max(4e3), searchPhrase: z8.string().max(500), originalJson: z8.string().max(3e5).optional() }).strict().optional() }).strict();
var marker = "unpublished-import-v1";
function summary(payload, version) {
  return { workflow: marker, version, filename: payload.filename, unpublished: payload.items.filter((i) => i.state === "unpublished").length, published: payload.items.filter((i) => i.state === "published").length, deleted: payload.items.filter((i) => i.state === "deleted").length };
}
function admin(p) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
}
function* audit2(p, action, id2) {
  yield { text: "INSERT INTO audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", values: [randomUUID4(), p.tenant, p.oid, action, id2, (/* @__PURE__ */ new Date()).toISOString()] };
}
function parse2(item2) {
  const data = spreadsheetRecord(item2.kind, item2.fields);
  const result = { material: materialInput, product: productInput, translation: translationInput, image: imageReferenceInput }[item2.kind].parse(data);
  if ((item2.kind === "material" || item2.kind === "product") && result.origin !== "admin_reviewed" && result.verification !== "provisional") throw Error("AI-origin imports must remain provisional; publication approval is separate from fact verification.");
  if (item2.kind === "material") describeMaterial(result);
  return result;
}
function issue(error) {
  return error instanceof z8.ZodError ? error.issues.slice(0, 4).map((i) => `${i.path.join(".")}: ${i.message}`).join("; ") : error instanceof Error ? error.message : "Invalid record.";
}
function* load(p, id2) {
  const row2 = (yield { text: "SELECT * FROM catalog_batches WHERE tenant=@p0 AND id=@p1", values: [p.tenant, id2] })[0];
  if (!row2) throw new ApiError(404, "Unpublished import not found.");
  const report = JSON.parse(row2.report);
  if (report.workflow !== marker) throw new ApiError(404, "Not an unpublished import.");
  return { row: row2, report, payload: JSON.parse(row2.csv) };
}
function* view(p, id2) {
  const { row: row2, report, payload } = yield* load(p, id2);
  const parsed = /* @__PURE__ */ new Map(), errors = /* @__PURE__ */ new Map();
  for (const item2 of payload.items) {
    if (item2.state !== "unpublished") continue;
    try {
      parsed.set(item2.id, parse2(item2));
    } catch (e) {
      errors.set(item2.id, issue(e));
    }
  }
  const materialKeys = new Set(payload.items.filter((i) => i.kind === "material" && i.state === "unpublished").map((i) => i.fields.externalKey?.toLowerCase()));
  const validKeys = new Set(payload.items.filter((i) => i.kind === "material" && parsed.has(i.id)).map((i) => i.fields.externalKey?.toLowerCase()));
  for (const item2 of payload.items) {
    const value = parsed.get(item2.id);
    if (!value || item2.kind === "material") continue;
    if (materialKeys.has(value.materialKey.toLowerCase()) && !validKeys.has(value.materialKey.toLowerCase())) errors.set(item2.id, "Related material has unresolved specifications. Edit that material before publishing this record.");
  }
  const knownMaterials = yield { text: "SELECT id,external_key,active FROM materials WHERE tenant=@p0", values: [p.tenant] };
  const markers = /* @__PURE__ */ new Map(), materialIds = /* @__PURE__ */ new Map();
  const norm3 = (value) => value.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  for (const item2 of payload.items) {
    if (item2.kind !== "material" || item2.state !== "unpublished" || !parsed.has(item2.id)) continue;
    try {
      const match = yield* createMaterial(p, parsed.get(item2.id), true);
      if (match.id) {
        materialIds.set(norm3(item2.fields.externalKey), match.id);
        const retired = !knownMaterials.find((material) => String(material.id).toLowerCase() === match.id)?.active;
        markers.set(item2.id, { state: retired ? "conflict" : "existing", label: retired ? "RETIRED MATERIAL \u2014 REVIEW" : "MATERIAL ALREADY EXISTS", detail: retired ? "Existing material is retired; review before publishing." : "Existing generic material will be reused." });
      }
    } catch (error) {
      markers.set(item2.id, { state: "conflict", label: "CATALOG CONFLICT", detail: issue(error) });
    }
  }
  const products = yield { text: "SELECT p.id,p.material_id,p.normalized_part,p.active,p.details_json,m.normalized FROM manufacturer_products p JOIN manufacturers m ON m.id=p.manufacturer_id AND m.tenant=p.tenant WHERE p.tenant=@p0", values: [p.tenant] };
  const pendingKeys = new Set(payload.items.filter((item2) => item2.kind === "material" && item2.state === "unpublished").map((item2) => norm3(item2.fields.externalKey ?? "")));
  for (const material of knownMaterials) if (!pendingKeys.has(norm3(material.external_key))) materialIds.set(norm3(material.external_key), String(material.id).toLowerCase());
  for (const item2 of payload.items) {
    if (item2.kind !== "product" || item2.state !== "unpublished") continue;
    const f = item2.fields, prior = products.find((product) => manufacturerIdentity(product.normalized) === manufacturerIdentity(f.manufacturer ?? "") && product.normalized_part === norm3(f.partNumber ?? ""));
    if (!prior) continue;
    const target = materialIds.get(norm3(f.materialKey ?? ""));
    let conflict = !prior.active ? "Existing product is retired." : target && String(prior.material_id).toLowerCase() !== target ? "Manufacturer part belongs to different material specifications." : !target ? "Resolve material specifications before confirming this existing product." : "";
    if (!conflict && parsed.has(item2.id)) {
      const before = JSON.parse(prior.details_json ?? "{}");
      for (const [key3, value] of Object.entries(parsed.get(item2.id).details ?? {})) if (Object.hasOwn(before, key3) && before[key3] !== value) {
        conflict = "Existing product detail " + key3 + " differs; review before replacing it.";
        break;
      }
    }
    markers.set(item2.id, { state: conflict ? "conflict" : "existing", label: conflict ? "EXISTING PRODUCT \u2014 REVIEW" : "PRODUCT ALREADY EXISTS", detail: conflict || "Same manufacturer and part number. Existing product will be reused; missing details may be added." });
  }
  return { id: id2, state: row2.state, filename: payload.filename, research: payload.research, version: report.version, createdAt: row2.created_at, items: payload.items.map((item2) => ({ ...item2, catalogMatch: markers.get(item2.id), error: errors.get(item2.id) ?? "", description: item2.kind === "material" && parsed.has(item2.id) ? parsed.get(item2.id).displayDescription ?? describeMaterial(parsed.get(item2.id)).description : "" })) };
}
function* save(p, id2, payload, version) {
  const remaining = payload.items.some((i) => i.state === "unpublished");
  yield { text: "UPDATE catalog_batches SET csv=@p0,report=@p1,state=@p2 WHERE tenant=@p3 AND id=@p4", values: [JSON.stringify(payload), JSON.stringify(summary(payload, version)), remaining ? "unpublished" : "reviewed", p.tenant, id2] };
}
function* inboxAction(p, action, data) {
  admin(p);
  if (action === "inbox-stage") {
    const payload2 = payloadSchema.parse(data);
    if (payload2.items.some((i) => i.state !== "unpublished")) throw new ApiError(400, "New uploads must be unpublished.");
    if (Buffer.byteLength(JSON.stringify(payload2)) > 25e5) throw new ApiError(413, "Use a smaller workbook.");
    const digest4 = createHash3("sha256").update(marker + JSON.stringify({ filename: payload2.filename, items: payload2.items.map(({ id: _id, ...item2 }) => item2), ...payload2.research ? { research: payload2.research } : {} })).digest("hex");
    const prior = (yield { text: "SELECT id FROM catalog_batches WHERE tenant=@p0 AND digest=@p1", values: [p.tenant, digest4] })[0];
    if (prior) return yield* view(p, String(prior.id).toLowerCase());
    const id2 = randomUUID4();
    yield { text: "INSERT INTO catalog_batches(id,tenant,digest,state,csv,report,created_at) VALUES(@p0,@p1,@p2,'unpublished',@p3,@p4,@p5)", values: [id2, p.tenant, digest4, JSON.stringify(payload2), JSON.stringify(summary(payload2, 1)), (/* @__PURE__ */ new Date()).toISOString()] };
    yield* audit2(p, "catalog.upload_unpublished", id2);
    return yield* view(p, id2);
  }
  if (action === "inbox-list") {
    const rows = yield { text: "SELECT * FROM (SELECT id,state,report,created_at,ROW_NUMBER() OVER(ORDER BY created_at DESC,id DESC) AS queue_row FROM catalog_batches WHERE tenant=@p0 AND state IN ('unpublished','reviewed')) paged WHERE queue_row<=100 ORDER BY queue_row", values: [p.tenant] };
    return { imports: rows.filter((row2) => JSON.parse(row2.report).workflow === marker).map((row2) => ({ id: String(row2.id).toLowerCase(), state: row2.state, createdAt: row2.created_at, ...JSON.parse(row2.report) })) };
  }
  const input2 = z8.object({ id: z8.uuid(), version: z8.number().int().positive().optional(), itemId: z8.uuid().optional(), images: z8.array(z8.object({ itemId: z8.uuid(), url: z8.string().max(2e3) }).strict()).max(100).optional(), fields: fields3.optional(), changes: z8.array(z8.object({ itemId: z8.uuid(), fields: fields3 })).max(2e3).optional(), itemIds: z8.array(z8.uuid()).min(1).max(2e3).optional(), approval: z8.string().optional(), planHash: z8.string().optional() }).strict().parse(data);
  if (action === "inbox-get") return yield* view(p, input2.id);
  const { report, payload } = yield* load(p, input2.id);
  if (report.version !== input2.version) throw new ApiError(409, "This import changed. Reload it before editing or publishing.");
  if (action === "inbox-image-target") {
    const item2 = payload.items.find((row2) => row2.id === input2.itemId && row2.state === "published" && (row2.kind === "material" || row2.kind === "product"));
    if (!item2) throw new ApiError(409, "Publish this item before attaching its image.");
    if (item2.kind === "material") {
      const result = yield* createMaterial(p, parse2(item2), true);
      if (!result.id) throw new ApiError(404, "Published material not found.");
      return { materialId: result.id, productId: null, sourceUrl: item2.fields.sourceUrl };
    }
    const rows = yield { text: "SELECT p.id,p.material_id,p.part_number,m.name FROM manufacturer_products p JOIN manufacturers m ON m.id=p.manufacturer_id AND m.tenant=p.tenant JOIN materials a ON a.id=p.material_id AND a.tenant=p.tenant WHERE p.tenant=@p0 AND LOWER(a.external_key)=LOWER(@p1) AND p.active=1", values: [p.tenant, item2.fields.materialKey] };
    const norm3 = (value) => value.normalize("NFKC").trim().toLowerCase().replace(/\s+/g, " ");
    const product = rows.find((row2) => manufacturerIdentity(row2.name) === manufacturerIdentity(item2.fields.manufacturer) && norm3(row2.part_number) === norm3(item2.fields.partNumber));
    if (!product) throw new ApiError(404, "Published manufacturer product not found.");
    return { materialId: String(product.material_id).toLowerCase(), productId: String(product.id).toLowerCase(), sourceUrl: item2.fields.sourceUrl };
  }
  if (action === "inbox-save") {
    if (!input2.changes?.length && !input2.images?.length) throw new ApiError(400, "No edited rows.");
    for (const change of input2.changes ?? []) {
      const item2 = payload.items.find((i) => i.id === change.itemId);
      if (!item2 || item2.state !== "unpublished") throw new ApiError(409, "Only unpublished records can be edited.");
      item2.fields = change.fields;
    }
    for (const change of input2.images ?? []) {
      const product = payload.items.find((i) => i.id === change.itemId && (i.kind === "product" || i.kind === "material") && i.state === "unpublished");
      if (!product) throw new ApiError(409, "Only unpublished material or product images can be edited.");
      const link = change.url.trim() ? publicSourceUrl(change.url.trim()).href : "";
      const related = payload.items.filter((i) => i.kind === "image" && i.state === "unpublished" && i.fields.materialKey === (product.kind === "material" ? product.fields.externalKey : product.fields.materialKey) && i.fields.manufacturer === product.fields.manufacturer && i.fields.partNumber === product.fields.partNumber);
      for (const image of related) image.state = "deleted";
      if (link) {
        if (payload.items.length >= 2e3) throw new ApiError(413, "Import has too many rows.");
        payload.items.push({ id: randomUUID4(), kind: "image", sheet: "Admin image", row: payload.items.length + 2, state: "unpublished", fields: { kind: "image", materialKey: product.kind === "material" ? product.fields.externalKey : product.fields.materialKey, ...product.kind === "product" ? { manufacturer: product.fields.manufacturer, partNumber: product.fields.partNumber } : {}, sourceUrl: link, rightsBasis: "Administrator supplied image reference; owner-managed use." } });
      }
    }
    yield* save(p, input2.id, payload, report.version + 1);
    yield* audit2(p, "catalog.unpublished_edited", input2.id);
    return yield* view(p, input2.id);
  }
  if (action === "inbox-edit") {
    const item2 = payload.items.find((i) => i.id === input2.itemId);
    if (!item2 || item2.state !== "unpublished" || !input2.fields) throw new ApiError(409, "Only unpublished records can be edited.");
    item2.fields = input2.fields;
    yield* save(p, input2.id, payload, report.version + 1);
    yield* audit2(p, "catalog.unpublished_edited", input2.id);
    return yield* view(p, input2.id);
  }
  if (!input2.itemIds) throw new ApiError(400, "Select records to review.");
  let chosen = payload.items.filter((i) => input2.itemIds.includes(i.id));
  if (chosen.length !== input2.itemIds.length || chosen.some((i) => i.state !== "unpublished")) throw new ApiError(409, "Selection includes unavailable records.");
  if (action === "inbox-plan") return yield* publicationPlan(p, input2.id, report.version, payload.items, input2.itemIds, parse2);
  if (action === "inbox-delete") {
    for (const item2 of chosen) item2.state = "deleted";
    yield* save(p, input2.id, payload, report.version + 1);
    yield* audit2(p, "catalog.unpublished_deleted", input2.id);
    return yield* view(p, input2.id);
  }
  if (action !== "inbox-publish" && action !== "inbox-publish-ready") throw new ApiError(404, "Unknown unpublished import operation.");
  if (input2.approval !== "I approve and publish these records") throw new ApiError(400, "Explicit publishing approval required.");
  let plan = null;
  if (action === "inbox-publish-ready") {
    plan = yield* publicationPlan(p, input2.id, report.version, payload.items, input2.itemIds, parse2);
    if (!input2.planHash || input2.planHash !== plan.planHash) throw new ApiError(409, "Publication review changed. Refresh the publication check and approve again.");
    if (!plan.readyIds.length) throw new ApiError(400, "No selected records are ready to publish. Review the held rows.");
    chosen = payload.items.filter((item2) => plan.readyIds.includes(item2.id));
  }
  const order = { material: 0, product: 1, translation: 2, image: 3 }, ordered = chosen.sort((a, b) => order[a.kind] - order[b.kind]);
  let created = 0, unchanged = 0;
  const keyMap = /* @__PURE__ */ new Map();
  for (const item2 of ordered) {
    try {
      const value = parse2(item2);
      if (item2.kind === "material") {
        const result = yield* createMaterial(p, value);
        const row2 = (yield { text: "SELECT external_key FROM materials WHERE tenant=@p0 AND id=@p1", values: [p.tenant, result.id] })[0];
        keyMap.set(value.externalKey.toLowerCase(), String(row2.external_key));
        for (const related of payload.items) if (related.kind !== "material" && related.state === "unpublished" && related.fields.materialKey?.toLowerCase() === value.externalKey.toLowerCase()) related.fields.materialKey = String(row2.external_key);
        if (result.unchanged) unchanged++;
        else created++;
      } else {
        value.materialKey = keyMap.get(value.materialKey.toLowerCase()) ?? value.materialKey;
        const result = item2.kind === "product" ? yield* addProduct(p, value) : item2.kind === "image" ? yield* addImageReference(p, { ...value, rightsBasis: ("Owner-managed image usage. Imported note: " + value.rightsBasis).slice(0, 2e3) }, false, input2.id) : yield* addTranslation(p, value, false, input2.id);
        if (item2.kind === "image") {
          if (!value.manufacturer) {
            const image = (yield { text: "SELECT material_id FROM image_references WHERE tenant=@p0 AND id=@p1", values: [p.tenant, result.id] })[0];
            yield { text: "UPDATE image_references SET status='rejected' WHERE tenant=@p0 AND material_id=@p1 AND product_id IS NULL AND id<>@p2 AND status='approved'", values: [p.tenant, image.material_id, result.id] };
          }
          yield { text: "UPDATE image_references SET status='approved' WHERE tenant=@p0 AND id=@p1", values: [p.tenant, result.id] };
          yield* audit2(p, "image.owner_published_reference", result.id);
        }
        if (result.unchanged) unchanged++;
        else created++;
      }
      item2.state = "published";
    } catch (error) {
      throw new ApiError(409, `${item2.sheet} row ${item2.row}: ${issue(error)}. No records in this publication were changed.`);
    }
  }
  yield* save(p, input2.id, payload, report.version + 1);
  yield* audit2(p, "catalog.import_published", input2.id);
  return { ...yield* view(p, input2.id), publication: { created, unchanged, ...plan ? { selectedPublished: plan.selectedReady, held: plan.held.length, dependencies: plan.dependencies.length } : {} } };
}

// server/material-workbook-data.ts
function materialWorkbookRows(tables) {
  const key3 = (v) => String(v ?? "").toLowerCase(), profiles = new Map((tables.catalog_profiles ?? []).map((p) => [key3(p.material_id), p]));
  return (tables.materials ?? []).filter((m) => Boolean(m.active)).map((m) => {
    const p = profiles.get(key3(m.id)), details2 = JSON.parse(m.details ?? "{}"), a = p ? JSON.parse(p.attributes) : {}, row2 = { key: m.external_key, description: m.description, category: a.category ?? details2.category ?? "general", unit: m.product_uom, type: String(a.type ?? ""), familyId: String(a.familyId ?? inferredFamily(a)?.id ?? ""), configurationStatus: String(a.configurationStatus ?? "existing"), phrases: [...new Set((tables.translations ?? []).filter((t) => key3(t.material_id) === key3(m.id) && t.active).map((t) => t.phrase).concat((tables.aliases ?? []).filter((t) => key3(t.material_id) === key3(m.id)).map((t) => t.phrase ?? t.normalized)))].join("\n"), source: details2.row?.source_url ?? "", notes: details2.row?.verification_basis ?? "", image: selectImage((tables.image_references ?? []).filter((i) => key3(i.material_id) === key3(m.id) && !i.product_id && i.status === "approved"), null)?.source_url ?? "", status: p ? "Existing \u2014 editable by material key" : "Existing \u2014 legacy specifications need review" };
    const known = new Set(materialWorkbookColumns.map((c) => String(c[1])));
    for (const [, field2] of materialWorkbookColumns) if (a[field2] !== void 0) row2[field2] = typeof a[field2] === "number" && field2.endsWith("In") ? field2 === "lengthIn" && a.category === "conduit" && Number(a[field2]) % 12 === 0 ? `${Number(a[field2]) / 12} ft` : formatInches(a[field2]) : String(a[field2]);
    row2.extra = Object.entries(a).filter(([k]) => !known.has(k) && !["category", "recordOrigin"].includes(k)).map(([k, v]) => k + "=" + String(v)).join("\n");
    return row2;
  }).sort((a, b) => a.category.localeCompare(b.category) || a.description.localeCompare(b.description));
}

// server/material-workbook.ts
var digest = (v) => createHash4("sha256").update(JSON.stringify(v)).digest("hex");
var norm2 = (v) => v.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
function dimension(value, length = false) {
  let v = value.trim(), factor = 1;
  if (length && /(?:ft|feet|foot|')\s*$/i.test(v)) {
    factor = 12;
    v = v.replace(/(?:ft|feet|foot|')\s*$/i, "").trim();
  } else v = v.replace(/(?:inches|inch|in|["″])\s*$/i, "").trim();
  const n = parseInches(v.replace(/^(\d+)-(\d+\/\d+)$/, "$1 $2"));
  if (!Number.isFinite(n) || n <= 0) throw Error("Enter a positive decimal or fraction measurement.");
  return n * factor;
}
function* materialWorkbookAction(p, action, data) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
  if (action === "material-workbook-export") {
    const tables = {};
    for (const table of ["materials", "catalog_profiles", "translations", "aliases", "image_references"]) tables[table] = yield { text: `SELECT * FROM ${table} WHERE ${table === "aliases" ? "material_id IN (SELECT id FROM materials WHERE tenant=@p0)" : "tenant=@p0"}`, values: [p.tenant] };
    return { rows: materialWorkbookRows(tables) };
  }
  const input2 = z9.object({ filename: z9.string().max(200), rows: z9.array(z9.record(z9.string(), z9.string().max(2e4))).min(1).max(1e3), previewHash: z9.string().length(64).optional() }).strict().parse(data), categories = yield* materialCategories(p), existing = yield { text: "SELECT * FROM materials WHERE tenant=@p0", values: [p.tenant] }, results = [], pending = /* @__PURE__ */ new Map(), seen = /* @__PURE__ */ new Map(), seenKeys = /* @__PURE__ */ new Map(), updates = [];
  const profiles = yield { text: "SELECT * FROM catalog_profiles WHERE tenant=@p0", values: [p.tenant] };
  const translations = yield { text: "SELECT * FROM translations WHERE tenant=@p0", values: [p.tenant] };
  const aliases = yield { text: "SELECT * FROM aliases WHERE material_id IN (SELECT id FROM materials WHERE tenant=@p0)", values: [p.tenant] };
  const imageReferences = yield { text: "SELECT * FROM image_references WHERE tenant=@p0", values: [p.tenant] };
  const exported = materialWorkbookRows({ materials: existing, catalog_profiles: profiles, translations, aliases, image_references: imageReferences });
  for (const [index, raw] of input2.rows.entries()) {
    const row2 = { ...raw };
    const line2 = { row: Number(row2._row) || index + 2, description: row2.description || row2.type || row2.key || "Unnamed material", status: "New", reason: "" };
    results.push(line2);
    const byKey = row2.key ? existing.find((m) => norm2(m.external_key) === norm2(row2.key)) : void 0;
    if (row2.key && input2.rows.filter((r) => r.key && norm2(r.key) === norm2(row2.key)).length > 1) {
      line2.status = "Needs correction";
      line2.reason = "Material key appears more than once. Keep one row per material key.";
      continue;
    }
    if (byKey && !byKey.active) {
      line2.status = "Needs correction";
      line2.reason = "Retired material: review its active replacement.";
      continue;
    }
    const original = { ...row2 };
    if (byKey) {
      const baseline = exported.find((r) => norm2(r.key) === norm2(row2.key));
      for (const [, field2] of materialWorkbookColumns) {
        if (!row2[field2]) row2[field2] = baseline[field2] ?? "";
        if (row2[field2] === "[CLEAR]") row2[field2] = "";
      }
      row2.key = byKey.external_key;
    }
    try {
      const family2 = materialFamily(row2.familyId);
      if (row2.familyId && !family2) throw Error("Choose a Material Family from the Family Reference sheet.");
      if (!byKey && family2) {
        if (row2.configurationStatus !== "confirmed") throw Error("Research needed: confirm this exact configuration and set Configuration Status to confirmed.");
        if (!row2.source || !row2.notes) throw Error("Confirmed new configurations require an Evidence URL and Notes identifying the relevant source section.");
      }
      if (byKey && row2.configurationStatus && row2.configurationStatus !== "confirmed" && row2.configurationStatus !== "existing") throw Error("Existing materials cannot be made unconfirmed through bulk update. Review them separately.");
      if (row2.configurationStatus === "existing") delete row2.configurationStatus;
      const category = categories.find((c) => [c.id, c.name].some((v) => norm2(v).replace(/[_/ -]+/g, "") === norm2(row2.category ?? "").replace(/[_/ -]+/g, "")));
      if (!category) throw Error("Choose an existing category, or add it under Materials \u2192 Manage categories.");
      if (!row2.description && !family2) throw Error("Description is required for rows without a material family.");
      if (family2 && !row2.type) row2.type = family2.type;
      if (!row2.unit) throw Error("An MRF ordering unit is required (EA, FT, STICK, BOX, ROLL or PAIR).");
      const attrs = {};
      for (const [, field2] of materialWorkbookColumns) {
        if (["key", "description", "category", "unit", "extra", "phrases", "image", "source", "notes", "status"].includes(field2) || !row2[field2]) continue;
        attrs[field2] = field2.endsWith("In") ? dimension(row2[field2], field2 === "lengthIn") : field2 === "angleDeg" ? Number(row2[field2]) : row2[field2];
      }
      for (const extra of (row2.extra ?? "").split(/\r?\n/).filter((v) => v.trim())) {
        const at = extra.indexOf("=");
        if (at < 1) throw Error("Other Specifications: use one key=value per line.");
        const name4 = extra.slice(0, at).trim(), value = extra.slice(at + 1).trim();
        if (!/^[a-zA-Z][a-zA-Z0-9]{0,39}$/.test(name4) || !value) throw Error("Other Specifications needs a valid field name and a value.");
        if (Object.hasOwn(attrs, name4)) throw Error("Specification " + name4 + " appears twice.");
        const definition = category.fields.find((f) => f.key === name4), familyField = family2?.fields.find((f) => f.key === name4), kind = familyField?.kind ?? definition?.type;
        attrs[name4] = ["diameterIn", "lengthIn", "minSpanIn", "maxSpanIn", "widthIn", "heightIn", "depthIn"].includes(name4) ? dimension(value, name4 === "lengthIn") : kind === "inches" ? dimension(value) : kind === "number" ? Number(value) : value;
      }
      const material = materialInput.parse({ externalKey: row2.key || "BULK-" + digest({ category: category.id, unit: row2.unit, attrs }).slice(0, 24), ...row2.description ? { displayDescription: row2.description } : {}, category: category.id, productUnit: row2.unit.toUpperCase(), attributes: attrs, verification: "provisional", origin: "admin_reviewed", sourceUrl: row2.source ? publicSourceUrl(row2.source).href : "", verificationBasis: row2.notes || "Material workbook entered by catalog administrator; specifications require review." }), built = describeMaterial(material);
      yield* validateMaterialCategory(p, material);
      if (!row2.description) {
        row2.description = built.description;
        material.displayDescription = built.description;
        line2.description = built.description;
      }
      const collision = profiles.find((q6) => materialIdentity(JSON.parse(q6.attributes).category, existing.find((m) => String(m.id).toLowerCase() === String(q6.material_id).toLowerCase())?.product_uom ?? "", JSON.parse(q6.attributes)) === built.identity && String(q6.material_id).toLowerCase() !== String(byKey?.id ?? "").toLowerCase());
      if (byKey && collision) throw Error("These specifications already belong to another material. Review the duplicate instead of overwriting it.");
      if (byKey) {
        const previous = profiles.find((q6) => String(q6.material_id).toLowerCase() === String(byKey.id).toLowerCase());
        if (previous && materialIdentity(JSON.parse(previous.attributes).category, byKey.product_uom, JSON.parse(previous.attributes)) !== built.identity) {
          const products = yield { text: "SELECT id FROM manufacturer_products WHERE tenant=@p0 AND material_id=@p1 AND active=1", values: [p.tenant, byKey.id] };
          if (products.length) throw Error("Physical specifications changed on a material with linked manufacturer products. Use reviewed material correction to verify those links. Description-only edits remain supported.");
        }
      }
      const match = byKey ? { id: byKey.id } : yield* createMaterial(p, material, true);
      if (seen.has(built.identity)) {
        line2.status = "Duplicate in workbook";
        line2.reason = "Same configuration as row " + results[seen.get(built.identity)].row + "; skipped.";
        continue;
      }
      if (row2.key) {
        const prior = seenKeys.get(norm2(row2.key));
        if (prior && prior.identity !== built.identity) {
          results[prior.index].status = "Needs correction";
          results[prior.index].reason = "This key is used for different specifications in the workbook.";
          pending.delete(prior.index);
          throw Error("This key is used for different specifications in the workbook.");
        }
        seenKeys.set(norm2(row2.key), { identity: built.identity, index });
      }
      if (byKey) {
        if (!profiles.some((q6) => String(q6.material_id).toLowerCase() === String(byKey.id).toLowerCase())) throw Error("Legacy material needs specification review before bulk updating.");
        if (seenKeys.has("update:" + norm2(row2.key))) throw Error("The workbook contains this existing material key more than once.");
        seenKeys.set("update:" + norm2(row2.key), { identity: built.identity, index });
        const profile = profiles.find((q6) => String(q6.material_id).toLowerCase() === String(byKey.id).toLowerCase()), old = JSON.parse(byKey.details), baseline = exported.find((r) => norm2(r.key) === norm2(row2.key));
        const baselinePhrases = new Set((baseline.phrases ?? "").split(/[;\r\n]+/).map(norm2));
        const changes = Object.fromEntries(materialWorkbookColumns.filter(([, f]) => !["key", "status"].includes(f) && original[f] && original[f] !== baseline[f] && (f !== "phrases" || original[f] === "[CLEAR]" || original[f].split(/[;\r\n]+/).some((v) => v.trim() && !baselinePhrases.has(norm2(v))))).map(([label, f]) => [label, { before: baseline[f] ?? "", after: original[f] === "[CLEAR]" ? "" : original[f] }]));
        if (!Object.keys(changes).length) {
          line2.status = "Unchanged";
          continue;
        }
        if (original.image === "[CLEAR]" || original.phrases === "[CLEAR]") throw Error("Use the image/phrase editor to remove an existing image or search phrase.");
        if (changes["Image URL"]) {
          const imageUrl = publicSourceUrl(row2.image).href;
          pending.set(index, [{ id: randomUUID5(), kind: "image", sheet: "Materials", row: line2.row, fields: { kind: "image", materialKey: material.externalKey, sourceUrl: imageUrl, rightsBasis: ("Administrator-reviewed representative generic material image. " + row2.notes).slice(0, 2e3) }, state: "unpublished" }]);
        }
        if ((original.phrases ?? "").split(/[;\r\n]+/).some((v) => v.trim().length > 500)) throw Error("Each search phrase must be 500 characters or fewer.");
        line2.status = "Updated";
        Object.assign(line2, { changes });
        seen.set(built.identity, index);
        updates.push({ index, material, built, before: byKey, profile, old, descriptionOnly: Object.keys(changes).every((k) => ["Description *", "Search Phrases", "Image URL"].includes(k)), phrases: original.phrases ? row2.phrases.split(/[;\r\n]+/).map((v) => v.trim()).filter(Boolean) : [] });
        continue;
      }
      if (match.id) {
        line2.status = "Already exists";
        line2.reason = "Matching material specifications and unit already exist; skipped.";
        continue;
      }
      if (seen.has(built.identity)) {
        line2.status = "Duplicate in workbook";
        line2.reason = "Same specifications and unit as row " + results[seen.get(built.identity)].row + "; skipped.";
        continue;
      }
      const fields4 = { externalKey: material.externalKey, displayDescription: material.displayDescription, category: material.category, productUnit: material.productUnit, verification: "provisional", origin: "admin_reviewed", sourceUrl: material.sourceUrl, verificationBasis: material.verificationBasis };
      for (const [k, v] of Object.entries(material.attributes)) fields4[materialColumns.includes(k) ? k : "attribute." + k] = String(v);
      const entries = [];
      const add = (kind, values) => entries.push({ id: randomUUID5(), kind, sheet: "Materials", row: line2.row, fields: { kind, ...values }, state: "unpublished" });
      add("material", fields4);
      const phrases = [...new Set([row2.description, ...(row2.phrases ?? "").split(/[;\r\n]+/)].map((v) => v.trim()).filter(Boolean))];
      for (const phrase of phrases) {
        if (phrase.length > 500) throw Error("Each search phrase must be 500 characters or fewer.");
        add("translation", { materialKey: material.externalKey, phrase, origin: "admin_reviewed", ...material.sourceUrl ? { sourceUrl: material.sourceUrl } : {} });
      }
      if (row2.image) add("image", { materialKey: material.externalKey, sourceUrl: publicSourceUrl(row2.image).href, rightsBasis: ("Administrator-reviewed representative generic material image. " + row2.notes).slice(0, 2e3) });
      pending.set(index, entries);
      seen.set(built.identity, index);
    } catch (error) {
      line2.status = "Needs correction";
      line2.reason = error instanceof z9.ZodError ? error.issues.map((i) => i.path.join(".") + ": " + i.message).slice(0, 3).join("; ") : error instanceof Error ? error.message : "Invalid material.";
    }
  }
  const summary2 = { updated: results.filter((r) => r.status === "Updated").length, unchanged: results.filter((r) => r.status === "Unchanged").length, new: results.filter((r) => r.status === "New").length, existing: results.filter((r) => r.status === "Already exists").length, duplicates: results.filter((r) => r.status === "Duplicate in workbook").length, errors: results.filter((r) => r.status === "Needs correction").length }, previewHash = digest({ tenant: p.tenant, rows: input2.rows, results, existing: [...existing].sort((a, b) => String(a.id).localeCompare(String(b.id))), profiles: [...profiles].sort((a, b) => String(a.material_id).localeCompare(String(b.material_id))), translations: [...translations].sort((a, b) => String(a.id).localeCompare(String(b.id))), aliases: [...aliases].sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b))), images: [...imageReferences].sort((a, b) => String(a.id).localeCompare(String(b.id))) });
  if (action === "material-workbook-preview") return { summary: summary2, results, previewHash };
  if (!["material-workbook-stage", "material-workbook-apply"].includes(action)) throw new ApiError(404, "Unknown material workbook operation.");
  if (input2.previewHash !== previewHash) throw new ApiError(409, "The workbook or catalog changed. Check the workbook preview again before sending new materials.");
  if (updates.some((u) => u.phrases.some((v) => v.length > 500))) throw new ApiError(400, "Each search phrase must be 500 characters or fewer.");
  if (results.some((r) => r.status === "Needs correction")) throw new ApiError(400, "Resolve all rows needing correction, or remove them from this upload, before applying the workbook.");
  const items = [...pending.entries()].filter(([i]) => ["New", "Updated"].includes(results[i].status)).flatMap(([, v]) => v);
  if (!items.length && !updates.length) throw new ApiError(400, "No new valid materials to send for approval.");
  if (items.length > 2e3) throw new ApiError(413, "Too many supporting phrases or images for one review batch. Split the workbook into smaller batches.");
  if (updates.length && action !== "material-workbook-apply") throw new ApiError(400, "Use Apply reviewed workbook to confirm the preview and apply updates.");
  for (const u of updates) {
    if (results[u.index].status !== "Updated") continue;
    const m = u.material, specs = Object.entries(m.attributes).map(([k, v]) => `${k}: ${v}`), details2 = { ...u.old, displayDescription: m.displayDescription, row: { ...u.old.row, description: m.displayDescription, product_uom: m.productUnit, requested_uom: m.productUnit, source_url: m.sourceUrl, verification_basis: m.verificationBasis, specifications_json: JSON.stringify(specs) }, specs };
    yield { text: "UPDATE materials SET description=@p0,product_uom=@p1,details=@p2 WHERE tenant=@p3 AND id=@p4", values: [m.displayDescription, m.productUnit, JSON.stringify(details2), p.tenant, u.before.id] };
    if (!u.profile) throw new ApiError(409, "Legacy material needs specification review before bulk updating.");
    yield { text: "UPDATE catalog_profiles SET identity_key=@p0,attributes=@p1,verification=@p2 WHERE tenant=@p3 AND material_id=@p4", values: [u.built.identity, JSON.stringify({ category: m.category, ...m.attributes, recordOrigin: "admin_reviewed" }), u.descriptionOnly ? u.profile.verification : "provisional", p.tenant, u.before.id] };
    for (const phrase of u.phrases) yield* addTranslation(p, { materialKey: m.externalKey, phrase, origin: "admin_reviewed" });
    const revision2 = randomUUID5();
    yield { text: "INSERT INTO catalog_revisions(id,tenant,kind,entity_id,replacement_id,before_json,after_json,reason,actor,created_at,request_key) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10)", values: [revision2, p.tenant, "material", u.before.id, null, JSON.stringify({ material: u.before, profile: u.profile }), JSON.stringify(m), "Administrator reviewed material workbook: " + input2.filename, p.oid, (/* @__PURE__ */ new Date()).toISOString(), digest({ previewHash, key: m.externalKey })] };
    yield { text: "INSERT INTO audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", values: [randomUUID5(), p.tenant, p.oid, "catalog.workbook_updated", u.before.id, (/* @__PURE__ */ new Date()).toISOString()] };
  }
  const batch = items.length ? yield* inboxAction(p, "inbox-stage", { filename: input2.filename, items }) : {};
  return { ...batch, workbookSummary: summary2 };
}

// src/document-layout.ts
import { z as z10 } from "zod";
var bindings = { "company.name": "Company name", "mrf.number": "MRF number", "mrf.date": "Request date", "mrf.name": "MRF name", "job.name": "Job name", "job.number": "Job number", "job.address": "Ship-to address", "requester.name": "Prepared by / Foreman", "requester.phone": "Preparer phone", "requester.email": "Preparer email", "foreman.name": "Requested-for foreman", "job.purchasingAgentName": "Purchasing agent", "job.deliveryContactName": "Delivery contact", "job.deliveryContactPhone": "Delivery contact phone", "job.receivingHours": "Receiving hours", "mrf.deliveryDate": "Delivery date", "form.workArea": "Work area", "form.defaultTaskCode": "Default task code", "form.packagingMethod": "Packaging method", "form.specialPackagingInstructions": "Special packaging instructions", "form.deliveryInstructions": "Delivery instructions", "form.purchasingNotes": "Purchasing notes", "item.number": "Item number", "item.quantityUom": "Quantity / UOM", "item.quantity": "Quantity", "item.unit": "Unit", "item.description": "Item description", "item.manufacturer": "Manufacturer", "item.partNumber": "Part number", "item.manufacturerPart": "Manufacturer / Part / substitution", "item.taskCode": "Item task override", "item.deliveryDate": "Item delivery date", "item.foreman": "Item foreman", "item.noSubstitutions": "No Substitutions checkbox", "item.image": "Item image", "page.count": "Page X of Y", "template.version": "Template version" };
var cellSchema = z10.object({ id: z10.string().regex(/^[\w-]{1,80}$/), row: z10.number().int().min(0).max(39), col: z10.number().int().min(0).max(15), rowSpan: z10.number().int().min(1).max(40).default(1), colSpan: z10.number().int().min(1).max(16).default(1), kind: z10.enum(["empty", "text", "field", "logo", "items"]).default("empty"), text: z10.string().max(4e3).default(""), binding: z10.enum(Object.keys(bindings)).default("job.name"), label: z10.string().max(100).default(""), font: z10.enum(["Helvetica", "Times", "Courier"]).default("Helvetica"), fontSize: z10.number().min(6).max(48).default(9), bold: z10.boolean().default(false), italic: z10.boolean().default(false), align: z10.enum(["left", "center", "right"]).default("left"), verticalAlign: z10.enum(["top", "middle", "bottom"]).default("top"), borderSides: z10.object({ top: z10.boolean(), right: z10.boolean(), bottom: z10.boolean(), left: z10.boolean() }).strict().optional(), borderWeight: z10.number().min(0.25).max(6).default(0.4), padding: z10.number().min(0).max(20).default(3), imageScale: z10.number().min(10).max(100).default(100), border: z10.boolean().default(true), background: z10.string().regex(/^#[a-f\d]{6}$/i).default("#ffffff"), editable: z10.boolean().default(true), hideEmpty: z10.boolean().default(false) }).strict();
var gridSchema = z10.object({ emptyBorder: z10.boolean().optional(), defaultFontSize: z10.number().min(6).max(48).optional(), rowModes: z10.array(z10.enum(["auto", "locked"])).min(1).max(40).optional(), rowBaseHeight: z10.number().min(12).max(2e3).optional(), columns: z10.number().int().min(2).max(16), columnWidths: z10.array(z10.number().min(10).max(1e3)).min(2).max(16).optional(), rows: z10.array(z10.number().min(12).max(2e3)).min(1).max(40), cells: z10.array(cellSchema).max(640) }).strict().superRefine((grid, ctx) => {
  if (grid.columnWidths && grid.columnWidths.length !== grid.columns) ctx.addIssue({ code: "custom", message: "Column widths must match the column count." });
  if (grid.rowModes && grid.rowModes.length !== grid.rows.length) ctx.addIssue({ code: "custom", message: "Row modes must match the row count." });
  const occupied = /* @__PURE__ */ new Set(), ids2 = /* @__PURE__ */ new Set();
  for (const c of grid.cells) {
    if (ids2.has(c.id)) ctx.addIssue({ code: "custom", message: "Cell IDs must be unique." });
    ids2.add(c.id);
    if (c.row + c.rowSpan > grid.rows.length || c.col + c.colSpan > grid.columns) ctx.addIssue({ code: "custom", message: "Cell extends outside the grid." });
    for (let r = c.row; r < c.row + c.rowSpan; r++) for (let k = c.col; k < c.col + c.colSpan; k++) {
      const key3 = r + ":" + k;
      if (occupied.has(key3)) ctx.addIssue({ code: "custom", message: "Cells overlap." });
      occupied.add(key3);
    }
  }
});
var documentLayout = z10.object({ format: z10.literal("etalonops-grid-v1"), defaultFontSize: z10.number().min(6).max(48).default(9), paper: z10.enum(["Letter", "A4", "Legal"]), orientation: z10.enum(["portrait", "landscape"]), margins: z10.object({ top: z10.number().min(0).max(100), right: z10.number().min(0).max(100), bottom: z10.number().min(0).max(100), left: z10.number().min(0).max(100) }).strict(), first: gridSchema, continuation: gridSchema, item: gridSchema, footerNote: z10.string().max(300).default("Material request only \u2014 not a purchase order.") }).strict();
function paperSize(layout) {
  const size = layout.paper === "A4" ? [595.28, 841.89] : layout.paper === "Legal" ? [612, 1008] : [612, 792];
  return layout.orientation === "landscape" ? [size[1], size[0]] : size;
}
function cellRect(grid, cell, width) {
  const weights = grid.columnWidths ?? Array(grid.columns).fill(1), total = weights.reduce((a, b) => a + b, 0);
  return { x: weights.slice(0, cell.col).reduce((a, b) => a + b, 0) * width / total, y: grid.rows.slice(0, cell.row).reduce((a, b) => a + b, 0), width: weights.slice(cell.col, cell.col + cell.colSpan).reduce((a, b) => a + b, 0) * width / total, height: grid.rows.slice(cell.row, cell.row + cell.rowSpan).reduce((a, b) => a + b, 0) };
}
function blankCell(row2, col, extra = {}) {
  return cellSchema.parse({ id: crypto.randomUUID(), row: row2, col, ...extra });
}
function completeGrid(grid) {
  const cells = [...grid.cells];
  for (let row2 = 0; row2 < grid.rows.length; row2++) for (let col = 0; col < grid.columns; col++) if (!cells.some((c) => row2 >= c.row && row2 < c.row + c.rowSpan && col >= c.col && col < c.col + c.colSpan)) cells.push(blankCell(row2, col, { border: grid.emptyBorder ?? true, fontSize: grid.defaultFontSize ?? 9 }));
  return { ...grid, cells };
}
function validatePublishedLayout(input2) {
  const layout = documentLayout.parse(input2), [width, height] = paperSize(layout);
  for (const name4 of ["first", "continuation"]) {
    const grid = layout[name4], items = grid.cells.filter((c) => c.kind === "items");
    if (items.length !== 1) throw Error("Place exactly one MRF items table on each page layout.");
    if (grid.rows.reduce((a, b) => a + b, 0) > height - layout.margins.top - layout.margins.bottom + 0.1) throw Error("The " + name4 + " page grid exceeds the printable height.");
    const rect = cellRect(grid, items[0], width - layout.margins.left - layout.margins.right);
    if (rect.height < 60) throw Error("Allow at least 60 points for the repeating items table.");
  }
  if (layout.item.cells.some((c) => c.kind === "items" || c.kind === "logo")) throw Error("Item rows support text, fields and item images, not nested tables or company logos.");
  if (!layout.item.cells.some((c) => c.kind === "field" && c.binding === "item.description")) throw Error("The item template needs an Item description field.");
  return layout;
}
function cellBorders(cell) {
  return cell.borderSides ?? { top: cell.border, right: cell.border, bottom: cell.border, left: cell.border };
}

// src/document-sizing.ts
var rowMode = (grid, index) => grid.rowModes?.[index] ?? "locked";
var sum = (values) => values.reduce((a, b) => a + b, 0);
function requiredCellHeight(c, width, text4, measure) {
  if (c.kind === "empty" || c.kind === "logo" || c.kind === "items" || c.kind === "field" && c.binding === "item.image") return 0;
  if (c.hideEmpty && !text4) return 0;
  if (c.kind === "field" && c.binding === "item.noSubstitutions") return 12 + c.padding * 2 + (c.label ? 8 : 0);
  const available = Math.max(5, width - c.padding * 2);
  let count = 0;
  for (const paragraph of text4.split("\n")) {
    let current = "";
    for (const word of paragraph.split(/\s+/)) {
      const candidate2 = current ? current + " " + word : word;
      if (measure(candidate2) <= available) {
        current = candidate2;
        continue;
      }
      if (current) count++;
      current = "";
      for (const char of word) {
        if (current && measure(current + char) > available) {
          count++;
          current = "";
        }
        current += char;
      }
    }
    count++;
  }
  return Math.max(1, count) * c.fontSize * 1.2 + c.padding * 2 + (c.label ? 8 : 0) + (c.kind === "field" ? 4 : 2);
}
function editorMeasure(c, width) {
  if (["empty", "logo", "items"].includes(c.kind) || c.kind === "field" && c.binding === "item.image") return 0;
  const text4 = c.kind === "text" ? c.text.replace(/\{[^}]+\}/g, "Example") : "";
  let context = null;
  if (typeof document !== "undefined") {
    context = document.createElement("canvas").getContext("2d");
    if (context) context.font = `${c.italic ? "italic " : ""}${c.bold ? "bold " : ""}${c.fontSize}px ${c.font === "Times" ? "Times New Roman" : c.font === "Courier" ? "Courier New" : "Arial"}`;
  }
  return requiredCellHeight(c, width, text4, (t) => context ? context.measureText(t).width : [...t].reduce((n, ch) => n + c.fontSize * (c.font === "Courier" ? 0.6 : /[ilI.,' ]/.test(ch) ? 0.28 : /[MW@]/.test(ch) ? 0.85 : 0.53), 0));
}
function spareRow(grid, index) {
  return rowMode(grid, index) === "auto" && grid.cells.filter((c) => c.row <= index && c.row + c.rowSpan > index).every((c) => c.kind === "empty" && c.rowSpan === 1 && c.background === "#ffffff" && Object.values(cellBorders(c)).every((v) => v === (grid.emptyBorder ?? true)) && !c.bold && !c.italic);
}
function sizeGrid(input2, width, measure = editorMeasure, pageHeight) {
  if (!input2.rowModes) return { grid: input2, warnings: pageHeight !== void 0 && sum(input2.rows) > pageHeight + 0.1 ? ["Grid exceeds the page margins. Reduce row heights or unlock blank rows."] : [] };
  const base = input2.rowBaseHeight ?? Math.min(...input2.rows), rows = input2.rows.map((h, i) => rowMode(input2, i) === "auto" ? base : h);
  let grid = { ...input2, rows, rowModes: [...input2.rowModes] }, warnings = [];
  for (const c of grid.cells) {
    const rect = cellRect(grid, c, width), required = c.kind === "items" ? 60 : measure(c, rect.width), missing = required - rect.height;
    if (missing <= 0.1) continue;
    const auto = Array.from({ length: c.rowSpan }, (_, i) => c.row + i).filter((i) => rowMode(grid, i) === "auto");
    if (auto.length) {
      let left = missing;
      for (const i of auto) {
        const add = Math.min(2e3 - grid.rows[i], left / (auto.length - auto.indexOf(i)));
        grid.rows[i] += add;
        left -= add;
      }
      if (left > 0.1) warnings.push(`Row ${c.row + 1}: content exceeds the maximum automatic row height. Shorten the text or merge additional rows.`);
    } else warnings.push(`Row ${c.row + 1}: content needs ${Math.ceil(required)} pt, but its height is locked. Enlarge or unlock the row.`);
  }
  if (pageHeight !== void 0) {
    for (let i = grid.rows.length - 1; i >= 0 && sum(grid.rows) > pageHeight + 0.1; i--) {
      if (!spareRow(grid, i) || grid.rows.length === 1) continue;
      const excess = sum(grid.rows) - pageHeight;
      if (grid.rows[i] - excess >= 12) {
        grid.rows[i] -= excess;
        break;
      }
      grid = { ...grid, rows: grid.rows.filter((_, r) => r !== i), rowModes: grid.rowModes.filter((_, r) => r !== i), cells: grid.cells.filter((c) => c.row !== i).map((c) => c.row > i ? { ...c, row: c.row - 1 } : c) };
    }
    let free = pageHeight - sum(grid.rows);
    while (free >= base - 0.1 && grid.rows.length < 40) {
      grid = { ...grid, rows: [...grid.rows, base], rowModes: [...grid.rowModes, "auto"] };
      free -= base;
    }
    grid = completeGrid(grid);
    if (free > 0) {
      for (let i = grid.rows.length - 1; i >= 0; i--) if (spareRow(grid, i)) {
        grid.rows[i] += free;
        break;
      }
    }
    if (sum(grid.rows) > pageHeight + 0.1) warnings.push(`Not enough blank space: ${Math.ceil(sum(grid.rows) - pageHeight)} pt exceeds the page margins. Content is preserved. Shorten text, reduce padding, enlarge the page or unlock blank rows.`);
  }
  return { grid, warnings: [...new Set(warnings)] };
}
function sizeLayout(input2, measure = editorMeasure) {
  const [w, h] = paperSize(input2), width = w - input2.margins.left - input2.margins.right, height = h - input2.margins.top - input2.margins.bottom, first = sizeGrid(input2.first, width, measure, height), continuation = sizeGrid(input2.continuation, width, measure, height), item2 = sizeGrid(input2.item, width, measure);
  return { layout: { ...input2, first: first.grid, continuation: continuation.grid, item: item2.grid }, warnings: [...first.warnings.map((w2) => "First page: " + w2), ...continuation.warnings.map((w2) => "Continuation page: " + w2), ...item2.warnings.map((w2) => "Repeating item: " + w2)] };
}

// server/document-templates.ts
import { randomUUID as randomUUID6 } from "node:crypto";
import { z as z11 } from "zod";
init_contracts();
function* q3(text4, ...values) {
  return yield { text: text4, values };
}
function* audit3(p, action, target) {
  yield* q3("INSERT INTO audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", randomUUID6(), p.tenant, p.oid, action, target, (/* @__PURE__ */ new Date()).toISOString());
}
var key = z11.string().regex(/^[a-zA-Z0-9._-]{1,64}$/);
function* companyAccess(p, companyId) {
  const m = yield* manager(p);
  if (!m.root && companyId !== m.company) throw new ApiError(404, "Company not found.");
  if (!(yield* q3("SELECT id FROM companies WHERE tenant=@p0 AND id=@p1 AND active=1", p.tenant, companyId)).length) throw new ApiError(404, "Active company not found.");
}
function* editable(p, id2) {
  const m = yield* manager(p), row2 = (yield* q3("SELECT * FROM document_templates WHERE tenant=@p0 AND id=@p1", p.tenant, id2))[0];
  if (!row2 || !m.root && row2.company_id !== m.company) throw new ApiError(404, "Editable template not found.");
  return row2;
}
function* resolveDocumentTemplate(p, project2, companyId) {
  const defaults = yield* q3("SELECT * FROM document_template_defaults WHERE tenant=@p0", p.tenant);
  for (const scope of ["job:" + project2, "company:" + companyId, "site"]) {
    const pointer = defaults.find((r) => r.scope_key === scope);
    if (!pointer) continue;
    const row2 = (yield* q3("SELECT * FROM document_templates WHERE tenant=@p0 AND id=@p1", p.tenant, pointer.template_id))[0];
    if (!row2 || !row2.published_revision || row2.company_id && row2.company_id !== companyId) continue;
    const version = (yield* q3("SELECT * FROM document_template_versions WHERE tenant=@p0 AND template_id=@p1 AND revision=@p2", p.tenant, row2.id, row2.published_revision))[0];
    if (version) return { id: String(row2.id).toLowerCase(), revision: Number(version.revision), name: version.name, layout: JSON.parse(version.layout) };
  }
  return null;
}
function* currentCompanyLogo(p, companyId) {
  const row2 = (yield* q3("SELECT a.* FROM company_logo_assets a JOIN company_logo_defaults d ON d.tenant=a.tenant AND d.asset_id=a.id AND d.company_id=a.company_id WHERE a.tenant=@p0 AND a.company_id=@p1", p.tenant, companyId))[0];
  return row2 ? { id: String(row2.id).toLowerCase(), companyId, hash: row2.content_hash } : null;
}
function* designerCommand(p, action, data) {
  const m = yield* manager(p);
  if (action === "designer-list") {
    const jobs = yield* q3("SELECT id,company_id FROM jobs WHERE tenant=@p0", p.tenant);
    const rows = yield* q3("SELECT * FROM document_templates WHERE tenant=@p0 ORDER BY name,id", p.tenant), defaults = yield* q3("SELECT * FROM document_template_defaults WHERE tenant=@p0", p.tenant), versions = yield* q3("SELECT * FROM document_template_versions WHERE tenant=@p0", p.tenant);
    return { root: m.root, companyId: m.company, templates: rows.filter((r) => m.root || r.company_id === m.company || !r.company_id && r.published_revision > 0).map((row2) => {
      const canEdit = m.root || row2.company_id === m.company, published = versions.find((v) => v.template_id === row2.id && Number(v.revision) === Number(row2.published_revision));
      return { id: String(row2.id).toLowerCase(), companyId: row2.company_id ?? null, name: canEdit ? row2.name : published?.name ?? row2.name, version: Number(row2.version), publishedRevision: Number(row2.published_revision), canEdit, hasDraft: !published || published.layout !== row2.layout || published.name !== row2.name, layout: JSON.parse(canEdit ? row2.layout : published.layout) };
    }), defaults: defaults.filter((r) => m.root || r.scope_key === "site" || r.scope_key === "company:" + m.company || r.scope_key.startsWith("job:") && jobs.some((j) => j.id === r.scope_key.slice(4) && j.company_id === m.company)) };
  }
  if (action === "designer-save") {
    const v = z11.object({ id: z11.uuid().optional(), name: z11.string().trim().min(1).max(120), companyId: key.nullable(), layout: documentLayout, version: z11.number().int().nonnegative() }).strict().parse(data);
    if (v.companyId) yield* companyAccess(p, v.companyId);
    else if (!m.root) throw new ApiError(403, "Only the site administrator can create global templates.");
    const prior = v.id ? yield* editable(p, v.id) : null;
    if (v.version !== Number(prior?.version ?? 0)) throw new ApiError(409, "Template changed. Reopen the saved version before saving.");
    if (prior?.published_revision && prior.company_id !== v.companyId) throw new ApiError(409, "Duplicate a published template to change its company scope.");
    const id2 = prior?.id ?? randomUUID6();
    if (prior) yield* q3("UPDATE document_templates SET name=@p0,company_id=@p1,layout=@p2,version=version+1 WHERE tenant=@p3 AND id=@p4", v.name, v.companyId, JSON.stringify(v.layout), p.tenant, id2);
    else yield* q3("INSERT INTO document_templates(tenant,id,company_id,name,layout,version,published_revision) VALUES(@p0,@p1,@p2,@p3,@p4,1,0)", p.tenant, id2, v.companyId, v.name, JSON.stringify(v.layout));
    yield* audit3(p, "document.template_draft_saved", String(id2));
    return { id: String(id2).toLowerCase(), version: v.version + 1 };
  }
  if (action === "designer-publish") {
    const v = z11.object({ id: z11.uuid(), version: z11.number().int().positive(), approval: z11.literal("I approve this template for live MRF output") }).strict().parse(data), row2 = yield* editable(p, v.id);
    if (Number(row2.version) !== v.version) throw new ApiError(409, "Template changed. Reload before publication.");
    try {
      const sized = sizeLayout(documentLayout.parse(JSON.parse(row2.layout)));
      if (sized.warnings.length) throw Error(sized.warnings.join(" "));
      validatePublishedLayout(sized.layout);
    } catch (e) {
      throw new ApiError(400, e instanceof Error ? e.message : "Invalid published layout.");
    }
    const revision2 = Number(row2.published_revision) + 1;
    yield* q3("INSERT INTO document_template_versions(tenant,template_id,revision,name,company_id,layout,published_at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6)", p.tenant, row2.id, revision2, row2.name, row2.company_id, row2.layout, (/* @__PURE__ */ new Date()).toISOString());
    yield* q3("UPDATE document_templates SET published_revision=@p0,version=version+1 WHERE tenant=@p1 AND id=@p2", revision2, p.tenant, row2.id);
    yield* audit3(p, "document.template_published", v.id + "-v" + revision2);
    return { revision: revision2, version: v.version + 1 };
  }
  if (action === "designer-assign") {
    const v = z11.object({ scope: z11.enum(["site", "company", "job"]), scopeId: key.optional(), templateId: z11.uuid().nullable() }).strict().parse(data);
    let companyId = null, scopeKey = "site";
    if (v.scope === "site") {
      if (!m.root) throw new ApiError(403, "Site administrator required.");
    } else if (v.scope === "company") {
      companyId = key.parse(v.scopeId);
      yield* companyAccess(p, companyId);
      scopeKey = "company:" + companyId;
    } else {
      const job = (yield* q3("SELECT * FROM jobs WHERE tenant=@p0 AND id=@p1", p.tenant, key.parse(v.scopeId)))[0];
      if (!job) throw new ApiError(404, "Job not found.");
      companyId = job.company_id;
      yield* companyAccess(p, companyId);
      scopeKey = "job:" + job.id;
    }
    if (v.templateId) {
      const t = (yield* q3("SELECT * FROM document_templates WHERE tenant=@p0 AND id=@p1", p.tenant, v.templateId))[0];
      if (!t || !t.published_revision || v.scope === "site" && t.company_id || t.company_id && t.company_id !== companyId) throw new ApiError(400, "Choose a published global template or one belonging to this company.");
    }
    yield* q3("DELETE FROM document_template_defaults WHERE tenant=@p0 AND scope_key=@p1", p.tenant, scopeKey);
    if (v.templateId) yield* q3("INSERT INTO document_template_defaults(tenant,scope_key,template_id) VALUES(@p0,@p1,@p2)", p.tenant, scopeKey, v.templateId);
    yield* audit3(p, "document.template_default", scopeKey);
    return { saved: true };
  }
  if (action === "designer-logo-get") {
    const companyId = key.parse(data.companyId);
    yield* companyAccess(p, companyId);
    return { logo: yield* currentCompanyLogo(p, companyId) };
  }
  if (action === "designer-logo-save") {
    const v = z11.object({ companyId: key, id: z11.uuid(), hash: z11.string().regex(/^[a-f\d]{64}$/) }).strict().parse(data);
    yield* companyAccess(p, v.companyId);
    yield* q3("INSERT INTO company_logo_assets(tenant,id,company_id,content_hash,created_at) VALUES(@p0,@p1,@p2,@p3,@p4)", p.tenant, v.id, v.companyId, v.hash, (/* @__PURE__ */ new Date()).toISOString());
    yield* q3("DELETE FROM company_logo_defaults WHERE tenant=@p0 AND company_id=@p1", p.tenant, v.companyId);
    yield* q3("INSERT INTO company_logo_defaults(tenant,company_id,asset_id) VALUES(@p0,@p1,@p2)", p.tenant, v.companyId, v.id);
    yield* audit3(p, "company.logo_uploaded", v.companyId);
    return { saved: true };
  }
  if (action === "designer-logo-remove") {
    const companyId = key.parse(data.companyId);
    yield* companyAccess(p, companyId);
    yield* q3("DELETE FROM company_logo_defaults WHERE tenant=@p0 AND company_id=@p1", p.tenant, companyId);
    yield* audit3(p, "company.logo_removed", companyId);
    return { saved: true };
  }
  throw new ApiError(404, "Unknown document designer operation.");
}

// server/pdf-template.ts
import { randomUUID as randomUUID7 } from "node:crypto";

// src/pdf-template.ts
import { z as z12 } from "zod";
var pdfTemplate = z12.object({ title: z12.string().trim().min(1).max(80).default("MATERIAL REQUEST FORM"), companyName: z12.string().trim().max(100).default(""), paper: z12.enum(["Letter", "A4"]).default("Letter"), accent: z12.string().regex(/^#[a-fA-F0-9]{6}$/).default("#dce5f5"), descriptionPercent: z12.number().int().min(40).max(70).default(58), fontSize: z12.number().int().min(8).max(12).default(9) }).strict();

// server/pdf-template.ts
init_contracts();
import { z as z13 } from "zod";
function* templateCommand(p, action, data) {
  const rows = yield { text: "SELECT * FROM pdf_templates WHERE tenant=@p0", values: [p.tenant] };
  if (action === "pdf-template-get") return { config: rows[0] ? pdfTemplate.parse(JSON.parse(rows[0].config)) : pdfTemplate.parse({}), version: Number(rows[0]?.version ?? 0) };
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
  const v = z13.object({ config: pdfTemplate, version: z13.number().int().nonnegative() }).strict().parse(data);
  if (v.version !== Number(rows[0]?.version ?? 0)) throw new ApiError(409, "Template changed. Reload before saving.");
  if (rows.length) yield { text: "UPDATE pdf_templates SET config=@p0,version=version+1 WHERE tenant=@p1", values: [JSON.stringify(v.config), p.tenant] };
  else yield { text: "INSERT INTO pdf_templates(tenant,config,version) VALUES(@p0,@p1,1)", values: [p.tenant, JSON.stringify(v.config)] };
  yield { text: "INSERT INTO audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", values: [randomUUID7(), p.tenant, p.oid, "pdf.template_saved", "template-version-" + (v.version + 1), (/* @__PURE__ */ new Date()).toISOString()] };
  return { config: v.config, version: v.version + 1 };
}

// server/material-table.ts
init_contracts();
import { createHash as createHash5 } from "node:crypto";
import { z as z14 } from "zod";
var withHash = (record2) => ({ ...record2, editHash: createHash5("sha256").update(JSON.stringify([record2.externalKey, record2.description, record2.displayDescription, record2.productUnit, record2.attributes, record2.sourceUrl, record2.verificationBasis, record2.active, record2.verification])).digest("hex") });
function* materialTable(p, action, data) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
  if (action === "material-table-row") {
    const { id: id2 } = z14.object({ id: z14.uuid() }).strict().parse(data);
    return withHash(yield* materialDetails(p, id2));
  }
  if (action === "material-categories") return { categories: yield* materialCategories(p) };
  if (action === "material-category-save") return yield* saveCategory(p, data);
  if (action === "material-table-page") {
    const input3 = z14.object({ text: z14.string().max(200).default(""), page: z14.number().int().positive().default(1), category: z14.string().max(60).default(""), familyId: z14.string().max(60).default(""), sort: z14.string().max(60).default("description"), direction: z14.enum(["asc", "desc"]).default("asc"), filters: z14.array(z14.object({ field: z14.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,39}$/), op: z14.enum(["contains", "eq", "gte", "lte"]), value: z14.string().max(200) }).strict()).max(25).default([]) }).strict().parse(data);
    const categories = yield* materialCategories(p);
    if (input3.category && !categories.some((category) => category.id === input3.category)) throw new ApiError(400, "Choose an existing material category.");
    if (input3.familyId && !materialFamily(input3.familyId)) throw new ApiError(400, "Choose a supported family.");
    const rows = yield { text: "SELECT m.id,m.external_key,m.description,m.product_uom,p.attributes FROM materials m LEFT JOIN catalog_profiles p ON p.material_id=m.id AND p.tenant=m.tenant WHERE m.tenant=@p0 AND m.active=1", values: [p.tenant] };
    const indexed = rows.map((row2) => ({ ...row2, attributes: (() => {
      const a = row2.attributes ? JSON.parse(row2.attributes) : {};
      return { ...a, ...inferredFamily(a) ? { familyId: inferredFamily(a).id } : {} };
    })() })), norm3 = (value) => String(value ?? "").normalize("NFKC").trim().toLowerCase();
    const inCategory = indexed.filter((row2) => !input3.category || (row2.attributes.category ?? "general") === input3.category).filter((row2) => !input3.familyId || row2.attributes.familyId === input3.familyId);
    const definition = categories.find((category) => category.id === input3.category);
    const family2 = materialFamily(input3.familyId);
    const schema = family2 ? family2.fields.map((f) => ({ key: f.key, label: f.label, type: f.kind, required: f.required })) : definition?.fields ?? [];
    const fields4 = [...schema];
    for (const row2 of inCategory) for (const [key3, value] of Object.entries(row2.attributes)) if (!["category", "recordOrigin"].includes(key3) && !fields4.some((field2) => field2.key === key3)) fields4.push({ key: key3, label: key3, type: key3.endsWith("In") ? "inches" : typeof value === "number" ? "number" : "text", required: false });
    const cell = (row2, field2) => field2 === "unit" ? row2.product_uom : field2 === "category" ? categories.find((category) => category.id === (row2.attributes.category ?? "general"))?.name ?? "general" : field2 === "description" ? row2.description : field2 === "externalKey" ? row2.external_key : row2.attributes[field2];
    const filters = input3.filters.filter((filter) => filter.value.trim()).map((filter) => {
      const type = fields4.find((field2) => field2.key === filter.field)?.type;
      let numeric2;
      if (type === "inches") {
        try {
          numeric2 = parseInches(filter.value);
        } catch {
          throw new ApiError(400, "Use an inch measurement such as 1/2 for " + filter.field + ".");
        }
      } else if (type === "number" || ["gte", "lte"].includes(filter.op)) {
        numeric2 = Number(filter.value);
        if (!Number.isFinite(numeric2)) throw new ApiError(400, "Use a number for " + filter.field + ".");
      }
      return { ...filter, numeric: numeric2 };
    });
    const matched = inCategory.filter((row2) => (!input3.text || norm3(row2.description + " " + row2.external_key).includes(norm3(input3.text))) && filters.every((filter) => {
      const value = cell(row2, filter.field);
      if (value === void 0 || value === null) return false;
      if (filter.numeric !== void 0) {
        const number3 = Number(value);
        return Number.isFinite(number3) && (filter.op === "gte" ? number3 >= filter.numeric : filter.op === "lte" ? number3 <= filter.numeric : number3 === filter.numeric);
      }
      return filter.op === "contains" ? norm3(value).includes(norm3(filter.value)) : norm3(value) === norm3(filter.value);
    }));
    const sort = input3.sort.startsWith("attr.") ? input3.sort.slice(5) : input3.sort;
    if (!["description", "externalKey", "category", "unit", ...fields4.map((field2) => field2.key)].includes(sort)) throw new ApiError(400, "Choose an available sort field.");
    matched.sort((a, b) => {
      const av = cell(a, sort), bv = cell(b, sort);
      if (av === void 0 && bv !== void 0) return 1;
      if (bv === void 0 && av !== void 0) return -1;
      let order = typeof av === "number" && typeof bv === "number" ? av - bv : norm3(av).localeCompare(norm3(bv), void 0, { numeric: true });
      if (input3.direction === "desc") order = -order;
      return order || norm3(a.external_key).localeCompare(norm3(b.external_key)) || String(a.id).localeCompare(String(b.id));
    });
    const total = matched.length, pages = Math.max(1, Math.ceil(total / 25)), page = Math.min(input3.page, pages), records = [];
    for (const row2 of matched.slice((page - 1) * 25, page * 25)) records.push(withHash(yield* materialDetails(p, String(row2.id).toLowerCase())));
    return { records, total, page, pages, categories, families: materialFamilies, fields: fields4.map((field2) => ({ ...field2, values: [...new Set(inCategory.map((row2) => row2.attributes[field2.key]).filter((value) => value !== void 0).map((value) => field2.type === "inches" ? formatInches(String(value)) : String(value)))].slice(0, 50) })) };
  }
  const editable2 = z14.object({ displayDescription: materialInput.shape.displayDescription, category: materialInput.shape.category, attributes: materialInput.shape.attributes, productUnit: materialInput.shape.productUnit, sourceUrl: materialInput.shape.sourceUrl, verificationBasis: materialInput.shape.verificationBasis }).strict();
  const input2 = z14.object({ id: z14.uuid().optional(), editHash: z14.string().optional(), material: editable2, reason: z14.string().trim().min(10).max(2e3), expectedHash: z14.string().optional(), approval: z14.string().optional() }).strict().parse(data);
  const material = { ...input2.material, externalKey: "pending", origin: "admin_reviewed", verification: "provisional" };
  const built = describeMaterial(material);
  material.externalKey = "MAT-" + built.identity.slice(0, 32);
  if (input2.id) {
    const current = yield* materialDetails(p, input2.id);
    if (input2.editHash !== withHash(current).editHash) throw new ApiError(409, "This material changed after you opened it. Discard this row and refresh materials before editing again.");
    if (current.attributes.category) {
      const attributes = Object.fromEntries(Object.entries(current.attributes).filter(([key3]) => !["category", "recordOrigin"].includes(key3)));
      const original = describeMaterial({ ...material, externalKey: current.externalKey, category: current.attributes.category, productUnit: current.productUnit, attributes });
      if (original.identity === built.identity) material.externalKey = current.externalKey;
    }
    const correction = { id: input2.id, material, reason: input2.reason };
    const preview = yield* correctCatalog(p, "material", correction);
    if (action === "material-table-preview") return preview;
    if (input2.approval !== "Save this material") throw new ApiError(400, "Review the material before saving.");
    return yield* correctCatalog(p, "material", { ...correction, expectedHash: input2.expectedHash, approval: "I reviewed the correction and historical impact" }, true);
  }
  const prior = yield* createMaterial(p, material, true);
  if (prior.id) {
    const target = yield* materialDetails(p, prior.id);
    if (!target.active) throw new ApiError(409, "This material already exists as a retired record. Review it in Catalog and imports.");
  }
  const previewHash = createHash5("sha256").update(JSON.stringify({ material, prior, reason: input2.reason })).digest("hex");
  if (action === "material-table-preview") return { mode: prior.id ? "existing" : "new", previewHash, description: input2.material.displayDescription ?? built.description, existingId: prior.id ?? null, impact: { savedLines: 0, products: 0, images: 0, activeRules: 0 } };
  if (input2.approval !== "Save this material" || input2.expectedHash !== previewHash) throw new ApiError(409, "Material review changed. Review again before saving.");
  return yield* createMaterial(p, material);
}

// server/catalog-import-v2.ts
init_contracts();
import { z as z15 } from "zod";
import { createHash as createHash6, randomUUID as randomUUID8 } from "node:crypto";

// src/research-attributes.ts
function isProductDetail(category, name4) {
  return ["conduit", "bracket", "box"].includes(category) && name4 === "specification" || ["packQuantity", "packWeightLbs", "packageQuantity", "packageWeightLbs", "palletQuantity", "palletWeightLbs", "bundleQuantity", "cartonQuantity", "tradeSizeIn", "standards", "ratings", "countryOfOrigin", "countryOfManufacture", "manufacturerCatalogSection", "productSeries"].includes(name4);
}
function separateResearchDetails(item2) {
  const attributes = { ...item2.attributes }, productDetails = { ...item2.productDetails };
  for (const [name4, value] of Object.entries(attributes)) if (isProductDetail(item2.category, name4)) {
    productDetails[name4] = value;
    delete attributes[name4];
  }
  return { ...item2, attributes, ...Object.keys(productDetails).length ? { productDetails } : {} };
}

// server/catalog-import-v2.ts
var name = z15.string().trim().min(1).max(500);
var url2 = z15.string().max(2e3).transform((v) => publicSourceUrl(v).href);
var attribute = z15.union([z15.string().max(2e3), z15.number().finite(), z15.array(z15.union([z15.string().max(500), z15.number().finite()])).max(50)]);
var item = z15.object({ recordType: z15.enum(["material", "product"]), manufacturer: name.nullable().optional(), partNumber: name.nullable().optional(), description: name, category: z15.enum(["general", "conduit", "bracket", "box", "hardware_fasteners", "hardware-fasteners", "drill_bits", "drill-bits", "consumables"]), attributes: z15.record(z15.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,39}$/), attribute), unit: z15.enum(["EA", "FT", "STICK", "BOX", "ROLL", "PAIR"]).nullable().optional(), packageQuantity: z15.number().int().positive().max(1e9).nullable().optional(), supplierReferences: z15.array(z15.object({ supplier: name, catalogNumber: name, url: url2.nullable().optional() }).strict()).max(10).default([]), productUrl: url2.nullable().optional(), imageUrl: url2.nullable().optional(), translations: z15.array(name).max(100), sources: z15.array(url2).max(20).default([]), notes: z15.string().max(2e3).optional() }).strict().superRefine((v, c) => {
  if (v.recordType === "product" && (!v.manufacturer || !v.partNumber)) c.addIssue({ code: "custom", message: "Manufacturer products require both manufacturer and manufacturer part number." });
  if (v.recordType === "product" && /^(approved (manufacturer|vendor)|generic|various|unknown|n\/a)$/i.test(v.manufacturer ?? "")) c.addIssue({ code: "custom", message: "Use recordType material when the manufacturer is unknown; do not invent a manufacturer." });
  if (v.recordType === "material" && (v.manufacturer || v.partNumber)) c.addIssue({ code: "custom", message: "Material-only records must leave manufacturer and partNumber null; place supplier identifiers in supplierReferences." });
  if (!v.productUrl && !v.sources.length && !v.supplierReferences.some((r) => r.url)) c.addIssue({ code: "custom", message: "An evidence URL is required." });
});
var catalogImportV2 = z15.object({ schemaVersion: z15.literal("etalonops-catalog-v2"), items: z15.array(item).min(1).max(25) }).strict();
function parseCatalogV2(raw) {
  const data = catalogImportV2.parse(raw), items = [], notices = [], keys = /* @__PURE__ */ new Map(), products = /* @__PURE__ */ new Set(), phrases = /* @__PURE__ */ new Set();
  let missingUnits = 0;
  const append = (kind, fields4) => {
    const row2 = { id: randomUUID8(), kind, sheet: "ChatGPT " + kind, row: items.length + 2, fields: { kind, ...fields4 }, state: "unpublished" };
    items.push(row2);
    return row2;
  };
  for (const v of data.items) {
    const category = v.category.replace(/_/g, "-"), sourceUrl = v.productUrl ?? v.sources[0] ?? v.supplierReferences.find((r) => r.url).url, unit2 = v.unit ?? (category === "conduit" || /\bwire\b/i.test(String(v.attributes.type)) ? null : "EA");
    if (!unit2) missingUnits++;
    const attributes = {}, details2 = {};
    for (const [key3, value] of Object.entries(v.attributes)) {
      const out = Array.isArray(value) ? JSON.stringify(value) : value;
      if (isProductDetail(category, key3) || ["upc", "gtin", "supplierReferences", "orderingUnitBasis"].includes(key3)) details2[key3] = out;
      else attributes[key3] = out;
    }
    if (v.packageQuantity != null) details2.packageQuantity = v.packageQuantity;
    if (v.supplierReferences.length) details2.supplierReferences = JSON.stringify(v.supplierReferences);
    if (v.notes) details2.researchNotes = v.notes;
    if (v.sources.length) details2.evidenceUrls = JSON.stringify(v.sources);
    const externalKey = "RESEARCH-" + createHash6("sha256").update(JSON.stringify({ category, unit: unit2, attributes: Object.fromEntries(Object.entries(attributes).sort(([a], [b]) => a.localeCompare(b))) })).digest("hex").slice(0, 24);
    let material = keys.get(externalKey);
    const materialDetails2 = v.recordType === "material" ? details2 : {};
    if (!material) {
      const fields4 = { externalKey, displayDescription: v.description, category, productUnit: unit2 ?? "", sourceUrl, verification: "provisional", origin: "ai_import", verificationBasis: "External research; administrator review required.", ...Object.keys(materialDetails2).length ? { details: JSON.stringify(materialDetails2) } : {} };
      for (const [k, val] of Object.entries(attributes)) fields4[materialColumns.includes(k) ? k : "attribute." + k] = String(val);
      material = append("material", fields4);
      keys.set(externalKey, material);
    } else if (Object.keys(materialDetails2).length) {
      const prior = JSON.parse(material.fields.details ?? "{}");
      for (const [key3, value] of Object.entries(materialDetails2)) {
        if (Object.hasOwn(prior, key3) && prior[key3] !== value) throw new ApiError(400, "Repeated generic material has different " + key3 + ". Keep one record per material or consolidate its supplier references.");
        prior[key3] = value;
      }
      material.fields.details = JSON.stringify(prior);
    }
    if (v.recordType === "product") {
      const partKey = JSON.stringify([v.manufacturer.normalize("NFKC").trim().toLowerCase(), v.partNumber.normalize("NFKC").trim().toLowerCase()]);
      if (products.has(partKey)) throw new ApiError(400, "A manufacturer part appears more than once.");
      products.add(partKey);
      append("product", { materialKey: externalKey, manufacturer: v.manufacturer, partNumber: v.partNumber, title: v.description, details: JSON.stringify(details2), sourceUrl, verification: "provisional", origin: "ai_import" });
    }
    const aliases = [...v.translations, ...v.supplierReferences.flatMap((r) => [r.catalogNumber, r.supplier + " " + r.catalogNumber]), ...v.recordType === "product" ? [v.partNumber, v.manufacturer + " " + v.partNumber] : []];
    for (const phrase of aliases) {
      const key3 = externalKey + "/" + phrase.normalize("NFKC").toLowerCase().trim().replace(/\s+/g, " ");
      if (phrases.has(key3)) continue;
      phrases.add(key3);
      append("translation", { materialKey: externalKey, phrase, sourceUrl, origin: "ai_generated" });
    }
    if (v.imageUrl) append("image", { materialKey: externalKey, ...v.recordType === "product" ? { manufacturer: v.manufacturer, partNumber: v.partNumber } : {}, sourceUrl: v.imageUrl, rightsBasis: "Owner-managed image use; externally researched product or representative material image. Evidence: " + sourceUrl });
    else notices.push(v.description + ": no image supplied; add one in review if needed.");
    if (!unit2) notices.push(v.description + ": choose an MRF ordering unit before publication.");
  }
  if (items.length > 2e3) throw new ApiError(413, "This research creates too many review rows. Import fewer items.");
  return { input: { ...data, request: "Externally prepared catalog v2" }, items, notices, originalJson: JSON.stringify(raw), summary: { products: data.items.filter((v) => v.recordType === "product").length, genericMaterials: data.items.filter((v) => v.recordType === "material").length, materials: keys.size, translations: items.filter((v) => v.kind === "translation").length, images: items.filter((v) => v.kind === "image").length, missingUnits, notices } };
}

// server/prepared-research.ts
init_contracts();
import { z as z16 } from "zod";
import { createHash as createHash7, randomUUID as randomUUID9 } from "node:crypto";
var text3 = z16.string().max(8e3);
var name2 = z16.string().trim().min(1).max(500);
var url3 = z16.string().max(2e3).transform((value) => publicSourceUrl(value).href);
var ids = z16.array(z16.string().min(1).max(80)).max(50);
var detail = z16.lazy(() => z16.union([z16.string().max(8e3), z16.number().finite(), z16.boolean(), z16.null(), z16.array(detail).max(100), z16.record(z16.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,79}$/), detail)]));
var evidence = z16.object({ sourceIds: ids, note: text3 }).strict();
var preparedResearch = z16.object({ schemaVersion: z16.literal("etalonops-research-v1"), request: z16.string().trim().min(1).max(2e3), coverageNotes: text3, sources: z16.array(z16.object({ id: z16.string().min(1).max(80), url: url3, title: name2, publisher: name2, sourceType: z16.enum(["manufacturer", "distributor", "other"]) }).strict()).max(100), items: z16.array(z16.object({ reviewStatus: z16.enum(["needs_review", "ready_for_admin_review"]), material: z16.object({ description: name2, category: z16.enum(["conduit", "bracket", "box", "general"]), productUnit: z16.enum(["EA", "FT", "STICK", "BOX", "ROLL", "PAIR"]).nullable(), unitBasis: text3.nullable(), attributes: z16.record(z16.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,39}$/), z16.union([z16.string().max(2e3), z16.number().finite(), z16.null()])), attributeEvidence: z16.record(z16.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,39}$/), evidence), verificationBasis: text3, sourceIds: ids }).strict(), manufacturer: z16.object({ name: name2.max(200), officialWebsite: url3.nullable(), parentCompany: name2.nullable(), sourceIds: ids }).strict(), product: z16.object({ partNumber: name2.max(200), title: name2, productPageUrl: url3.nullable(), details: z16.record(z16.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,39}$/), detail), sourceIds: ids }).strict(), translations: z16.array(name2).max(100), images: z16.array(z16.object({ url: url3, sourcePageUrl: url3, imageType: z16.enum(["product", "representative"]), caption: text3, sourceIds: ids }).strict()).max(10), missingInformation: z16.array(text3).max(100), warnings: z16.array(text3).max(100) }).strict()).max(25) }).strict();
var compact = z16.object({ schemaVersion: z16.literal("etalonops-catalog-v1"), items: z16.array(z16.object({ manufacturer: name2, partNumber: name2, description: name2, category: z16.enum(["conduit", "bracket", "box", "general"]), unit: z16.enum(["EA", "FT", "STICK", "BOX", "ROLL", "PAIR"]).nullable().optional(), attributes: z16.record(z16.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,39}$/), z16.union([z16.string().max(2e3), z16.number().finite(), z16.array(z16.union([z16.string().max(500), z16.number().finite()])).max(50)])), productUrl: url3, imageUrl: url3.nullable().optional(), translations: z16.array(name2).max(100), sources: z16.array(url3).max(20).optional(), notes: z16.string().max(2e3).optional() }).strict()).min(1).max(25) }).strict();
function expandCompact(raw) {
  if (raw?.schemaVersion !== "etalonops-catalog-v1") return raw;
  const data = compact.parse(raw);
  const sources = data.items.flatMap((item2, index) => [item2.productUrl, ...item2.sources ?? []].map((link, n) => ({ id: `S${index}-${n}`, url: link, title: item2.description, publisher: item2.manufacturer, sourceType: "other" })));
  return { schemaVersion: "etalonops-research-v1", request: "Externally prepared catalog products", coverageNotes: "", sources, items: data.items.map((item2, index) => ({ reviewStatus: "needs_review", material: { description: item2.description, category: item2.category, productUnit: item2.unit ?? null, unitBasis: null, attributes: Object.fromEntries(Object.entries(item2.attributes).filter(([key3]) => key3 !== "compatibleBoxDepthsIn").map(([key3, value]) => [key3, Array.isArray(value) ? JSON.stringify(value) : value])), attributeEvidence: {}, verificationBasis: "External research; administrator review required.", sourceIds: [`S${index}-0`] }, manufacturer: { name: item2.manufacturer, officialWebsite: null, parentCompany: null, sourceIds: [`S${index}-0`] }, product: { partNumber: item2.partNumber, title: item2.description, productPageUrl: item2.productUrl, details: item2.attributes.compatibleBoxDepthsIn !== void 0 ? { compatibleBoxDepthsIn: item2.attributes.compatibleBoxDepthsIn } : {}, sourceIds: [`S${index}-0`] }, translations: item2.translations, images: item2.imageUrl ? [{ url: item2.imageUrl, sourcePageUrl: item2.productUrl, imageType: "representative", caption: "External product image for administrator review.", sourceIds: [`S${index}-0`] }] : [], missingInformation: [], warnings: item2.notes ? [item2.notes] : [] })) };
}
function parsePreparedResearch(json) {
  if (Buffer.byteLength(json) > 3e5) throw new ApiError(413, "Paste research JSON smaller than 300 KB.");
  let raw;
  try {
    raw = JSON.parse(json.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, ""));
  } catch {
    throw new ApiError(400, "Paste a complete JSON object. Your pasted text has been retained.");
  }
  let nodes = 0;
  function bounded(value, depth = 0) {
    if (++nodes > 5e4 || depth > 12) throw new ApiError(400, "Research JSON is nested too deeply or contains too many values.");
    if (value && typeof value === "object") for (const nested of Object.values(value)) bounded(nested, depth + 1);
  }
  bounded(raw);
  if (raw?.schemaVersion === "etalonops-catalog-v2") {
    try {
      return parseCatalogV2(raw);
    } catch (error) {
      if (error instanceof z16.ZodError) throw new ApiError(400, "Research JSON needs correction: " + error.issues.slice(0, 4).map((issue2) => issue2.path.join(".") + ": " + issue2.message).join("; ") + ". Your pasted text is retained.");
      throw error;
    }
  }
  let input2;
  try {
    input2 = preparedResearch.parse(expandCompact(raw));
  } catch (error) {
    if (error instanceof z16.ZodError) throw new ApiError(400, "Research JSON needs correction: " + error.issues.slice(0, 4).map((issue2) => issue2.path.join(".") + ": " + issue2.message).join("; ") + ". Your pasted text is retained.");
    throw error;
  }
  if (!input2.items.length) throw new ApiError(400, "The research contains no products to import. Your text has been retained.");
  const sources = new Map(input2.sources.map((source) => [source.id, source]));
  if (sources.size !== input2.sources.length) throw new ApiError(400, "Source identifiers must be unique.");
  function checkIds(values) {
    for (const id2 of values) if (!sources.has(id2)) throw new ApiError(400, "Unknown source reference: " + id2);
  }
  const items = [], notices = [];
  const materials = /* @__PURE__ */ new Set(), products = /* @__PURE__ */ new Set(), phrases = /* @__PURE__ */ new Set();
  const append = (kind, fields4) => items.push({ id: randomUUID9(), kind, sheet: "ChatGPT " + kind, row: items.length + 2, fields: { kind, ...fields4 }, state: "unpublished" });
  for (const [index, item2] of input2.items.entries()) {
    if (!item2.material.productUnit && (item2.material.category === "bracket" || item2.material.category === "box" || /\b(fitting|hardware|bracket|hanger|support|screw|nut|washer)\b/i.test(String(item2.material.attributes.type ?? "")))) item2.material.productUnit = "EA";
    for (const values of [item2.material.sourceIds, item2.manufacturer.sourceIds, item2.product.sourceIds, ...Object.values(item2.material.attributeEvidence).map((value) => value.sourceIds), ...item2.images.map((image) => image.sourceIds)]) checkIds(values);
    const sourceUrl = item2.product.productPageUrl ?? sources.get(item2.product.sourceIds[0] ?? item2.material.sourceIds[0])?.url;
    if (!sourceUrl) throw new ApiError(400, "Product " + (index + 1) + " needs an evidence URL or a valid source reference.");
    const attributes = Object.fromEntries(Object.entries(item2.material.attributes).filter(([, value]) => value !== null));
    const separated = separateResearchDetails({ externalKey: "pending", category: item2.material.category, productUnit: item2.material.productUnit ?? "EA", attributes, manufacturer: item2.manufacturer.name, partNumber: item2.product.partNumber, title: item2.product.title, sourceUrl, verificationBasis: item2.material.verificationBasis || "External research; source evidence needs administrator review.", phrases: item2.translations, productDetails: {} });
    const signature2 = JSON.stringify({ category: item2.material.category, unit: item2.material.productUnit, attributes: separated.attributes });
    const materialKey = "RESEARCH-" + createHash7("sha256").update(signature2).digest("hex").slice(0, 24);
    if (!materials.has(materialKey)) {
      const fields4 = { externalKey: materialKey, category: item2.material.category, productUnit: item2.material.productUnit ?? "", sourceUrl, verification: "provisional", origin: "ai_import", verificationBasis: item2.material.verificationBasis.slice(0, 2e3) || "External research; source evidence needs administrator review." };
      for (const [field2, value] of Object.entries(separated.attributes)) fields4[materialColumns.includes(field2) ? field2 : "attribute." + field2] = String(value);
      append("material", fields4);
      materials.add(materialKey);
    }
    const details2 = { ...separated.productDetails };
    for (const [field2, value] of Object.entries(item2.product.details)) {
      if (value === null) continue;
      details2[field2] = typeof value === "string" || typeof value === "number" ? value : JSON.stringify(value);
    }
    if (item2.manufacturer.officialWebsite) details2.manufacturerWebsite = item2.manufacturer.officialWebsite;
    if (item2.manufacturer.parentCompany) details2.manufacturerParentCompany = item2.manufacturer.parentCompany;
    if (item2.material.unitBasis) details2.orderingUnitBasis = item2.material.unitBasis;
    const partKey = JSON.stringify([item2.manufacturer.name.toLowerCase().trim(), item2.product.partNumber.toLowerCase().trim()]);
    if (products.has(partKey)) throw new ApiError(400, "A manufacturer part appears more than once. Keep one researched record per part.");
    products.add(partKey);
    append("product", { materialKey, manufacturer: item2.manufacturer.name, partNumber: item2.product.partNumber, title: item2.product.title, sourceUrl, verification: "provisional", origin: "ai_import", details: JSON.stringify(details2) });
    for (const phrase of [...item2.translations, item2.product.partNumber, item2.manufacturer.name + " " + item2.product.partNumber]) {
      const key3 = materialKey + "/" + phrase.normalize("NFKC").trim().toLowerCase().replace(/\s+/g, " ");
      if (phrases.has(key3)) continue;
      phrases.add(key3);
      append("translation", { materialKey, phrase, sourceUrl, origin: "ai_generated" });
    }
    for (const image of item2.images) append("image", { materialKey, manufacturer: item2.manufacturer.name, partNumber: item2.product.partNumber, sourceUrl: image.url, rightsBasis: ("Owner-managed image use; externally researched " + image.imageType + " image. Evidence: " + image.sourcePageUrl + "; " + image.caption).slice(0, 2e3) });
    if (!item2.material.productUnit) notices.push(item2.product.partNumber + ": choose the catalog ordering unit before publication.");
    if (!item2.images.length) notices.push(item2.product.partNumber + ": no image supplied; add one separately if needed.");
    for (const note of [...item2.missingInformation, ...item2.warnings]) if (/conflict|contradict|mismatch/i.test(note)) notices.push(item2.product.partNumber + ": " + note);
  }
  if (items.length > 2e3) throw new ApiError(413, "This research creates too many review rows. Import fewer products.");
  return { input: input2, items, notices, originalJson: JSON.stringify(raw), summary: { products: input2.items.length, materials: materials.size, translations: items.filter((item2) => item2.kind === "translation").length, images: items.filter((item2) => item2.kind === "image").length, missingUnits: input2.items.filter((item2) => !item2.material.productUnit).length, notices } };
}
function* preparedResearchAction(p, data, stage = false) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
  const { json } = z16.object({ json: z16.string().max(3e5) }).strict().parse(data);
  const parsed = parsePreparedResearch(json);
  if (!stage) return parsed.summary;
  const batch = yield* inboxAction(p, "inbox-stage", { filename: "ChatGPT research \u2014 " + parsed.input.request.slice(0, 160), research: { scope: parsed.input.request, coverageNotes: (parsed.input.coverageNotes + "\n" + parsed.notices.join("\n")).slice(0, 4e3), searchPhrase: "", originalJson: parsed.originalJson }, items: parsed.items });
  return { ...batch, preparedSummary: parsed.summary };
}

// server/research-output.ts
import { z as z17 } from "zod";

// server/search.ts
function normalize(input2) {
  return input2.toLowerCase().normalize("NFKC").replace(/["″]/g, " inch ").replace(/\b(\d+(?:\/\d+)?)\s*pvc\b/g, "$1 inch pvc").replace(/\b(inches|in\.?)(?=\s|$)/g, "inch").replace(/\b(pvc pipe|pvc conduit)\b/g, "pvc").replace(/\belec(?:trical)?\b/g, "electrical").replace(/\bfeet\b/g, "ft").replace(/[^\p{L}\p{N}./-]+/gu, " ").replace(/\s+/g, " ").trim();
}
function oneEditApart(a, b) {
  if (Math.abs(a.length - b.length) > 1) return false;
  let i = 0, j = 0, edits = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) {
      i++;
      j++;
      continue;
    }
    if (++edits > 1) return false;
    if (a.length <= b.length) j++;
    if (b.length <= a.length) i++;
  }
  return edits + (a.length - i) + (b.length - j) <= 1;
}
function terms(value) {
  return normalize(value.normalize("NFKC").replace(/[⁄∕]/g, "/")).replace(/\bsch\.?\s*(\d+)\b/g, "schedule $1").replace(/\bemt\b/g, "electrical metallic tubing").replace(/\bgalv\b/g, "galvanized").replace(/\bblk\b/g, "black").replace(/\bwht\b/g, "white").replace(/\bself[ -]?tappers?\b/g, "self tapping screws");
}
function score(query4, phrase) {
  const cleanQuery = query4.replace(/^(?:i need|i am looking for|looking for|please get me)\s+(?:(?:some|a|an)\s+)?/i, "").replace(/\s+please[.!]?$/i, "");
  const q6 = terms(cleanQuery), p = terms(phrase);
  if (!q6 || !p) return 0;
  const tagged = cleanQuery.match(/#\d+(?![\d-])/g) ?? [];
  if (tagged.some((tag) => !new RegExp(`${tag}(?![\\d-])`, "i").test(phrase))) return 0;
  const numbers = q6.match(/\d+(?:[./-]\d+)*/g) ?? [];
  const productNumbers = p.match(/\d+(?:[./-]\d+)*/g) ?? [];
  if (numbers.some((number3) => !productNumbers.includes(number3))) return 0;
  if (normalize(cleanQuery) === normalize(phrase)) return 100;
  if (q6 === p) return 90;
  const tokens = q6.split(" "), words = p.split(" ");
  const hits = tokens.filter((token) => words.some((word) => token === word || /^[a-z]{5,}$/.test(token) && /^[a-z]{5,}$/.test(word) && oneEditApart(token, word))).length;
  return hits === tokens.length ? 85 : 0;
}

// server/research-policy.ts
init_contracts();
var researchPolicy = { model: "gpt-5.4-mini", version: "2026-03-17", monthlyMicroUsd: 3e7, reservationMicroUsd: 15e4, inputPerMillion: 0.825, outputPerMillion: 4.95, maxBodyBytes: 12e4, maxOutputTokens: 8e3, maxItems: 5, timeoutMs: 6e4, pricingValidThrough: "2026-11-18" };

// server/research-output.ts
var researchNumericFields = ["diameterIn", "lengthIn", "minSpanIn", "maxSpanIn", "widthIn", "heightIn", "depthIn"];
var researchTextFields = ["material", "type", "schedule", "endConnection", "mounting", "nominalSpacing", "knockouts", "specification"];
var string = { type: "string" };
var number2 = { type: "number" };
var attributeProperties = Object.fromEntries([...researchNumericFields.map((name4) => [name4, { type: ["number", "null"] }]), ...researchTextFields.map((name4) => [name4, { type: ["string", "null"] }])]);
var researchOutputSchema = { type: "object", additionalProperties: false, required: ["coverageNotes", "items"], properties: { coverageNotes: string, items: { type: "array", items: { type: "object", additionalProperties: false, required: ["externalKey", "category", "productUnit", "attributes", "additionalDefiningAttributes", "manufacturer", "partNumber", "title", "sourceIndex", "verificationBasis", "phrases", "imageIndex"], properties: { externalKey: string, category: { type: "string", enum: ["conduit", "bracket", "box", "general"] }, productUnit: { type: "string", enum: ["EA", "FT", "STICK", "BOX", "ROLL", "PAIR"] }, attributes: { type: "object", additionalProperties: false, required: Object.keys(attributeProperties), properties: attributeProperties }, additionalDefiningAttributes: { type: "array", items: { type: "object", additionalProperties: false, required: ["name", "value"], properties: { name: string, value: { anyOf: [string, number2] } } } }, manufacturer: string, partNumber: string, title: string, sourceIndex: { type: "integer" }, verificationBasis: string, phrases: { type: "array", items: string }, imageIndex: { type: ["integer", "null"] } } } } } };
var attributeShape = Object.fromEntries([...researchNumericFields.map((name4) => [name4, z17.number().nullable()]), ...researchTextFields.map((name4) => [name4, z17.string().nullable()])]);
var wire = z17.object({ coverageNotes: z17.string().min(1).max(4e3), items: z17.array(z17.object({ externalKey: z17.string(), category: z17.enum(["conduit", "bracket", "box", "general"]), productUnit: z17.enum(["EA", "FT", "STICK", "BOX", "ROLL", "PAIR"]), attributes: z17.object(attributeShape).strict(), additionalDefiningAttributes: z17.array(z17.object({ name: z17.string(), value: z17.union([z17.string(), z17.number()]) }).strict()).max(25), manufacturer: z17.string(), partNumber: z17.string(), title: z17.string(), sourceIndex: z17.number().int().nonnegative(), verificationBasis: z17.string(), phrases: z17.array(z17.string()).max(40), imageIndex: z17.number().int().nonnegative().nullable() }).strict()).max(researchPolicy.maxItems) }).strict();
function researchGaps(candidate2) {
  const missing = researchFields[candidate2.category].filter((field2) => candidate2.attributes[field2] === void 0 || candidate2.attributes[field2] === "");
  if (missing.length) return missing;
  try {
    describeMaterial(materialInput.parse({ externalKey: candidate2.externalKey, category: candidate2.category, productUnit: candidate2.productUnit, attributes: candidate2.attributes, sourceUrl: candidate2.sourceUrl, verificationBasis: candidate2.verificationBasis, verification: "provisional", origin: "ai_discovery" }));
    return [];
  } catch (error) {
    return [error instanceof Error ? error.message.slice(0, 300) : "Invalid defining specifications"];
  }
}

// server/catalog-research.ts
import { createHash as createHash8 } from "node:crypto";
import { z as z18 } from "zod";
import { randomUUID as randomUUID10 } from "node:crypto";
init_contracts();
var requestSchema = z18.object({ results: researchResults, previewHash: z18.string().optional(), approval: z18.string().optional() }).strict();
var csv = (kind, rows) => "kind,data_json\n" + rows.map((row2) => `${kind},"${JSON.stringify(row2).replaceAll('"', '""')}"`).join("\n");
function* researchAction(p, data, apply = false) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
  const input2 = requestSchema.parse(data);
  input2.results.items = input2.results.items.map(separateResearchDetails);
  const materials = /* @__PURE__ */ new Map(), products = [], phrases = /* @__PURE__ */ new Map(), summaries = [], identities = /* @__PURE__ */ new Map(), parts = /* @__PURE__ */ new Set();
  for (const item2 of input2.results.items) {
    const material = materialInput.parse({ externalKey: item2.externalKey, category: item2.category, productUnit: item2.productUnit, attributes: item2.attributes, sourceUrl: item2.sourceUrl, verificationBasis: item2.verificationBasis, origin: "ai_discovery", verification: "provisional" }), built = describeMaterial(material);
    const sameKey = materials.get(item2.externalKey.toLowerCase());
    if (sameKey && describeMaterial(sameKey).identity !== built.identity) throw new ApiError(409, "One material key has conflicting specifications.");
    const existing = yield* createMaterial(p, material, true);
    let materialKey = identities.get(built.identity) ?? material.externalKey;
    if (existing.id) {
      const row2 = (yield { text: "SELECT external_key FROM materials WHERE tenant=@p0 AND id=@p1", values: [p.tenant, existing.id] })[0];
      materialKey = String(row2.external_key);
    }
    identities.set(built.identity, materialKey);
    materials.set(item2.externalKey.toLowerCase(), material);
    const product = productInput.parse({ materialKey, manufacturer: item2.manufacturer, partNumber: item2.partNumber, title: item2.title, ...item2.productDetails ? { details: item2.productDetails } : {}, sourceUrl: item2.sourceUrl, verification: "provisional", origin: "ai_discovery" });
    const partKey = JSON.stringify([product.manufacturer.toLowerCase(), product.partNumber.toLowerCase()]);
    if (parts.has(partKey)) throw new ApiError(409, "A manufacturer part appears more than once.");
    parts.add(partKey);
    const maker = yield* manufacturerByName(p, product.manufacturer);
    const prior = maker ? (yield { text: "SELECT id,material_id FROM manufacturer_products WHERE tenant=@p0 AND manufacturer_id=@p1 AND normalized_part=@p2", values: [p.tenant, maker.id, product.partNumber.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim()] })[0] : void 0;
    if (prior && (!existing.id || String(prior.material_id).toLowerCase() !== String(existing.id).toLowerCase())) throw new ApiError(409, "Manufacturer part is linked to different specifications; use reviewed corrections.");
    if (existing.id) yield* addProduct(p, product, true);
    products.push(product);
    for (const phrase of item2.phrases) {
      const value = translationInput.parse({ materialKey, phrase, sourceUrl: item2.sourceUrl, origin: "ai_generated" });
      phrases.set(JSON.stringify([materialKey.toLowerCase(), phrase.toLowerCase().replace(/\s+/g, " ").trim()]), value);
    }
    summaries.push({ manufacturer: product.manufacturer, partNumber: product.partNumber, description: built.description, materialKey, materialAction: existing.id ? "Link existing material" : "Create or share material", productAction: prior ? item2.productDetails ? "Keep existing manufacturer product; review additional details" : "Keep existing manufacturer product" : "Link manufacturer product" });
  }
  const phraseCheck = parseExtendedCsv(csv("translation", [...phrases.values()]));
  if (phraseCheck.errors.length) throw new ApiError(400, JSON.stringify(phraseCheck.errors));
  const previewHash = createHash8("sha256").update(JSON.stringify({ results: input2.results, summaries })).digest("hex");
  if (!apply) return { previewHash, summaries, phrases: phrases.size, verification: "provisional" };
  if (input2.approval !== "I reviewed these products and sources" || input2.previewHash !== previewHash) throw new ApiError(409, "Preview changed or review confirmation missing. Preview again before adding.");
  const batches = [];
  const canonical = /* @__PURE__ */ new Map();
  for (const material of materials.values()) {
    const identity2 = describeMaterial(material).identity;
    if (!canonical.has(identity2)) canonical.set(identity2, material);
  }
  for (const [kind, rows] of [["material", [...canonical.values()]], ["product", products], ["translation", [...phrases.values()]]]) {
    const batch = yield* previewBulk(p, csv(kind, rows));
    if (batch.report.errors.length) throw new ApiError(409, JSON.stringify(batch.report.errors));
    const result = yield* applyBulk(p, batch.id, "I reviewed this batch");
    batches.push({ kind, id: batch.id, ...result });
  }
  return { batches, products: products.length, verification: "provisional" };
}
function* stageResearch(p, data) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
  const input2 = z18.object({ results: researchResults, searchPhrase: z18.string().trim().max(500).default(""), images: z18.array(z18.object({ manufacturer: z18.string(), partNumber: z18.string(), sourceUrl: z18.url() })).max(5).default([]) }).strict().parse(data);
  input2.results.items = input2.results.items.map(separateResearchDetails);
  const complete = input2.results.items.every((item2) => researchGaps(item2).length === 0);
  const preview = complete ? yield* researchAction(p, { results: input2.results }) : { summaries: input2.results.items.map((item2) => ({ materialKey: item2.externalKey })) };
  const items = [], materials = /* @__PURE__ */ new Set(), phrases = /* @__PURE__ */ new Set();
  const append = (kind, fields4) => items.push({ id: randomUUID10(), kind, sheet: "AI research " + kind, row: items.length + 2, fields: { kind, ...fields4 }, state: "unpublished" });
  input2.results.items.forEach((item2, index) => {
    const materialKey = preview.summaries[index].materialKey;
    if (!materials.has(materialKey)) {
      const attributes = {};
      for (const [key3, value] of Object.entries(item2.attributes)) attributes[materialColumns.includes(key3) ? key3 : "attribute." + key3] = String(value);
      append("material", { externalKey: materialKey, category: item2.category, productUnit: item2.productUnit, verification: "provisional", origin: "ai_import", sourceUrl: item2.sourceUrl, verificationBasis: item2.verificationBasis, ...attributes });
      materials.add(materialKey);
    }
    append("product", { materialKey, manufacturer: item2.manufacturer, partNumber: item2.partNumber, title: item2.title, ...item2.productDetails ? { details: JSON.stringify(item2.productDetails) } : {}, sourceUrl: item2.sourceUrl, verification: "provisional", origin: "ai_import" });
    for (const phrase of [...item2.phrases, ...input2.searchPhrase ? [input2.searchPhrase] : []]) {
      const key3 = JSON.stringify([materialKey, phrase.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim()]);
      if (phrases.has(key3)) continue;
      phrases.add(key3);
      append("translation", { materialKey, phrase, origin: "ai_generated", sourceUrl: item2.sourceUrl });
    }
  });
  for (const image of input2.images) {
    const index = input2.results.items.findIndex((item2) => item2.manufacturer === image.manufacturer && item2.partNumber === image.partNumber);
    if (index < 0) throw new ApiError(400, "Image does not belong to a selected product.");
    append("image", { materialKey: preview.summaries[index].materialKey, manufacturer: image.manufacturer, partNumber: image.partNumber, sourceUrl: image.sourceUrl, rightsBasis: "Owner-managed image usage; imported from selected manufacturer-page AI research." });
  }
  return yield* inboxAction(p, "inbox-stage", { filename: "Product research \u2014 " + (input2.results.scope.trim() || "selected products").slice(0, 160), research: { scope: input2.results.scope, coverageNotes: (input2.results.coverageNotes + " " + input2.results.items.flatMap((item2) => {
    const gaps = researchGaps(item2);
    return gaps.length ? [item2.manufacturer + " " + item2.partNumber + ": needs " + gaps.join(", ")] : [];
  }).join("; ")).trim().slice(0, 4e3), searchPhrase: input2.searchPhrase }, items });
}

// server/catalog-readiness.ts
init_contracts();
import { z as z19 } from "zod";
function* query(text4, ...values) {
  return yield { text: text4, values };
}
var issues = {
  unreviewed: "Catalog specifications need review",
  legacy: "Materials need structured identity review",
  products: "Materials without manufacturer products",
  translations: "Materials without search phrases",
  images: "Materials without approved images",
  productReview: "Manufacturer products need review",
  pendingImages: "Uploaded images awaiting review"
};
function* catalogReadiness(p, data) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
  const input2 = z19.object({ issue: z19.enum(["unreviewed", "legacy", "products", "translations", "images", "productReview", "pendingImages"]).default("unreviewed"), text: z19.string().trim().max(200).default(""), page: z19.number().int().min(1).max(1e5).default(1) }).strict().parse(data);
  const base = "m.tenant=@p0 AND m.active=1";
  const reviewed = "EXISTS(SELECT 1 FROM catalog_profiles cp WHERE cp.tenant=m.tenant AND cp.material_id=m.id AND cp.verification='reviewed')";
  const rules = {
    unreviewed: "EXISTS(SELECT 1 FROM catalog_profiles cp WHERE cp.tenant=m.tenant AND cp.material_id=m.id AND cp.verification='provisional')",
    legacy: "NOT EXISTS(SELECT 1 FROM catalog_profiles cp WHERE cp.tenant=m.tenant AND cp.material_id=m.id)",
    products: "NOT EXISTS(SELECT 1 FROM manufacturer_products mp WHERE mp.tenant=m.tenant AND mp.material_id=m.id AND mp.active=1)",
    translations: "NOT EXISTS(SELECT 1 FROM translations t WHERE t.tenant=m.tenant AND t.material_id=m.id AND t.active=1) AND NOT EXISTS(SELECT 1 FROM aliases a WHERE a.material_id=m.id)",
    images: "NOT EXISTS(SELECT 1 FROM image_associations ia WHERE ia.tenant=m.tenant AND ia.material_id=m.id AND ia.status='approved' AND (ia.product_id IS NULL OR EXISTS(SELECT 1 FROM manufacturer_products ip WHERE ip.tenant=m.tenant AND ip.material_id=m.id AND ip.id=ia.product_id AND ip.active=1)))",
    productReview: "mp.active=1 AND mp.verification='provisional'",
    pendingImages: "ia.status='pending' AND (ia.product_id IS NULL OR EXISTS(SELECT 1 FROM manufacturer_products ip WHERE ip.tenant=m.tenant AND ip.material_id=m.id AND ip.id=ia.product_id AND ip.active=1))"
  };
  const source = (issue2) => issue2 === "productReview" ? "materials m INNER JOIN manufacturer_products mp ON mp.material_id=m.id AND mp.tenant=m.tenant" : issue2 === "pendingImages" ? "materials m INNER JOIN image_associations ia ON ia.material_id=m.id AND ia.tenant=m.tenant" : "materials m";
  const counts = { activeMaterials: `SELECT COUNT(*) FROM materials m WHERE ${base}`, reviewedMaterials: `SELECT COUNT(*) FROM materials m WHERE ${base} AND ${reviewed}`, fixtureMaterials: `SELECT COUNT(*) FROM materials m WHERE ${base} AND m.dataset_kind='fixture'`, activeProducts: "SELECT COUNT(*) FROM manufacturer_products mp INNER JOIN materials m ON m.id=mp.material_id AND m.tenant=mp.tenant WHERE " + base + " AND mp.active=1", activePhrases: "SELECT COUNT(*) FROM translations t INNER JOIN materials m ON m.id=t.material_id AND m.tenant=t.tenant WHERE " + base + " AND t.active=1", stagedImports: "SELECT COUNT(*) FROM catalog_batches WHERE tenant=@p0 AND state IN ('preview','unpublished')", enabledRestrictions: "SELECT COUNT(*) FROM job_restrictions WHERE tenant=@p0 AND enabled=1" };
  for (const issue2 of Object.keys(issues)) counts[issue2] = `SELECT COUNT(*) FROM ${source(issue2)} WHERE ${base} AND (${rules[issue2]})`;
  const raw = (yield* query("SELECT " + Object.entries(counts).map(([key3, sql3]) => `(${sql3}) AS ${key3}`).join(","), p.tenant))[0];
  const summary2 = Object.fromEntries(Object.keys(counts).map((key3) => [key3, Number(raw[key3])]));
  const values = [p.tenant];
  let where = `${base} AND (${rules[input2.issue]})`;
  if (input2.text) {
    values.push("%" + input2.text.toLowerCase().replace(/[!%_\[]/g, (c) => "!" + c) + "%");
    where += " AND (LOWER(m.description) LIKE @p1 ESCAPE '!' OR LOWER(m.external_key) LIKE @p1 ESCAPE '!')";
  }
  const total = Number((yield* query(`SELECT COUNT(*) AS total FROM ${source(input2.issue)} WHERE ${where}`, ...values))[0].total);
  const pages = Math.max(1, Math.ceil(total / 25)), page = Math.min(input2.page, pages), offset = values.length;
  values.push((page - 1) * 25, page * 25);
  const extra = input2.issue === "productReview" ? ",mp.id AS related_id,mp.part_number AS related_label" : input2.issue === "pendingImages" ? ",ia.id AS related_id,ia.source_url AS related_label" : "";
  const tie = input2.issue === "productReview" ? ",mp.id" : input2.issue === "pendingImages" ? ",ia.id" : "";
  const rows = yield* query(`SELECT * FROM (SELECT m.id,m.external_key,m.description${extra},ROW_NUMBER() OVER(ORDER BY m.external_key,m.id${tie}) AS row_num FROM ${source(input2.issue)} WHERE ${where}) queue WHERE row_num>@p${offset} AND row_num<=@p${offset + 1} ORDER BY row_num`, ...values);
  return { summary: summary2, issue: input2.issue, label: issues[input2.issue], generatedAt: (/* @__PURE__ */ new Date()).toISOString(), records: rows.map((row2) => ({ materialId: String(row2.id).toLowerCase(), materialKey: row2.external_key, description: row2.description, ...row2.related_id ? { relatedId: String(row2.related_id).toLowerCase(), relatedLabel: row2.related_label } : {} })), total, page, pages };
}

// server/catalog-v2.ts
init_contracts();
import { createHash as createHash9, randomUUID as randomUUID11 } from "node:crypto";
import { z as z20 } from "zod";
import { parse as parse3 } from "csv-parse/sync";
init_purchasing();
init_purchasing();
function* query2(text4, ...values) {
  return yield { text: text4, values };
}
var digest2 = (value) => createHash9("sha256").update(value).digest("hex");
var key2 = (value) => value.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
var phraseKey = (value) => key2(searchWords(value)).replace(/[″"]/g, " inch ").replace(/\s+/g, " ").trim();
var name3 = z20.string().trim().min(1).max(200);
var reference = z20.string().trim().min(1).max(100);
var https = z20.url().max(2e3).refine((v) => {
  try {
    const u = new URL(v);
    return u.protocol === "https:" && !u.username && !u.password;
  } catch {
    return false;
  }
}, "Use a public HTTPS evidence URL.");
var verification = z20.enum(["provisional", "reviewed"]);
var attributeValue = z20.union([z20.string().trim().min(1).max(2e3), z20.number().finite().nonnegative()]);
var materialInput = z20.object({ externalKey: reference, details: productDetailsSchema.optional(), displayDescription: z20.string().trim().min(1).max(2e3).nullable().optional(), category: z20.string().regex(/^[a-z][a-z0-9-]{0,59}$/), attributes: z20.record(z20.string().regex(/^[a-zA-Z][a-zA-Z0-9]{0,39}$/), attributeValue).refine((v) => Object.keys(v).length > 0 && Object.keys(v).length <= 25), productUnit: z20.enum(["EA", "FT", "STICK", "BOX", "ROLL", "PAIR"]), verification, origin: z20.enum(["admin_reviewed", "ai_import", "ai_discovery"]).default("admin_reviewed"), sourceUrl: z20.union([https, z20.literal("")]), verificationBasis: z20.string().trim().min(10).max(2e3) }).strict().refine((value) => Boolean(value.sourceUrl) || value.origin === "admin_reviewed", "AI-origin materials require a source URL.");
var productInput = z20.object({ materialKey: reference, manufacturer: name3, partNumber: name3, title: z20.string().trim().min(1).max(500), details: productDetailsSchema.optional(), sourceUrl: https, verification, origin: z20.enum(["admin_reviewed", "ai_import", "ai_discovery"]).default("admin_reviewed") }).strict();
var translationInput = z20.object({ materialKey: reference, phrase: z20.string().trim().min(1).max(500), origin: z20.enum(["admin_reviewed", "ai_import", "ai_generated"]), sourceUrl: https.optional() }).strict().superRefine((v, c) => {
  if (v.origin !== "admin_reviewed" && !v.sourceUrl) c.addIssue({ code: "custom", message: "AI phrases need source evidence." });
});
var imageReferenceInput = z20.object({ materialKey: reference, manufacturer: name3.optional(), partNumber: name3.optional(), sourceUrl: https, rightsBasis: z20.string().trim().min(10).max(2e3) }).strict().refine((v) => Boolean(v.manufacturer) === Boolean(v.partNumber), "Manufacturer and part number must be supplied together.");
var policyInput = z20.object({ id: z20.uuid().optional(), projectId: z20.string().regex(/^[a-zA-Z0-9._-]{1,64}$/), materialKey: reference.nullable(), category: z20.enum(["conduit", "bracket", "box", "general"]).nullable(), enabled: z20.boolean().default(false), manufacturerIds: z20.array(z20.uuid()).max(100), productIds: z20.array(z20.uuid()).max(100) }).strict().refine((v) => !(v.materialKey && v.category), "Choose material or category scope, not both.").refine((v) => v.manufacturerIds.length + v.productIds.length > 0, "An allow list cannot be empty.");
function materialIdentity(category, productUnit, attributes) {
  const physical = familyIdentityFields(category, attributes);
  const canonical = Object.fromEntries(Object.entries(attributes).filter(([field2]) => (!physical || physical.has(field2)) && !["familyId", "configurationStatus", "nominalSpacing", "category", "recordOrigin"].includes(field2) && !isProductDetail(category, field2)).sort(([x], [y]) => x.localeCompare(y)).map(([field2, value]) => {
    let normalized = typeof value === "string" ? key2(value) : value;
    if (field2 === "endConnection" && typeof normalized === "string") {
      const end = normalized.replace(/[-_]/g, " ").replace(/\s+/g, " ").trim();
      normalized = ["bell", "bell end", "belled", "belled end"].includes(end) ? "bell end" : ["plain", "plain end"].includes(end) ? "plain end" : end;
    }
    if (field2 === "material" && typeof normalized === "string" && ["pvc", "polyvinyl chloride", "polyvinylchloride"].includes(normalized)) normalized = "pvc";
    return [field2, normalized];
  }));
  return digest2(JSON.stringify({ category: ["hardware-fasteners", "drill-bits", "consumables"].includes(category) ? "general" : category, productUnit, attributes: canonical }));
}
function describeMaterial(input2) {
  const a = input2.attributes;
  if (a.configurationStatus && a.configurationStatus !== "confirmed") throw new ApiError(400, "Unconfirmed configurations cannot enter the active catalog.");
  if (Object.keys(a).some((field2) => /manufacturer|brand|vendor|partnumber|source|verification|price|usage|image/i.test(field2))) throw new ApiError(400, "Brands, part numbers and administrative metadata belong outside material specifications.");
  const positive = (field2) => {
    if (typeof a[field2] !== "number" || Number(a[field2]) <= 0) throw new ApiError(400, `Positive numeric ${field2} in inches is required.`);
    return a[field2];
  };
  const required = (field2) => {
    if (typeof a[field2] !== "string" || !String(a[field2]).trim()) throw new ApiError(400, `${field2} is required.`);
    return String(a[field2]).trim();
  };
  let description;
  const familyText = familyDescription(input2.category, a);
  if (familyText) description = familyText;
  else if (input2.category === "conduit") {
    const type = required("type").toLowerCase();
    if (!["pipe", "conduit"].includes(type)) throw new ApiError(400, "Specify pipe or conduit explicitly.");
    description = `${positive("diameterIn")} in. ${required("material")} ${type}, Schedule ${required("schedule")}, ${positive("lengthIn")} in. Length, ${required("endConnection")}`;
  } else if (input2.category === "bracket") {
    const min = positive("minSpanIn"), max = positive("maxSpanIn");
    if (Number(min) > Number(max)) throw new ApiError(400, "Minimum span cannot exceed maximum span.");
    description = `Telescoping Support Bracket, ${min}\u2013${max} in. Adjustable Span, ${required("mounting")}, ${required("material")}`;
    if (a.nominalSpacing) description += `, ${a.nominalSpacing} Nominal Spacing`;
  } else if (input2.category === "box") description = `${required("type")} Box, ${positive("widthIn")} \xD7 ${positive("heightIn")} \xD7 ${positive("depthIn")} in., ${required("material")}, ${required("knockouts")}`;
  else description = `${required("type")}, ${required("specification")}`;
  return { description, identity: materialIdentity(input2.category, input2.productUnit, a) };
}
function* materialByKey(p, externalKey) {
  const row2 = (yield* query2("SELECT * FROM materials WHERE tenant=@p0 AND LOWER(external_key)=LOWER(@p1) AND active=1", p.tenant, externalKey))[0];
  if (!row2) throw new ApiError(404, `Active material not found: ${externalKey}`);
  return row2;
}
function* materialById(p, id2) {
  if (!z20.uuid().safeParse(id2).success) throw new ApiError(404, "Material not found.");
  const row2 = (yield* query2("SELECT * FROM materials WHERE tenant=@p0 AND id=@p1", p.tenant, id2))[0];
  if (!row2) throw new ApiError(404, "Material not found.");
  return row2;
}
function* audit4(p, action, target) {
  yield* query2("INSERT INTO audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", randomUUID11(), p.tenant, p.oid, action, target, (/* @__PURE__ */ new Date()).toISOString());
}
function admin2(p) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
}
function* createMaterial(p, data, dry = false) {
  admin2(p);
  const input2 = materialInput.parse(data), built = describeMaterial(input2);
  yield* validateMaterialCategory(p, input2);
  if (input2.origin !== "admin_reviewed" && input2.verification === "reviewed") throw new ApiError(400, "AI-origin material records must enter as provisional.");
  let existing = (yield* query2("SELECT material_id FROM catalog_profiles WHERE tenant=@p0 AND identity_key=@p1", p.tenant, built.identity))[0];
  if (!existing) {
    const profiles = yield* query2("SELECT p.material_id,p.attributes FROM catalog_profiles p JOIN materials m ON m.id=p.material_id AND m.tenant=p.tenant WHERE p.tenant=@p0 AND m.product_uom=@p1", p.tenant, input2.productUnit);
    const matches = profiles.filter((row3) => {
      const attributes = JSON.parse(row3.attributes);
      return attributes.category === input2.category && materialIdentity(input2.category, input2.productUnit, attributes) === built.identity;
    });
    if (matches.length > 1) throw new ApiError(409, "Several existing materials share these specifications. Resolve duplicate material records before importing.");
    existing = matches[0];
  }
  const byKey = (yield* query2("SELECT id FROM materials WHERE tenant=@p0 AND LOWER(external_key)=LOWER(@p1)", p.tenant, input2.externalKey))[0];
  if (existing) {
    if (byKey && String(byKey.id).toLowerCase() !== String(existing.material_id).toLowerCase()) throw new ApiError(409, "External key conflicts with another material.");
    const material = (yield* query2("SELECT details FROM materials WHERE tenant=@p0 AND id=@p1", p.tenant, existing.material_id))[0], stored = JSON.parse(material.details), before = stored.catalogDetails ?? {}, merged = { ...before };
    let enriched = false;
    for (const [field2, value] of Object.entries(input2.details ?? {})) {
      if (Object.hasOwn(merged, field2) && merged[field2] !== value) throw new ApiError(409, "Existing material detail " + field2 + " differs; review before replacing it.");
      if (!Object.hasOwn(merged, field2)) {
        merged[field2] = value;
        enriched = true;
      }
    }
    if (enriched && !dry) {
      yield* query2("UPDATE materials SET details=@p0 WHERE tenant=@p1 AND id=@p2", JSON.stringify({ ...stored, catalogDetails: merged }), p.tenant, existing.material_id);
      yield* audit4(p, "catalog.material_enriched", String(existing.material_id));
    }
    return { id: String(existing.material_id).toLowerCase(), unchanged: !enriched };
  }
  if (byKey) throw new ApiError(409, "Existing external key requires reviewed correction; no automatic merge.");
  if ((yield* query2("SELECT id FROM materials WHERE tenant=@p0 AND description=@p1 AND active=1", p.tenant, built.description)).length) throw new ApiError(409, "Matching legacy description requires identity review.");
  if (dry) return { description: input2.displayDescription ?? built.description };
  let batch = (yield* query2("SELECT id FROM import_batches WHERE tenant=@p0 AND hash=@p1", p.tenant, digest2("catalog-v2-materials")))[0];
  if (!batch) {
    batch = { id: randomUUID11() };
    yield* query2("INSERT INTO import_batches(id,tenant,hash,state,[file],report) VALUES(@p0,@p1,@p2,'applied',@p3,@p4)", batch.id, p.tenant, digest2("catalog-v2-materials"), "", JSON.stringify({ rows: 0, errors: [], kind: "structured" }));
  }
  const id2 = randomUUID11();
  const displayDescription = input2.displayDescription ?? built.description;
  const row2 = { schema_version: "1", external_key: input2.externalKey, description: displayDescription, aliases_json: JSON.stringify([.../* @__PURE__ */ new Set([built.description, displayDescription])]), requested_uom: input2.productUnit, product_uom: input2.productUnit, manufacturer: "", manufacturer_part_number: "", specifications_json: JSON.stringify(Object.entries(input2.attributes).map(([k, v]) => `${k}: ${v}`)), conversion_basis_json: "null", source_url: input2.sourceUrl, verification_basis: input2.verificationBasis, dataset_kind: "reviewed" };
  yield* query2("INSERT INTO materials(id,tenant,external_key,description,product_uom,details,dataset_kind,batch_id,active) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7,1)", id2, p.tenant, input2.externalKey, displayDescription, input2.productUnit, JSON.stringify({ catalogDetails: input2.details ?? {}, displayDescription: input2.displayDescription ?? null, row: row2, specs: JSON.parse(row2.specifications_json), category: input2.category === "conduit" ? "conduit" : "general" }), "reviewed", batch.id);
  yield* query2("INSERT INTO catalog_profiles(material_id,tenant,identity_key,attributes,verification,high_use) VALUES(@p0,@p1,@p2,@p3,@p4,0)", id2, p.tenant, built.identity, JSON.stringify({ category: input2.category, ...input2.attributes, recordOrigin: input2.origin }), input2.verification);
  yield* audit4(p, input2.origin === "admin_reviewed" ? "catalog.material_created" : "catalog.material_ai_created", id2);
  return { id: id2, description: displayDescription, unchanged: false };
}
function manufacturerIdentity(value) {
  return key2(value).replace(/[^\p{L}\p{N}]+/gu, " ").trim().replace(/(?:\s+(?:inc|incorporated|corp|corporation|llc|ltd|limited))+$/, "").trim();
}
function* manufacturerByName(p, name4) {
  const exact = (yield* query2("SELECT * FROM manufacturers WHERE tenant=@p0 AND normalized=@p1", p.tenant, key2(name4)))[0];
  if (exact) return exact;
  const matches = (yield* query2("SELECT * FROM manufacturers WHERE tenant=@p0", p.tenant)).filter((row2) => manufacturerIdentity(row2.name) === manufacturerIdentity(name4));
  if (matches.length > 1) throw new ApiError(409, "Manufacturer name matches several existing records. Resolve the duplicate manufacturer records before importing.");
  return matches[0];
}
function* addProduct(p, data, dry = false) {
  admin2(p);
  const input2 = productInput.parse(data);
  if (input2.origin !== "admin_reviewed" && input2.verification === "reviewed") throw new ApiError(400, "AI-origin products must enter as provisional.");
  const material = yield* materialByKey(p, input2.materialKey);
  let maker = yield* manufacturerByName(p, input2.manufacturer);
  const prior = maker ? (yield* query2("SELECT * FROM manufacturer_products WHERE tenant=@p0 AND manufacturer_id=@p1 AND normalized_part=@p2", p.tenant, maker.id, key2(input2.partNumber)))[0] : null;
  if (prior) {
    if (String(prior.material_id).toLowerCase() !== String(material.id).toLowerCase()) throw new ApiError(409, "Manufacturer part number is already linked to another material.");
    const details2 = { ...JSON.parse(prior.details_json ?? "{}") };
    let enriched = false;
    for (const [field2, value] of Object.entries(input2.details ?? {})) {
      if (Object.hasOwn(details2, field2) && details2[field2] !== value) throw new ApiError(409, "Existing product detail " + field2 + " differs; review the product before replacing it.");
      if (!Object.hasOwn(details2, field2)) {
        details2[field2] = value;
        enriched = true;
      }
    }
    if (enriched && !dry) {
      yield* query2("UPDATE manufacturer_products SET details_json=@p0 WHERE tenant=@p1 AND id=@p2", JSON.stringify(details2), p.tenant, prior.id);
      yield* audit4(p, "catalog.product_enriched", String(prior.id));
    }
    return { id: String(prior.id).toLowerCase(), unchanged: !enriched };
  }
  if (dry) return {};
  if (!maker) {
    maker = { id: randomUUID11() };
    yield* query2("INSERT INTO manufacturers(id,tenant,name,normalized) VALUES(@p0,@p1,@p2,@p3)", maker.id, p.tenant, input2.manufacturer, key2(input2.manufacturer));
  }
  const id2 = randomUUID11();
  yield* query2("INSERT INTO manufacturer_products(id,tenant,material_id,manufacturer_id,part_number,normalized_part,title,source_url,verification,details_json,active) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,1)", id2, p.tenant, material.id, maker.id, input2.partNumber, key2(input2.partNumber), input2.title, input2.sourceUrl, input2.verification, JSON.stringify(input2.details ?? {}));
  yield* audit4(p, input2.origin === "admin_reviewed" ? "catalog.product_linked" : "catalog.product_ai_linked", id2);
  return { id: id2, unchanged: false };
}
function* addPhrase(p, materialId, phrase, origin, batch = null, sourceUrl = null) {
  const normalized = phraseKey(phrase);
  if (!normalized || normalized.length > 500) throw new ApiError(400, "Phrase must normalize to 1\u2013500 characters.");
  const prior = (yield* query2("SELECT id,active FROM translations WHERE tenant=@p0 AND material_id=@p1 AND normalized=@p2 AND origin=@p3", p.tenant, materialId, normalized, origin))[0];
  if (prior) return { id: String(prior.id).toLowerCase(), unchanged: true, active: Boolean(prior.active) };
  const id2 = randomUUID11();
  yield* query2("INSERT INTO translations(id,tenant,material_id,phrase,normalized,origin,actor,created_at,active,batch_id,source_url) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7,1,@p8,@p9)", id2, p.tenant, materialId, phrase, normalized, origin, p.oid, (/* @__PURE__ */ new Date()).toISOString(), batch, sourceUrl);
  return { id: id2, unchanged: false };
}
function* addTranslation(p, data, dry = false, batch = null) {
  admin2(p);
  const input2 = translationInput.parse(data), m = yield* materialByKey(p, input2.materialKey);
  if (dry) return {};
  const result = yield* addPhrase(p, String(m.id).toLowerCase(), input2.phrase, input2.origin, batch, input2.sourceUrl ?? null);
  yield* audit4(p, "translation.imported", result.id);
  return result;
}
function* selectMaterial(p, data) {
  const input2 = z20.object({ eventId: z20.uuid(), projectId: z20.string().regex(/^[a-zA-Z0-9._-]{1,64}$/), materialId: z20.uuid(), productId: z20.uuid().nullable(), phrase: z20.string().trim().min(1).max(500) }).strict().parse(data);
  if (!(yield* query2("SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, input2.projectId)).length) throw new ApiError(404, "Project not found.");
  const material = yield* materialById(p, input2.materialId);
  if (!material.active) throw new ApiError(409, "Material is inactive.");
  const existing = (yield* query2("SELECT * FROM selection_events WHERE id=@p0", input2.eventId))[0];
  if (existing) {
    if (existing.tenant !== p.tenant || existing.actor !== p.oid || String(existing.material_id).toLowerCase() !== input2.materialId || existing.phrase !== input2.phrase || existing.project !== input2.projectId || (existing.product_id ? String(existing.product_id).toLowerCase() : null) !== input2.productId) throw new ApiError(409, "Selection identifier is already used.");
    return { unchanged: true };
  }
  if (input2.productId) yield* productForMaterial(p, input2.materialId, input2.productId);
  yield* query2("INSERT INTO selection_events(id,tenant,actor,project,material_id,product_id,phrase,created_at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7)", input2.eventId, p.tenant, p.oid, input2.projectId, input2.materialId, input2.productId, input2.phrase, (/* @__PURE__ */ new Date()).toISOString());
  const translation = yield* addPhrase(p, input2.materialId, input2.phrase, "user_selection");
  yield* audit4(p, "catalog.selected", input2.eventId);
  return { translation, unchanged: false };
}
function* productForMaterial(p, materialId, productId) {
  const product = (yield* query2("SELECT p.*,m.name AS manufacturer FROM manufacturer_products p JOIN manufacturers m ON p.manufacturer_id=m.id AND p.tenant=m.tenant WHERE p.id=@p0 AND p.tenant=@p1 AND p.material_id=@p2 AND p.active=1", productId, p.tenant, materialId))[0];
  if (!product) throw new ApiError(400, "Manufacturer product does not belong to this material.");
  return product;
}
function* materialDetails(p, id2, projectId) {
  if (projectId && !(yield* query2("SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, projectId)).length) throw new ApiError(404, "Project not found.");
  const material = yield* materialById(p, id2);
  const profile = (yield* query2("SELECT * FROM catalog_profiles WHERE material_id=@p0 AND tenant=@p1", id2, p.tenant))[0];
  const products = yield* query2("SELECT p.*,m.name AS manufacturer FROM manufacturer_products p JOIN manufacturers m ON m.id=p.manufacturer_id AND m.tenant=p.tenant WHERE p.tenant=@p0 AND p.material_id=@p1 AND p.active=1", p.tenant, id2);
  for (const product of products) {
    product.allowed = true;
    if (projectId) try {
      yield* validatePurchase(p, projectId, id2, { productId: String(product.id).toLowerCase(), manufacturer: product.manufacturer, partNumber: product.part_number, noSubstitutions: false });
    } catch (error) {
      if (!(error instanceof ApiError)) throw error;
      product.allowed = false;
    }
  }
  const storedDetails = JSON.parse(material.details), evidence2 = storedDetails.row ?? {}, attributes = profile ? JSON.parse(profile.attributes) : {};
  let generatedDescription = material.description;
  if (attributes.category) try {
    generatedDescription = describeMaterial({ externalKey: material.external_key, category: attributes.category, productUnit: material.product_uom, attributes: Object.fromEntries(Object.entries(attributes).filter(([key3]) => !["category", "recordOrigin"].includes(key3))), sourceUrl: evidence2.source_url ?? "", verificationBasis: evidence2.verification_basis ?? "", verification: profile?.verification ?? "provisional", origin: "admin_reviewed" }).description;
  } catch {
  }
  return { id: id2, details: storedDetails.catalogDetails ?? {}, externalKey: material.external_key, description: material.description, generatedDescription, displayDescription: storedDetails.displayDescription ?? null, active: Boolean(material.active), productUnit: material.product_uom, sourceUrl: evidence2.source_url ?? "", verificationBasis: evidence2.verification_basis ?? "", attributes: profile ? JSON.parse(profile.attributes) : {}, verification: profile?.verification ?? "reviewed", highUse: Boolean(profile?.high_use), preferredProductId: profile?.preferred_product_id ? String(profile.preferred_product_id).toLowerCase() : null, products: products.map((product) => ({ id: String(product.id).toLowerCase(), manufacturerId: String(product.manufacturer_id).toLowerCase(), manufacturer: product.manufacturer, partNumber: product.part_number, title: product.title, sourceUrl: product.source_url, details: JSON.parse(product.details_json ?? "{}"), verification: product.verification, allowed: product.allowed })) };
}
function* setPriority(p, data) {
  admin2(p);
  const input2 = z20.object({ materialId: z20.uuid(), highUse: z20.boolean(), preferredProductId: z20.uuid().nullable() }).strict().parse(data);
  const m = yield* materialById(p, input2.materialId);
  if (input2.preferredProductId) yield* productForMaterial(p, input2.materialId, input2.preferredProductId);
  const exists = (yield* query2("SELECT material_id FROM catalog_profiles WHERE tenant=@p0 AND material_id=@p1", p.tenant, input2.materialId))[0];
  if (!exists) yield* query2("INSERT INTO catalog_profiles(material_id,tenant,identity_key,attributes,verification,high_use) VALUES(@p0,@p1,@p2,@p3,@p4,0)", m.id, p.tenant, digest2(`legacy:${m.id}`), "{}", "reviewed");
  yield* query2("UPDATE catalog_profiles SET high_use=@p0,preferred_product_id=@p1 WHERE tenant=@p2 AND material_id=@p3", Number(input2.highUse), input2.preferredProductId, p.tenant, input2.materialId);
  yield* audit4(p, "catalog.priority_changed", input2.materialId);
  return { updated: true };
}
function* setPolicy(p, data) {
  admin2(p);
  const input2 = policyInput.parse(data);
  input2.manufacturerIds = input2.manufacturerIds.map((id3) => id3.toLowerCase());
  input2.productIds = input2.productIds.map((id3) => id3.toLowerCase());
  let materialId = null;
  if (input2.materialKey) materialId = String((yield* materialByKey(p, input2.materialKey)).id).toLowerCase();
  for (const id3 of input2.manufacturerIds) if (!(yield* query2("SELECT id FROM manufacturers WHERE tenant=@p0 AND id=@p1", p.tenant, id3)).length) throw new ApiError(400, "Unknown manufacturer.");
  for (const id3 of input2.productIds) {
    const product = (yield* query2("SELECT material_id,manufacturer_id FROM manufacturer_products WHERE tenant=@p0 AND id=@p1 AND active=1", p.tenant, id3))[0];
    if (!product) throw new ApiError(400, "Unknown product.");
    if (materialId && String(product.material_id).toLowerCase() !== materialId) throw new ApiError(400, "Restricted part belongs to another material.");
    if (input2.manufacturerIds.length && !input2.manufacturerIds.map((value) => value.toLowerCase()).includes(String(product.manufacturer_id).toLowerCase())) throw new ApiError(400, "Restricted part is outside the selected manufacturer list.");
  }
  const id2 = input2.id ?? randomUUID11();
  const prior = (yield* query2("SELECT id FROM job_restrictions WHERE tenant=@p0 AND id=@p1", p.tenant, id2))[0];
  if (input2.id && !prior) throw new ApiError(404, "Restriction not found.");
  if (prior) yield* query2("UPDATE job_restrictions SET project=@p0,material_id=@p1,category=@p2,enabled=@p3,manufacturer_ids=@p4,product_ids=@p5 WHERE tenant=@p6 AND id=@p7", input2.projectId, materialId, input2.category, Number(input2.enabled), JSON.stringify(input2.manufacturerIds), JSON.stringify(input2.productIds), p.tenant, id2);
  else yield* query2("INSERT INTO job_restrictions(id,tenant,project,material_id,category,enabled,manufacturer_ids,product_ids) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7)", id2, p.tenant, input2.projectId, materialId, input2.category, Number(input2.enabled), JSON.stringify(input2.manufacturerIds), JSON.stringify(input2.productIds));
  yield* audit4(p, "job.restriction_changed", id2);
  return { id: id2, enabled: input2.enabled };
}
function* validatePurchase(p, project2, materialId, purchase, enforcePolicies = true, allowHistorical = false) {
  const value = purchase ? purchaseSchema.parse(purchase) : void 0;
  if (value?.productId && !allowHistorical) {
    if (!materialId) throw new ApiError(400, "A linked manufacturer product requires a catalog material.");
    const product = yield* productForMaterial(p, materialId, value.productId);
    if (product.manufacturer !== value.manufacturer || product.part_number !== value.partNumber) throw new ApiError(400, "Manufacturer snapshot does not match the selected product.");
  }
  if (!enforcePolicies) return;
  if (materialId && !(yield* materialById(p, materialId)).active) throw new ApiError(400, "This catalog material was retired or corrected. Select its active replacement before purchasing.");
  const profiles = materialId ? yield* query2("SELECT attributes FROM catalog_profiles WHERE tenant=@p0 AND material_id=@p1", p.tenant, materialId) : [];
  let category = profiles[0] ? JSON.parse(profiles[0].attributes).category : null;
  if (!category && materialId) {
    const m = yield* materialById(p, materialId);
    category = JSON.parse(m.details).category;
  }
  const policies = yield* query2("SELECT * FROM job_restrictions WHERE tenant=@p0 AND project=@p1 AND enabled=1", p.tenant, project2);
  for (const policy of policies) {
    if (policy.material_id && String(policy.material_id).toLowerCase() !== materialId) continue;
    if (policy.category && policy.category !== category) {
      if (materialId) continue;
      throw new ApiError(400, "Job restrictions require a classified catalog material.");
    }
    if (!value?.productId || !materialId) throw new ApiError(400, "This job requires an allowed catalog manufacturer product.");
    const product = yield* productForMaterial(p, materialId, value.productId), makers = JSON.parse(policy.manufacturer_ids), products = JSON.parse(policy.product_ids);
    if (makers.length && !makers.includes(String(product.manufacturer_id).toLowerCase()) || products.length && !products.includes(String(product.id).toLowerCase())) throw new ApiError(400, "The selected manufacturer product violates this job restriction.");
  }
}
function* translationsForAdmin(p, materialId) {
  admin2(p);
  yield* materialById(p, materialId);
  return yield* query2("SELECT * FROM translations WHERE tenant=@p0 AND material_id=@p1", p.tenant, materialId);
}
function* rejectTranslation(p, id2) {
  admin2(p);
  if (!(yield* query2("SELECT id FROM translations WHERE id=@p0 AND tenant=@p1", id2, p.tenant)).length) throw new ApiError(404, "Translation not found.");
  yield* query2("UPDATE translations SET active=0 WHERE id=@p0 AND tenant=@p1", id2, p.tenant);
  yield* audit4(p, "translation.rejected", id2);
  return { rejected: true };
}
function* addImageReference(p, data, dry = false, batch = null) {
  admin2(p);
  const input2 = imageReferenceInput.parse(data), m = yield* materialByKey(p, input2.materialKey);
  let productId = null;
  if (input2.manufacturer) {
    const maker = yield* manufacturerByName(p, input2.manufacturer);
    const row2 = maker ? (yield* query2("SELECT p.id FROM manufacturer_products p WHERE p.tenant=@p0 AND p.material_id=@p1 AND p.manufacturer_id=@p2 AND p.normalized_part=@p3 AND p.active=1", p.tenant, m.id, maker.id, key2(input2.partNumber)))[0] : void 0;
    if (!row2) throw new ApiError(400, "Image manufacturer product not found.");
    productId = String(row2.id).toLowerCase();
  }
  const prior = (yield* query2("SELECT id,product_id FROM image_references WHERE tenant=@p0 AND material_id=@p1 AND source_url=@p2", p.tenant, m.id, input2.sourceUrl)).find((row2) => (row2.product_id ? String(row2.product_id).toLowerCase() : null) === productId);
  if (prior) return { id: String(prior.id).toLowerCase(), unchanged: true };
  if (dry) return {};
  const id2 = randomUUID11();
  yield* query2("INSERT INTO image_references(id,tenant,material_id,product_id,source_url,rights_basis,status,batch_id) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,'pending',@p6)", id2, p.tenant, m.id, productId, input2.sourceUrl, input2.rightsBasis, batch);
  yield* audit4(p, "image.reference_imported", id2);
  return { id: id2, unchanged: false };
}
function searchWords(text4) {
  return text4.replace(/(\d)([½¼¾⅛⅜⅝⅞])/g, "$1 $2").normalize("NFKC").replace(/[⁄∕]/g, "/").replace(/\b(\d+)[ -](\d+)\/(\d+)(?=\s*(?:inches|inch|in\b|["″]|pvc\b))/gi, (_all, whole, num, den) => Number(den) ? String(Number(whole) + Number(num) / Number(den)) : _all).replace(/\b(\d+)\/(\d+)(?=\s*(?:inches|inch|in\b|["″]|pvc\b))/gi, (_all, num, den) => Number(den) ? String(Number(num) / Number(den)) : _all).replace(/(\d+(?:\.\d+)?)\s*['′]/g, "$1 ft ").replace(/\b(\d+)\s*(?:feet|foot|ft)\b/gi, "$1 ft").replace(/\bsticks?\b/gi, "").replace(/\bpvc\s+(40|80)\b/gi, "PVC schedule $1").replace(/\s+/g, " ").trim();
}
function* searchCatalog(p, input2, projectId) {
  if (projectId && !(yield* query2("SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, projectId)).length) throw new ApiError(404, "Project not found.");
  const policies = projectId ? yield* query2("SELECT * FROM job_restrictions WHERE tenant=@p0 AND project=@p1 AND enabled=1", p.tenant, projectId) : [];
  const materials = yield* query2("SELECT * FROM materials WHERE tenant=@p0 AND active=1", p.tenant);
  const profiles = yield* query2("SELECT * FROM catalog_profiles WHERE tenant=@p0", p.tenant);
  const aliases = yield* query2("SELECT * FROM translations WHERE tenant=@p0 AND active=1", p.tenant);
  const products = yield* query2("SELECT p.*,m.name AS manufacturer,m.normalized AS manufacturer_normalized FROM manufacturer_products p JOIN manufacturers m ON m.id=p.manufacturer_id AND m.tenant=p.tenant WHERE p.tenant=@p0 AND p.active=1", p.tenant);
  const counts = yield* query2("SELECT material_id,COUNT(*) AS uses FROM selection_events WHERE tenant=@p0 GROUP BY material_id", p.tenant);
  const profilesByMaterial = new Map(profiles.map((row2) => [String(row2.material_id).toLowerCase(), row2]));
  const phrasesByMaterial = /* @__PURE__ */ new Map(), productsByMaterial = /* @__PURE__ */ new Map();
  for (const row2 of aliases) {
    const id2 = String(row2.material_id).toLowerCase();
    const values = phrasesByMaterial.get(id2) ?? [];
    values.push(row2.phrase);
    phrasesByMaterial.set(id2, values);
  }
  for (const row2 of products) {
    const id2 = String(row2.material_id).toLowerCase();
    const values = productsByMaterial.get(id2) ?? [];
    values.push(row2);
    productsByMaterial.set(id2, values);
  }
  const countsByMaterial = new Map(counts.map((row2) => [String(row2.material_id).toLowerCase(), Number(row2.uses)]));
  const rulesByMaterial = /* @__PURE__ */ new Map();
  for (const row2 of policies) {
    const id2 = row2.material_id ? String(row2.material_id).toLowerCase() : "*";
    const values = rulesByMaterial.get(id2) ?? [];
    values.push({ category: row2.category, makers: new Set(JSON.parse(row2.manufacturer_ids)), products: new Set(JSON.parse(row2.product_ids)) });
    rulesByMaterial.set(id2, values);
  }
  const queryWords = searchWords(input2);
  const requestedMakers = [...new Set(products.map((product) => product.manufacturer_normalized))].filter((maker) => new RegExp(`(?:^|[^a-z0-9])${String(maker).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?:$|[^a-z0-9])`, "i").test(input2));
  const results = materials.map((material) => {
    const id2 = String(material.id).toLowerCase(), details2 = JSON.parse(material.details), profile = profilesByMaterial.get(id2), attributes = profile ? JSON.parse(profile.attributes) : {};
    let choices = [...productsByMaterial.get(id2) ?? []];
    if (requestedMakers.length) choices = choices.filter((product) => requestedMakers.includes(product.manufacturer_normalized));
    if (requestedMakers.length && !choices.length) return null;
    const applicable = [...rulesByMaterial.get("*") ?? [], ...rulesByMaterial.get(id2) ?? []].filter((rule) => !rule.category || rule.category === (attributes.category ?? details2.category));
    for (const rule of applicable) choices = choices.filter((product) => (!rule.makers.size || rule.makers.has(String(product.manufacturer_id).toLowerCase())) && (!rule.products.size || rule.products.has(String(product.id).toLowerCase())));
    if (applicable.length && !choices.length) return null;
    const phraseList = [material.description, ...JSON.parse(details2.row.aliases_json), ...phrasesByMaterial.get(id2) ?? []];
    if (attributes.lengthIn) phraseList.push(`${attributes.diameterIn} inch ${attributes.material} ${attributes.type} schedule ${attributes.schedule} ${Number(attributes.lengthIn) / 12} ft`);
    for (const product of choices) phraseList.push(`${product.manufacturer} ${product.part_number} ${product.title} ${material.description}`);
    let q6 = queryWords;
    const span = q6.match(/(?:for\s+(?:a\s+)?)?(\d+(?:\.\d+)?)[ -]*(?:inch|in\b|["″])[ -]*(?:span|spread)/i);
    if (span && attributes.minSpanIn != null && attributes.maxSpanIn != null) {
      if (Number(span[1]) < Number(attributes.minSpanIn) || Number(span[1]) > Number(attributes.maxSpanIn)) return null;
      q6 = q6.replace(span[0], "").trim();
    }
    let rank = 0;
    for (const phrase of new Set(phraseList)) rank = Math.max(rank, score(q6, searchWords(phrase)));
    const schedule = q6.match(/\bsch(?:edule)?\s*(\d+)\b/i)?.[1], expectedSchedule = attributes.schedule ?? material.description.match(/\bsch(?:edule)?\s*(\d+)\b/i)?.[1];
    if (!matchesPhysicalSearch(input2, attributes)) return null;
    const diameter = sizeQueryWithoutRadius(q6).match(/\b(\d+(?:\.\d+|\/\d+)?)\s*(?:inch|in\b|["″])/i)?.[1];
    const mappedTerminology = (phrasesByMaterial.get(id2) ?? []).some((phrase) => score(q6, searchWords(phrase)) >= 90);
    if (!mappedTerminology && (/\bpipe\b/i.test(q6) && attributes.type === "conduit" || /\bconduit\b/i.test(q6) && attributes.type === "pipe")) rank = 0;
    if (schedule && expectedSchedule && String(schedule) !== String(expectedSchedule) || diameter && attributes.diameterIn && Number(diameter) !== Number(attributes.diameterIn)) rank = 0;
    choices.sort((a, b) => Number(key2(input2).includes(key2(b.part_number))) - Number(key2(input2).includes(key2(a.part_number))) || Number(String(b.id).toLowerCase() === String(profile?.preferred_product_id).toLowerCase()) - Number(String(a.id).toLowerCase() === String(profile?.preferred_product_id).toLowerCase()));
    const useCount = countsByMaterial.get(id2) ?? 0;
    return { id: id2, description: material.description, productUnit: material.product_uom, specs: details2.specs, category: details2.category, source: material.dataset_kind === "fixture" ? "verified_fixture" : "verified", verification: profile?.verification ?? "reviewed", score: rank, highUse: Boolean(profile?.high_use) || useCount >= 10, useCount, reason: rank === 100 ? "Exact phrase match" : "Potential specification match", preferredProductId: profile?.preferred_product_id ? String(profile.preferred_product_id).toLowerCase() : null, products: choices.map((product) => ({ id: String(product.id).toLowerCase(), manufacturer: product.manufacturer, partNumber: product.part_number, verification: product.verification })), provenance: { sourceUrl: details2.row.source_url, verificationBasis: details2.row.verification_basis, datasetKind: material.dataset_kind } };
  }).filter((row2) => Boolean(row2 && row2.score >= 85));
  return results.sort((a, b) => b.score - a.score || Number(b.highUse) - Number(a.highUse) || Math.min(b.useCount, 100) - Math.min(a.useCount, 100) || a.description.localeCompare(b.description)).slice(0, 20);
}
var importKinds = ["material", "product", "translation", "image"];
function parseExtendedCsv(csv2) {
  const errors = [], records = [];
  let rowCount = 0;
  try {
    let legacy = false;
    const rows = parse3(csv2, { bom: true, columns: (header2) => {
      const columns = header2.map((value) => value.trim());
      if (columns.some((value) => !value) || new Set(columns).size !== columns.length) throw new Error("Use nonempty, unique template column headers.");
      legacy = columns.length === 2 && columns.includes("kind") && columns.includes("data_json");
      if (!columns.includes("kind") || !legacy && columns.includes("data_json")) throw new Error("Use the Excel-friendly column templates and save as CSV UTF-8 (Comma delimited). Legacy kind,data_json files are also supported.");
      return columns;
    }, skip_empty_lines: true, max_record_size: 2e4 });
    const nonempty = (row2) => Object.values(row2).some((value) => value.trim());
    rowCount = rows.filter(nonempty).length;
    if (!rowCount || rowCount > 2e3) throw new Error("Use 1\u20132000 rows per staged file.");
    const seen = /* @__PURE__ */ new Set(), identities = /* @__PURE__ */ new Map();
    rows.forEach((row2, i) => {
      if (!nonempty(row2)) return;
      try {
        const kind = z20.enum(importKinds).parse(row2.kind.trim().toLowerCase()), schema = { material: materialInput, product: productInput, translation: translationInput, image: imageReferenceInput }[kind], data = schema.parse(legacy ? JSON.parse(row2.data_json) : spreadsheetRecord(kind, row2));
        const identifier = JSON.stringify([kind, data]);
        if (seen.has(identifier)) throw new Error("Duplicate row.");
        const value = data;
        let identifiers = [];
        if (kind === "material") identifiers = ["material-key:" + value.externalKey.toLowerCase(), "material-spec:" + describeMaterial(value).identity];
        if (kind === "product") identifiers = ["product:" + JSON.stringify([key2(value.manufacturer), key2(value.partNumber)])];
        if (kind === "translation") identifiers = ["translation:" + JSON.stringify([value.materialKey.toLowerCase(), phraseKey(value.phrase), value.origin])];
        if (kind === "image") identifiers = ["image:" + JSON.stringify([value.materialKey.toLowerCase(), key2(value.manufacturer ?? ""), key2(value.partNumber ?? ""), value.sourceUrl])];
        const duplicate = identifiers.find((identity2) => identities.has(identity2));
        if (duplicate) throw new Error(`Repeated catalog identity conflicts with row ${identities.get(duplicate)}. Keep one record per material specification, manufacturer part, or translation origin.`);
        seen.add(identifier);
        for (const identity2 of identifiers) identities.set(identity2, i + 2);
        records.push({ kind, data, row: i + 2 });
      } catch (error) {
        errors.push({ row: i + 2, message: error instanceof z20.ZodError ? "Invalid fields: " + error.issues.slice(0, 3).map((issue2) => `${issue2.path.join(".") || "record"}: ${issue2.message}`).join("; ") : error instanceof Error ? error.message : "Invalid JSON." });
      }
    });
    if (new Set(records.map((row2) => row2.kind)).size > 1) errors.push({ row: 1, message: "Stage one record kind per file: materials first, then products/translations/images." });
  } catch (error) {
    errors.push({ row: 1, message: error instanceof Error ? error.message : "Malformed CSV." });
  }
  return { records, errors, rowCount };
}
function* importRecord(p, record2, dry, batch) {
  if (record2.kind === "material") return yield* createMaterial(p, record2.data, dry);
  if (record2.kind === "product") return yield* addProduct(p, record2.data, dry);
  if (record2.kind === "translation") return yield* addTranslation(p, record2.data, dry, batch);
  return yield* addImageReference(p, record2.data, dry, batch);
}
function* previewBulk(p, csv2) {
  admin2(p);
  if (Buffer.byteLength(csv2) > 8e5) throw new ApiError(413, "Stage imports in files up to 800 KB.");
  const hash2 = digest2(csv2), prior = (yield* query2("SELECT * FROM catalog_batches WHERE tenant=@p0 AND digest=@p1", p.tenant, hash2))[0];
  if (prior && prior.state !== "preview") return { id: String(prior.id).toLowerCase(), state: prior.state, report: JSON.parse(prior.report) };
  const parsed = parseExtendedCsv(csv2), id2 = prior ? String(prior.id).toLowerCase() : randomUUID11();
  for (const record2 of parsed.records) {
    try {
      yield* importRecord(p, record2, true, id2);
    } catch (error) {
      parsed.errors.push({ row: record2.row, message: error instanceof Error ? error.message : "Invalid reference." });
    }
  }
  const report = { rows: parsed.rowCount, errors: parsed.errors, created: [] };
  if (prior) yield* query2("UPDATE catalog_batches SET report=@p0 WHERE tenant=@p1 AND id=@p2", JSON.stringify(report), p.tenant, id2);
  else yield* query2("INSERT INTO catalog_batches(id,tenant,digest,state,csv,report,created_at) VALUES(@p0,@p1,@p2,'preview',@p3,@p4,@p5)", id2, p.tenant, hash2, csv2, JSON.stringify(report), (/* @__PURE__ */ new Date()).toISOString());
  yield* audit4(p, "catalog.bulk_previewed", id2);
  return { id: id2, state: "preview", report };
}
function* applyBulk(p, id2, approval) {
  admin2(p);
  if (approval !== "I reviewed this batch") throw new ApiError(400, "Explicit review confirmation required.");
  const batch = (yield* query2("SELECT * FROM catalog_batches WHERE tenant=@p0 AND id=@p1", p.tenant, id2))[0];
  if (!batch) throw new ApiError(404, "Import not found.");
  if (batch.state === "applied") return { unchanged: true };
  if (batch.state !== "preview") throw new ApiError(409, "Rolled back imports cannot be reapplied.");
  const parsed = parseExtendedCsv(batch.csv);
  if (parsed.errors.length || JSON.parse(batch.report).errors.length) throw new ApiError(409, "Resolve preview errors before applying.");
  const created = [];
  for (const record2 of parsed.records) {
    const result = yield* importRecord(p, record2, false, id2);
    if (!result.unchanged) created.push({ kind: record2.kind, id: result.id });
  }
  yield* query2("UPDATE catalog_batches SET state='applied',report=@p0 WHERE tenant=@p1 AND id=@p2", JSON.stringify({ rows: parsed.records.length, errors: [], created }), p.tenant, id2);
  yield* audit4(p, "catalog.bulk_applied", id2);
  return { created: created.length, unchanged: parsed.records.length - created.length };
}
function* rollbackBulk(p, id2) {
  admin2(p);
  const batch = (yield* query2("SELECT * FROM catalog_batches WHERE tenant=@p0 AND id=@p1", p.tenant, id2))[0];
  if (!batch) throw new ApiError(404, "Import not found.");
  if (batch.state === "rolled_back") return { unchanged: true };
  if (batch.state !== "applied") throw new ApiError(409, "Only applied batches can be rolled back.");
  for (const row2 of JSON.parse(batch.report).created) {
    if (row2.kind === "translation") {
      const record2 = (yield* query2("SELECT * FROM translations WHERE tenant=@p0 AND id=@p1", p.tenant, row2.id))[0];
      if (record2) yield* query2("UPDATE translations SET active=0 WHERE tenant=@p0 AND id=@p1 AND batch_id=@p2", p.tenant, row2.id, id2);
    } else if (row2.kind === "material") yield* query2("UPDATE materials SET active=0 WHERE tenant=@p0 AND id=@p1", p.tenant, row2.id);
    else if (row2.kind === "product") yield* query2("UPDATE manufacturer_products SET active=0 WHERE tenant=@p0 AND id=@p1", p.tenant, row2.id);
    else if (row2.kind === "image") yield* query2("UPDATE image_references SET status='withdrawn' WHERE tenant=@p0 AND id=@p1 AND batch_id=@p2", p.tenant, row2.id, id2);
  }
  yield* query2("UPDATE catalog_batches SET state='rolled_back' WHERE tenant=@p0 AND id=@p1", p.tenant, id2);
  yield* audit4(p, "catalog.bulk_rolled_back", id2);
  return { historyPreserved: true };
}
function* selectDiscovery(p, data) {
  const input2 = z20.object({ eventId: z20.uuid(), projectId: z20.string().regex(/^[a-zA-Z0-9._-]{1,64}$/), phrase: z20.string().trim().min(1).max(500), material: materialInput, product: productInput.omit({ materialKey: true }), additionalPhrases: z20.array(z20.string().trim().min(1).max(500)).max(8).default([]) }).strict().parse(data);
  if (!(yield* query2("SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, input2.projectId)).length) throw new ApiError(404, "Project not found.");
  const fingerprint = `${input2.eventId}/${digest2(JSON.stringify(input2)).slice(0, 32)}`;
  const prior = (yield* query2("SELECT id FROM selection_events WHERE id=@p0", input2.eventId))[0];
  if (prior) {
    if (!(yield* query2("SELECT id FROM audit_events WHERE tenant=@p0 AND actor=@p1 AND action='discovery.fingerprint' AND target=@p2", p.tenant, p.oid, fingerprint)).length) throw new ApiError(409, "Discovery identifier already used for another selection.");
    return { unchanged: true };
  }
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const count = (yield* query2("SELECT COUNT(*) AS count FROM audit_events WHERE tenant=@p0 AND actor=@p1 AND action='catalog.discovery_selected' AND at LIKE @p2", p.tenant, p.oid, `${today}%`))[0];
  if (Number(count.count) >= 20) throw new ApiError(429, "The daily provisional discovery limit has been reached.");
  const writer = { ...p, roles: [...p.roles, "Admin"] };
  const material = yield* createMaterial(writer, { ...input2.material, origin: "ai_discovery", verification: "provisional" });
  const m = yield* materialById(p, material.id);
  const product = yield* addProduct(writer, { ...input2.product, materialKey: m.external_key, origin: "ai_discovery", verification: "provisional" });
  const selected = yield* selectMaterial(p, { eventId: input2.eventId, projectId: input2.projectId, materialId: material.id, productId: product.id, phrase: input2.phrase });
  const factText = JSON.stringify(input2.material.attributes).toLowerCase(), numbers = new Set(factText.match(/\d+(?:[./-]\d+)*/g) ?? []);
  const phrases = [...new Set(input2.additionalPhrases)];
  const allowedWords = new Set((describeMaterial(input2.material).description.toLowerCase() + " " + Object.values(input2.material.attributes).join(" ").toLowerCase() + " of the a an for with in inch inches ft foot feet sch schedule adjustable stock stick span spread").match(/[a-z]+/g) ?? []);
  for (const phrase of phrases) {
    if ((phrase.toLowerCase().match(/[a-z]+/g) ?? []).some((word) => !allowedWords.has(word))) throw new ApiError(400, "Generated phrase introduces unsupported terminology.");
    if (/https?:\/\/|<\/?[a-z]/i.test(phrase) || (phrase.match(/\d+(?:[./-]\d+)*/g) ?? []).some((n) => !numbers.has(n))) throw new ApiError(400, "Generated phrase contains unsupported numeric facts or markup.");
    yield* addPhrase(p, material.id, phrase, "ai_generated", null, input2.material.sourceUrl);
  }
  yield* audit4(p, "discovery.fingerprint", fingerprint);
  yield* audit4(p, "catalog.discovery_selected", input2.eventId);
  return { materialId: material.id, productId: product.id, selected, provisional: true };
}
var correctionBase = { reason: z20.string().trim().min(10).max(2e3), expectedHash: z20.string().regex(/^[a-f\d]{64}$/).optional(), approval: z20.string().optional() };
var materialCorrection = z20.object({ id: z20.uuid(), material: materialInput, ...correctionBase }).strict();
var productCorrection = z20.object({ id: z20.uuid(), product: productInput, ...correctionBase }).strict();
var mergeCorrection = z20.object({ sourceId: z20.uuid(), targetId: z20.uuid(), specifications: materialInput, phrases: z20.array(z20.string().trim().min(1).max(500)).max(100).default([]), ...correctionBase }).strict();
function* materialImpact(p, id2) {
  const count = (rows) => Number(rows[0].total);
  return { savedLines: count(yield* query2("SELECT COUNT(*) AS total FROM draft_lines l JOIN drafts d ON d.id=l.draft_id WHERE d.tenant=@p0 AND l.material_id=@p1", p.tenant, id2)), products: count(yield* query2("SELECT COUNT(*) AS total FROM manufacturer_products WHERE tenant=@p0 AND material_id=@p1 AND active=1", p.tenant, id2)), activeRules: count(yield* query2("SELECT COUNT(*) AS total FROM job_restrictions WHERE tenant=@p0 AND material_id=@p1 AND enabled=1", p.tenant, id2)), images: count(yield* query2("SELECT COUNT(*) AS total FROM image_associations WHERE tenant=@p0 AND material_id=@p1", p.tenant, id2)) };
}
function* revision(p, kind, entity, replacement, before, after, reason2, requestKey) {
  const id2 = randomUUID11();
  yield* query2("INSERT INTO catalog_revisions(id,tenant,kind,entity_id,replacement_id,before_json,after_json,reason,actor,created_at,request_key) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10)", id2, p.tenant, kind, entity, replacement, JSON.stringify(before), JSON.stringify(after), reason2, p.oid, (/* @__PURE__ */ new Date()).toISOString(), requestKey);
  yield* audit4(p, "catalog.correction_applied", id2);
  return id2;
}
function* correctCatalog(p, kind, data, apply = false) {
  admin2(p);
  const input2 = { material: materialCorrection, product: productCorrection, merge: mergeCorrection }[kind].parse(data);
  const requestKey = digest2(JSON.stringify({ kind, input: input2 }));
  if (apply) {
    const prior = (yield* query2("SELECT id,replacement_id FROM catalog_revisions WHERE tenant=@p0 AND request_key=@p1", p.tenant, requestKey))[0];
    if (prior) return { id: String(prior.id).toLowerCase(), replacementId: prior.replacement_id ? String(prior.replacement_id).toLowerCase() : null, unchanged: true };
  }
  let before, after, impact, mode;
  if (kind === "material") {
    yield* validateMaterialCategory(p, input2.material);
    const m = yield* materialById(p, input2.id);
    if (!m.active) throw new ApiError(409, "Retired materials are historical records. Correct their active replacement instead.");
    const profile = (yield* query2("SELECT * FROM catalog_profiles WHERE tenant=@p0 AND material_id=@p1", p.tenant, input2.id))[0];
    const built = describeMaterial(input2.material);
    mode = profile && materialIdentity(input2.material.category, m.product_uom, JSON.parse(profile.attributes)) === built.identity ? "metadata" : "replacement";
    if (mode === "metadata" && input2.material.externalKey !== m.external_key) throw new ApiError(400, "Keep the stable key for a metadata correction.");
    if (mode === "replacement" && key2(input2.material.externalKey) === key2(m.external_key)) throw new ApiError(400, "A specification change needs a new stable material key; the old key is retained for history.");
    const origin = profile ? JSON.parse(profile.attributes).recordOrigin ?? "admin_reviewed" : "admin_reviewed";
    const previousDetails = JSON.parse(m.details), oldAttributes = profile ? JSON.parse(profile.attributes) : {};
    const ordered = (value) => JSON.stringify(Object.entries(value).filter(([key3]) => !["category", "recordOrigin"].includes(key3)).sort(([a], [b]) => a.localeCompare(b)));
    const descriptionOnly = mode === "metadata" && input2.material.displayDescription !== void 0 && input2.material.category === oldAttributes.category && input2.material.productUnit === m.product_uom && ordered(input2.material.attributes) === ordered(oldAttributes) && input2.material.sourceUrl === (previousDetails.row?.source_url ?? "") && input2.material.verificationBasis === (previousDetails.row?.verification_basis ?? "");
    const override = input2.material.displayDescription !== void 0 ? input2.material.displayDescription : mode === "metadata" ? previousDetails.displayDescription ?? null : null;
    before = { material: m, profile: profile ?? null };
    after = { ...input2.material, origin, displayDescription: override, verification: descriptionOnly ? profile?.verification ?? "provisional" : "provisional", description: override ?? built.description, descriptionOnly };
    impact = yield* materialImpact(p, input2.id);
    let existing = (yield* query2("SELECT material_id FROM catalog_profiles WHERE tenant=@p0 AND identity_key=@p1", p.tenant, built.identity))[0];
    if (!existing) {
      const profiles = yield* query2("SELECT p.material_id,p.attributes FROM catalog_profiles p JOIN materials m ON m.id=p.material_id AND m.tenant=p.tenant WHERE p.tenant=@p0 AND m.product_uom=@p1", p.tenant, input2.material.productUnit);
      const matches = profiles.filter((row2) => {
        const attributes = JSON.parse(row2.attributes);
        return attributes.category === input2.material.category && materialIdentity(input2.material.category, input2.material.productUnit, attributes) === built.identity;
      });
      if (matches.length > 1) throw new ApiError(409, "Several existing materials share these specifications. Resolve duplicate material records before importing.");
      existing = matches[0];
    }
    if (existing && String(existing.material_id).toLowerCase() !== input2.id.toLowerCase()) {
      after.existingTarget = yield* materialById(p, String(existing.material_id).toLowerCase());
      if (!after.existingTarget.active) throw new ApiError(409, "The matching canonical material is retired. Review it separately before correcting this item.");
    }
  } else if (kind === "product") {
    const product = (yield* query2("SELECT p.*,m.name AS manufacturer FROM manufacturer_products p JOIN manufacturers m ON m.id=p.manufacturer_id AND m.tenant=p.tenant WHERE p.tenant=@p0 AND p.id=@p1", p.tenant, input2.id))[0];
    if (!product) throw new ApiError(404, "Product not found.");
    if (!product.active) throw new ApiError(409, "Retired products are historical records.");
    const material = yield* materialById(p, String(product.material_id).toLowerCase());
    if (!material.active || material.external_key !== input2.product.materialKey) throw new ApiError(400, "This editor retains the current material relationship. Review a wrong material mapping separately.");
    mode = key2(product.manufacturer) === key2(input2.product.manufacturer) && key2(product.part_number) === key2(input2.product.partNumber) ? "metadata" : "replacement";
    before = { product };
    after = { ...input2.product, origin: "admin_reviewed", verification: "provisional" };
    impact = yield* materialImpact(p, String(material.id).toLowerCase());
    if (mode === "replacement") {
      const existing = (yield* query2("SELECT p.* FROM manufacturer_products p JOIN manufacturers m ON m.id=p.manufacturer_id AND m.tenant=p.tenant WHERE p.tenant=@p0 AND m.normalized=@p1 AND p.normalized_part=@p2", p.tenant, key2(input2.product.manufacturer), key2(input2.product.partNumber)))[0];
      if (existing) {
        if (!existing.active) throw new ApiError(409, "The matching manufacturer product is retired. Review it separately.");
        if (String(existing.material_id).toLowerCase() !== String(material.id).toLowerCase()) throw new ApiError(409, "Manufacturer part number is already linked to another material.");
        after.existingTarget = existing;
      }
    }
  } else {
    if (input2.sourceId.toLowerCase() === input2.targetId.toLowerCase()) throw new ApiError(400, "Choose two different materials.");
    const source = yield* materialById(p, input2.sourceId), target = yield* materialById(p, input2.targetId);
    if (!source.active || !target.active) throw new ApiError(409, "Choose two active materials.");
    const profiles = yield* query2("SELECT * FROM catalog_profiles WHERE tenant=@p0 AND (material_id=@p1 OR material_id=@p2)", p.tenant, input2.sourceId, input2.targetId);
    const sourceProfile = profiles.find((row2) => String(row2.material_id).toLowerCase() === input2.sourceId.toLowerCase()), targetProfile = profiles.find((row2) => String(row2.material_id).toLowerCase() === input2.targetId.toLowerCase()), identity2 = describeMaterial(input2.specifications).identity;
    if (!targetProfile || targetProfile.verification !== "reviewed" || targetProfile.identity_key !== identity2) throw new ApiError(409, "The retained material must have the independently reviewed defining specifications.");
    if (source.product_uom !== target.product_uom || sourceProfile && JSON.parse(sourceProfile.attributes).category && sourceProfile.identity_key !== identity2) throw new ApiError(409, "Meaningfully different specifications or units cannot be merged.");
    impact = yield* materialImpact(p, input2.sourceId);
    if (impact.products || impact.activeRules) throw new ApiError(409, "Review linked manufacturer products and disable source-specific active restrictions before retiring a duplicate. Nothing was moved.");
    const sourceDetails = JSON.parse(source.details), available = /* @__PURE__ */ new Set([source.description, ...JSON.parse(sourceDetails.row.aliases_json)]);
    for (const phrase of input2.phrases) if (!available.has(phrase) && !(yield* query2("SELECT id FROM translations WHERE tenant=@p0 AND material_id=@p1 AND phrase=@p2 AND active=1", p.tenant, input2.sourceId, phrase)).length) throw new ApiError(400, "Copy only phrases recorded on the duplicate.");
    before = { source, target, sourceProfile: sourceProfile ?? null, targetProfile };
    after = { targetId: input2.targetId, phrases: input2.phrases, specifications: input2.specifications };
    mode = "retire-duplicate";
  }
  const previewHash = digest2(JSON.stringify({ kind, before, after, impact, reason: input2.reason }));
  if (!apply) return { kind, mode, previewHash, before, after, impact, description: after.description, descriptionOnly: after.descriptionOnly ?? false, requiresReview: true };
  if (input2.approval !== "I reviewed the correction and historical impact") throw new ApiError(400, "Explicit correction review is required.");
  if (input2.expectedHash !== previewHash) throw new ApiError(409, "The catalog or correction changed. Preview it again; nothing was changed.");
  let replacement = null;
  if (kind === "material") {
    if (mode === "replacement") {
      yield* query2("UPDATE materials SET active=0 WHERE tenant=@p0 AND id=@p1", p.tenant, input2.id);
      const { description, existingTarget, descriptionOnly, ...material } = after;
      const created = yield* createMaterial(p, material);
      replacement = created.id;
    } else {
      const old = JSON.parse(before.material.details), row2 = { ...old.row, description: after.description, source_url: after.sourceUrl, verification_basis: after.verificationBasis, specifications_json: JSON.stringify(Object.entries(after.attributes).map(([k, v]) => `${k}: ${v}`)) };
      yield* query2("UPDATE materials SET description=@p0,details=@p1 WHERE tenant=@p2 AND id=@p3", after.description, JSON.stringify({ ...old, displayDescription: after.displayDescription, row: row2, specs: JSON.parse(row2.specifications_json) }), p.tenant, input2.id);
      yield* query2("UPDATE catalog_profiles SET attributes=@p0,verification=@p1 WHERE tenant=@p2 AND material_id=@p3", JSON.stringify({ category: after.category, ...after.attributes, recordOrigin: after.origin }), after.verification, p.tenant, input2.id);
    }
  } else if (kind === "product") {
    if (mode === "replacement") {
      const { existingTarget, ...product } = after;
      const result = yield* addProduct(p, product);
      replacement = result.id;
      const activeTarget = (yield* query2("SELECT active FROM manufacturer_products WHERE tenant=@p0 AND id=@p1", p.tenant, replacement))[0];
      if (!activeTarget?.active) throw new ApiError(409, "The matching manufacturer product is retired. Review it separately.");
      if (replacement === input2.id.toLowerCase()) throw new ApiError(409, "The corrected product identity still resolves to the original.");
      yield* query2("UPDATE manufacturer_products SET active=0 WHERE tenant=@p0 AND id=@p1", p.tenant, input2.id);
      yield* query2("UPDATE catalog_profiles SET preferred_product_id=@p0 WHERE tenant=@p1 AND material_id=@p2 AND preferred_product_id=@p3", null, p.tenant, before.product.material_id, input2.id);
    } else yield* query2("UPDATE manufacturer_products SET title=@p0,source_url=@p1,details_json=@p2,verification='provisional' WHERE tenant=@p3 AND id=@p4", after.title, after.sourceUrl, after.details ? JSON.stringify(after.details) : before.product.details_json ?? "{}", p.tenant, input2.id);
  } else {
    replacement = input2.targetId;
    yield* query2("UPDATE materials SET active=0 WHERE tenant=@p0 AND id=@p1", p.tenant, input2.sourceId);
    for (const phrase of input2.phrases) yield* addPhrase(p, input2.targetId, phrase, "admin_reviewed", null, input2.specifications.sourceUrl);
  }
  const id2 = yield* revision(p, kind, input2.id ?? input2.sourceId, replacement, before, after, input2.reason, requestKey);
  return { id: id2, replacementId: replacement, mode, unchanged: false };
}
function* catalogPage(p, data) {
  admin2(p);
  const input2 = z20.object({ section: z20.enum(["materials", "translations", "policies", "images", "batches", "manufacturers", "revisions"]), page: z20.number().int().min(1).max(1e5).default(1), pageSize: z20.number().int().min(1).max(100).default(25), text: z20.string().trim().max(200).default(""), materialId: z20.uuid().optional(), includeInactive: z20.boolean().default(false), ruleScope: z20.enum(["all", "global"]).default("all"), manufacturerIds: z20.array(z20.uuid()).max(100).optional(), ruleId: z20.uuid().optional(), entityId: z20.uuid().optional() }).strict().parse(data);
  let table = "", columns = "*", where = "tenant=@p0", order = "id";
  const values = [p.tenant];
  switch (input2.section) {
    case "materials":
      table = "materials";
      columns = "id,external_key,description,product_uom,active";
      if (!input2.includeInactive) where += " AND active=1";
      if (input2.text) {
        const pattern = "%" + input2.text.toLowerCase().replace(/[!%_]/g, (c) => "!" + c) + "%";
        values.push(pattern);
        where += " AND (LOWER(description) LIKE @p1 ESCAPE '!' OR LOWER(external_key) LIKE @p1 ESCAPE '!')";
      }
      order = "external_key,id";
      break;
    case "translations":
      if (!input2.materialId) throw new ApiError(400, "Choose a material first.");
      yield* materialById(p, input2.materialId);
      table = "translations";
      values.push(input2.materialId);
      where += " AND material_id=@p1";
      order = "created_at DESC,id";
      break;
    case "policies":
      table = "job_restrictions";
      if (input2.ruleScope === "global") where += " AND material_id IS NULL";
      if (input2.materialId) {
        yield* materialById(p, input2.materialId);
        values.push(input2.materialId);
        where += " AND material_id=@p" + (values.length - 1);
      }
      if (input2.ruleId) {
        values.push(input2.ruleId);
        where += " AND id=@p" + (values.length - 1);
      }
      order = "project,id";
      break;
    case "manufacturers":
      table = "manufacturers";
      columns = "id,name";
      order = "normalized,id";
      if (input2.manufacturerIds) {
        if (!input2.manufacturerIds.length) where += " AND 1=0";
        else {
          where += " AND id IN (" + input2.manufacturerIds.map((id2) => {
            values.push(id2);
            return "@p" + (values.length - 1);
          }).join(",") + ")";
        }
      } else if (input2.text) {
        values.push("%" + input2.text.toLowerCase().replace(/[!%_]/g, (c) => "!" + c) + "%");
        where += " AND LOWER(name) LIKE @p1 ESCAPE '!'";
      }
      break;
    case "revisions":
      table = "catalog_revisions";
      columns = "id,kind,entity_id,replacement_id,reason,actor,created_at";
      order = "created_at DESC,id";
      if (input2.entityId) {
        values.push(input2.entityId);
        where += " AND (entity_id=@p1 OR replacement_id=@p1 OR entity_id IN (SELECT id FROM manufacturer_products WHERE tenant=@p0 AND material_id=@p1))";
      }
      break;
    case "images":
      table = "image_references";
      break;
    case "batches":
      table = "catalog_batches";
      columns = "id,state,report,created_at";
      where += " AND state IN ('preview','applied','rolled_back')";
      order = "created_at DESC,id";
      break;
  }
  const total = Number((yield* query2(`SELECT COUNT(*) AS total FROM ${table} WHERE ${where}`, ...values))[0].total);
  const pages = Math.max(1, Math.ceil(total / input2.pageSize)), page = Math.min(input2.page, pages), start = (page - 1) * input2.pageSize;
  const low = values.length;
  values.push(start, start + input2.pageSize);
  const records = yield* query2(`SELECT * FROM (SELECT ${columns},ROW_NUMBER() OVER(ORDER BY ${order}) AS page_row FROM ${table} WHERE ${where}) paged WHERE page_row>@p${low} AND page_row<=@p${low + 1} ORDER BY page_row`, ...values);
  return { records: records.map(({ page_row, ...row2 }) => row2), total, page, pageSize: input2.pageSize, pages };
}
function* batchDetails(p, data) {
  admin2(p);
  const input2 = z20.object({ id: z20.uuid(), page: z20.number().int().min(1).default(1), includeSource: z20.boolean().default(false) }).strict().parse(data);
  const row2 = (yield* query2("SELECT * FROM catalog_batches WHERE tenant=@p0 AND id=@p1", p.tenant, input2.id))[0];
  if (!row2) throw new ApiError(404, "Import not found.");
  if (JSON.parse(row2.report).workflow === "unpublished-import-v1") throw new ApiError(400, "Open this import in Administration \u2192 Workbook imports.");
  const parsed = parseExtendedCsv(row2.csv), pages = Math.max(1, Math.ceil(parsed.records.length / 25)), page = Math.min(input2.page, pages);
  return { id: String(row2.id).toLowerCase(), state: row2.state, report: JSON.parse(row2.report), ...input2.includeSource ? { sourceCsv: row2.csv } : {}, records: parsed.records.slice((page - 1) * 25, page * 25), page, pages };
}
var catalogExportTables = ["material_categories", "materials", "aliases", "catalog_profiles", "manufacturers", "manufacturer_products", "translations", "selection_events", "job_restrictions", "catalog_batches", "image_references", "image_associations", "import_batches", "catalog_revisions"];
function* catalogExportPage(p, data) {
  admin2(p);
  const input2 = z20.object({ table: z20.enum(catalogExportTables), pageSize: z20.number().int().min(1).max(500).default(250), cursor: z20.object({ id: z20.uuid(), normalized: z20.string().min(1).max(200).optional() }).strict().optional() }).strict().parse(data);
  const alias = input2.table === "aliases", profile = input2.table === "catalog_profiles";
  if (input2.cursor && Boolean(input2.cursor.normalized) !== alias) throw new ApiError(400, "Invalid export cursor for this table.");
  const source = alias ? "aliases a INNER JOIN materials m ON m.id=a.material_id" : input2.table;
  const id2 = alias ? "a.material_id" : profile ? "material_id" : "id", columns = alias ? "a.*,m.tenant" : "*", scope = alias ? "m.tenant" : "tenant";
  const values = [p.tenant];
  let where = `${scope}=@p0`;
  if (input2.cursor) {
    values.push(input2.cursor.id);
    where += alias ? ` AND (${id2}>@p1 OR (${id2}=@p1 AND a.normalized>@p2))` : ` AND ${id2}>@p1`;
    if (alias) values.push(input2.cursor.normalized);
  }
  const limit = values.length;
  values.push(input2.pageSize);
  const rows = yield* query2(`SELECT * FROM (SELECT ${columns},ROW_NUMBER() OVER(ORDER BY ${id2}${alias ? ",a.normalized" : ""}) AS export_row FROM ${source} WHERE ${where}) export_page WHERE export_row<=@p${limit} ORDER BY export_row`, ...values);
  const records = rows.map(({ export_row, ...row2 }) => row2), last = records.at(-1);
  return { records, nextCursor: records.length === input2.pageSize ? { id: String(last[alias || profile ? "material_id" : "id"]).toLowerCase(), ...alias ? { normalized: last.normalized } : {} } : null };
}
function* exportCatalogSnapshot(p) {
  admin2(p);
  const tables = {};
  let count = 0;
  for (const table of catalogExportTables) {
    const source = table === "aliases" ? "aliases a INNER JOIN materials m ON m.id=a.material_id" : table;
    const scope = table === "aliases" ? "m.tenant" : "tenant";
    const columns = table === "aliases" ? "a.*,m.tenant" : "*";
    const size = Number((yield* query2(`SELECT COUNT(*) AS total FROM ${source} WHERE ${scope}=@p0`, p.tenant))[0].total);
    count += size;
    if (count > 1e4) throw new ApiError(413, "Catalog snapshot exceeds 10,000 records. Request a paged export before expanding this catalog.");
    tables[table] = yield* query2(`SELECT ${columns} FROM ${source} WHERE ${scope}=@p0`, p.tenant);
  }
  const snapshot = { format: "etalonops-catalog-snapshot", version: 1, exportedAt: (/* @__PURE__ */ new Date()).toISOString(), tenant: p.tenant, recordCount: count, includesInactive: true, imageFilesIncluded: false, tables };
  if (Buffer.byteLength(JSON.stringify(snapshot), "utf8") > 2e7) throw new ApiError(413, "Catalog snapshot exceeds 20 MB. Request a paged export.");
  yield* audit4(p, "catalog.snapshot_exported", String(count));
  return snapshot;
}
function* catalogAction(p, action, data) {
  if (action === "material-families") return { families: materialFamilies };
  if (action.startsWith("material-workbook-")) return yield* materialWorkbookAction(p, action, data);
  if (["material-table-page", "material-table-row", "material-table-preview", "material-table-save", "material-categories", "material-category-save"].includes(action)) return yield* materialTable(p, action, data);
  if (action.startsWith("designer-")) return yield* designerCommand(p, action, data);
  if (action.startsWith("inbox-")) return yield* inboxAction(p, action, data);
  switch (action) {
    case "prepared-preview":
      return yield* preparedResearchAction(p, data);
    case "prepared-stage":
      return yield* preparedResearchAction(p, data, true);
    case "research-stage":
      return yield* stageResearch(p, data);
    case "research-preview":
      return yield* researchAction(p, data);
    case "research-apply":
      return yield* researchAction(p, data, true);
    case "external-image": {
      const input2 = z20.object({ materialId: z20.uuid(), productId: z20.uuid().nullable() }).parse(data);
      const material = yield* materialById(p, input2.materialId);
      if (!material.active) throw new ApiError(404, "Material not found.");
      const rows = yield* query2("SELECT i.id,i.source_url,i.product_id FROM image_references i LEFT JOIN manufacturer_products p ON p.id=i.product_id AND p.tenant=i.tenant AND p.material_id=i.material_id WHERE i.tenant=@p0 AND i.material_id=@p1 AND i.status='approved' AND (i.product_id IS NULL OR p.active=1)", p.tenant, input2.materialId);
      const match = selectImage(rows, input2.productId);
      return { url: match?.source_url ?? null };
    }
    case "export-page":
      return yield* catalogExportPage(p, data);
    case "preview-material-correction":
      return yield* correctCatalog(p, "material", data);
    case "apply-material-correction":
      return yield* correctCatalog(p, "material", data, true);
    case "preview-product-correction":
      return yield* correctCatalog(p, "product", data);
    case "apply-product-correction":
      return yield* correctCatalog(p, "product", data, true);
    case "preview-duplicate-retirement":
      return yield* correctCatalog(p, "merge", data);
    case "apply-duplicate-retirement":
      return yield* correctCatalog(p, "merge", data, true);
    case "revision-details": {
      admin2(p);
      const id2 = z20.uuid().parse(data.id);
      const row2 = (yield* query2("SELECT * FROM catalog_revisions WHERE tenant=@p0 AND id=@p1", p.tenant, id2))[0];
      if (!row2) throw new ApiError(404, "Revision not found.");
      return { ...row2, before: JSON.parse(row2.before_json), after: JSON.parse(row2.after_json) };
    }
    case "page":
      return yield* catalogPage(p, data);
    case "batch-details":
      return yield* batchDetails(p, data);
    case "export-snapshot":
      return yield* exportCatalogSnapshot(p);
    case "select-discovery":
      return yield* selectDiscovery(p, data);
    case "material":
      return yield* createMaterial(p, data);
    case "product":
      return yield* addProduct(p, data);
    case "translation":
      return yield* addTranslation(p, data);
    case "selection":
      return yield* selectMaterial(p, data);
    case "review-material": {
      admin2(p);
      const input2 = z20.object({ id: z20.uuid(), approval: z20.literal("I verified the defining specifications") }).strict().parse(data);
      yield* materialById(p, input2.id);
      if (!(yield* query2("SELECT material_id FROM catalog_profiles WHERE material_id=@p0 AND tenant=@p1", input2.id, p.tenant)).length) throw new ApiError(409, "Legacy identity needs structured review before verification.");
      yield* query2("UPDATE catalog_profiles SET verification='reviewed' WHERE material_id=@p0 AND tenant=@p1", input2.id, p.tenant);
      yield* audit4(p, "catalog.material_reviewed", input2.id);
      return { reviewed: true };
    }
    case "review-product": {
      admin2(p);
      const input2 = z20.object({ materialId: z20.uuid(), productId: z20.uuid(), approval: z20.literal("I verified this product matches the material specification") }).strict().parse(data);
      yield* productForMaterial(p, input2.materialId, input2.productId);
      yield* query2("UPDATE manufacturer_products SET verification='reviewed' WHERE tenant=@p0 AND id=@p1", p.tenant, input2.productId);
      yield* audit4(p, "catalog.product_reviewed", input2.productId);
      return { reviewed: true };
    }
    case "priority":
      return yield* setPriority(p, data);
    case "policy":
      return yield* setPolicy(p, data);
    case "validate-lines": {
      const body = z20.object({ projectId: z20.string().regex(/^[a-zA-Z0-9._-]{1,64}$/), lines: z20.array(z20.object({ id: z20.uuid(), candidate: z20.object({ id: z20.string() }).nullable(), purchasing: purchaseSchema.optional() }).passthrough()).max(500) }).parse(data);
      if (!(yield* query2("SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, body.projectId)).length) throw new ApiError(404, "Project not found.");
      const issues2 = [];
      for (const line2 of body.lines) {
        try {
          yield* validatePurchase(p, body.projectId, line2.candidate?.id ?? null, line2.purchasing);
        } catch (error) {
          if (!(error instanceof ApiError)) throw error;
          issues2.push({ lineId: line2.id, message: error.message });
        }
      }
      return { issues: issues2, ready: issues2.length === 0 };
    }
    case "details":
      return yield* materialDetails(p, z20.uuid().parse(data.id), z20.string().regex(/^[a-zA-Z0-9._-]{1,64}$/).optional().parse(data.projectId));
    case "translations":
      return yield* translationsForAdmin(p, z20.uuid().parse(data.id));
    case "reject-translation":
      return yield* rejectTranslation(p, z20.uuid().parse(data.id));
    case "image-reference":
      return yield* addImageReference(p, data);
    case "preview":
      return yield* previewBulk(p, z20.string().max(8e5).parse(data.csv));
    case "apply":
      return yield* applyBulk(p, z20.uuid().parse(data.id), z20.string().parse(data.approval));
    case "rollback":
      return yield* rollbackBulk(p, z20.uuid().parse(data.id));
    case "disable-policy": {
      admin2(p);
      const id2 = z20.uuid().parse(data.id);
      if (!(yield* query2("SELECT id FROM job_restrictions WHERE tenant=@p0 AND id=@p1", p.tenant, id2)).length) throw new ApiError(404, "Restriction not found.");
      yield* query2("UPDATE job_restrictions SET enabled=0 WHERE tenant=@p0 AND id=@p1", p.tenant, id2);
      yield* audit4(p, "job.restriction_disabled", id2);
      return { disabled: true };
    }
    case "readiness":
      return yield* catalogReadiness(p, data);
    case "pdf-template-get":
    case "pdf-template-save":
      return yield* templateCommand(p, action, data);
    case "overview":
      admin2(p);
      return { manufacturers: yield* query2("SELECT * FROM manufacturers WHERE tenant=@p0", p.tenant), policies: yield* query2("SELECT * FROM job_restrictions WHERE tenant=@p0", p.tenant), batches: yield* query2("SELECT id,state,report,created_at FROM catalog_batches WHERE tenant=@p0 AND state IN ('preview','applied','rolled_back')", p.tenant), imageReferences: yield* query2("SELECT * FROM image_references WHERE tenant=@p0", p.tenant) };
    default:
      throw new ApiError(404, "Unknown catalog operation.");
  }
}

// server/research-selection.ts
function* selectResearchedProduct(p, data) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required during the AI pilot.");
  const input2 = z21.object({ eventId: z21.uuid(), projectId: z21.string().regex(/^[a-zA-Z0-9._-]{1,64}$/), phrase: z21.string().trim().min(1).max(500), item: researchCandidate.extend({ imageUrl: z21.url().optional() }) }).strict().parse(data), item2 = input2.item;
  const selected = yield* selectDiscovery(p, { eventId: input2.eventId, projectId: input2.projectId, phrase: input2.phrase, material: { externalKey: item2.externalKey, category: item2.category, attributes: item2.attributes, productUnit: item2.productUnit, sourceUrl: item2.sourceUrl, verificationBasis: item2.verificationBasis, verification: "provisional", origin: "ai_discovery" }, product: { manufacturer: item2.manufacturer, partNumber: item2.partNumber, title: item2.title, ...item2.productDetails ? { details: item2.productDetails } : {}, sourceUrl: item2.sourceUrl, verification: "provisional", origin: "ai_discovery" }, additionalPhrases: [] });
  let materialId = selected.materialId, productId = selected.productId;
  if (selected.unchanged) {
    const prior = (yield { text: "SELECT material_id,product_id FROM selection_events WHERE id=@p0 AND tenant=@p1 AND actor=@p2", values: [input2.eventId, p.tenant, p.oid] })[0];
    materialId = String(prior.material_id).toLowerCase();
    productId = String(prior.product_id).toLowerCase();
  }
  const product = yield* productForMaterial(p, materialId, productId);
  const materialKey = (yield { text: "SELECT external_key FROM materials WHERE id=@p0 AND tenant=@p1", values: [materialId, p.tenant] })[0].external_key;
  for (const phrase of [...new Set(item2.phrases)]) yield* addTranslation(p, { materialKey, phrase, sourceUrl: item2.sourceUrl, origin: "ai_generated" });
  if (item2.imageUrl) {
    const image = yield* addImageReference(p, { materialKey, manufacturer: product.manufacturer, partNumber: product.part_number, sourceUrl: item2.imageUrl, rightsBasis: "Owner-managed image usage for selected AI-researched product; source page: " + item2.sourceUrl });
    yield { text: "UPDATE image_references SET status='approved' WHERE id=@p0 AND tenant=@p1 AND status='pending'", values: [image.id, p.tenant] };
  }
  const matches = yield* searchCatalog(p, item2.partNumber, input2.projectId);
  const candidate2 = matches.find((match) => match.id === materialId && match.products.some((product2) => product2.id === productId));
  if (!candidate2) throw new ApiError(409, "This product is unavailable under the current job requirements. No catalog additions from this selection were kept.");
  return { candidate: candidate2, productId, provisional: true };
}

// server/research-ledger.ts
init_contracts();
import { randomUUID as randomUUID12 } from "node:crypto";
import { z as z22 } from "zod";
function* researchLedger(p, action, data) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Live AI research is limited to administrators during development.");
  const period = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
  if (action === "usage" || action === "reserve") {
    const rows = yield { text: "SELECT target FROM audit_events WHERE tenant=@p0 AND action='ai.research.reserved' AND target LIKE @p1", values: [p.tenant, period + "/%"] };
    const settled = yield { text: "SELECT target FROM audit_events WHERE tenant=@p0 AND action='ai.research.settled' AND target LIKE @p1", values: [p.tenant, period + "/%"] };
    const costs = /* @__PURE__ */ new Map();
    for (const row2 of settled) {
      const parts = String(row2.target).split("/"), cost = Number(parts[2]);
      if (costs.has(parts[1]) || !Number.isSafeInteger(cost) || cost < 0 || cost > researchPolicy.reservationMicroUsd) throw new ApiError(503, "AI budget ledger requires review.");
      costs.set(parts[1], cost);
    }
    let committed = 0, held = 0, successful = 0;
    for (const row2 of rows) {
      const parts = String(row2.target).split("/"), reserve = Number(parts[2]);
      if (reserve !== researchPolicy.reservationMicroUsd) throw new ApiError(503, "AI budget ledger requires review.");
      if (costs.has(parts[1])) {
        committed += costs.get(parts[1]);
        successful += costs.get(parts[1]);
      } else {
        committed += reserve;
        held += reserve;
      }
    }
    if (action === "usage") return { period, limitUsd: researchPolicy.monthlyMicroUsd / 1e6, reservedUsd: committed / 1e6, heldUsd: held / 1e6, estimatedSuccessfulUsd: successful / 1e6, requests: rows.length, reservationUsd: researchPolicy.reservationMicroUsd / 1e6 };
    const blocked2 = yield { text: "SELECT id FROM audit_events WHERE tenant=@p0 AND action='ai.research.cost_review'", values: [p.tenant] };
    if (blocked2.length) throw new ApiError(503, "Paid research is paused pending review of unexpected Azure search charges or missing billing usage. Saved research and catalog search remain available.");
    const input2 = z22.object({ requestId: z22.uuid() }).strict().parse(data), target = period + "/" + input2.requestId + "/" + researchPolicy.reservationMicroUsd;
    const prior = yield { text: "SELECT id FROM audit_events WHERE tenant=@p0 AND action='ai.research.reserved' AND target LIKE @p1", values: [p.tenant, "%/" + input2.requestId + "/%"] };
    if (prior.length) throw new ApiError(409, "This research request was already reserved. No automatic paid retry.");
    if (committed + researchPolicy.reservationMicroUsd > researchPolicy.monthlyMicroUsd) throw new ApiError(429, "The $30 monthly AI allowance is committed. Catalog searches and saved research remain available.");
    yield { text: "INSERT INTO audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", values: [randomUUID12(), p.tenant, p.oid, "ai.research.reserved", target, (/* @__PURE__ */ new Date()).toISOString()] };
    return { reservedUsd: researchPolicy.reservationMicroUsd / 1e6 };
  }
  if (action === "save") {
    const input2 = z22.object({ id: z22.uuid(), requestId: z22.uuid(), actualCostMicroUsd: z22.number().int().min(0).max(researchPolicy.reservationMicroUsd), digest: z22.string().regex(/^[a-f0-9]{64}$/), payload: z22.string().max(5e5) }).strict().parse(data);
    const reservations = yield { text: "SELECT target FROM audit_events WHERE tenant=@p0 AND actor=@p1 AND action='ai.research.reserved' AND target LIKE @p2", values: [p.tenant, p.oid, "%/" + input2.requestId + "/%"] };
    if (reservations.length !== 1) throw new ApiError(409, "Research reservation not found.");
    const reservedPeriod = String(reservations[0].target).split("/")[0];
    const settled = yield { text: "SELECT id FROM audit_events WHERE tenant=@p0 AND action='ai.research.settled' AND target LIKE @p1", values: [p.tenant, "%/" + input2.requestId + "/%"] };
    if (settled.length) throw new ApiError(409, "Research usage was already settled.");
    yield { text: "INSERT INTO catalog_batches(id,tenant,digest,state,csv,report,created_at) VALUES(@p0,@p1,@p2,'ai-research',@p3,@p4,@p5)", values: [input2.id, p.tenant, input2.digest, input2.payload, JSON.stringify({ workflow: "live-research-v1", actor: p.oid }), (/* @__PURE__ */ new Date()).toISOString()] };
    yield { text: "INSERT INTO audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", values: [randomUUID12(), p.tenant, p.oid, "ai.research.settled", `${reservedPeriod}/${input2.requestId}/${input2.actualCostMicroUsd}`, (/* @__PURE__ */ new Date()).toISOString()] };
    return { id: input2.id };
  }
  if (action === "finish") {
    const input2 = z22.object({ id: z22.uuid(), payload: z22.string().max(5e5) }).strict().parse(data);
    const row2 = (yield { text: "SELECT report FROM catalog_batches WHERE id=@p0 AND tenant=@p1 AND state='ai-research'", values: [input2.id, p.tenant] })[0];
    if (!row2 || JSON.parse(row2.report).actor !== p.oid) throw new ApiError(404, "Research not found.");
    yield { text: "UPDATE catalog_batches SET csv=@p0 WHERE id=@p1 AND tenant=@p2", values: [input2.payload, input2.id, p.tenant] };
    return { id: input2.id };
  }
  if (action === "list") {
    const rows = yield { text: "SELECT id,csv,report,created_at FROM catalog_batches WHERE tenant=@p0 AND state='ai-research' ORDER BY created_at DESC", values: [p.tenant] };
    return rows.filter((row2) => JSON.parse(row2.report).actor === p.oid).flatMap((row2) => {
      const payload = JSON.parse(row2.csv);
      return payload.internalStep ? [] : [{ id: String(row2.id).toLowerCase(), scope: payload.results.scope, at: row2.created_at, candidates: payload.results.items.length, estimatedUsd: payload.usage.estimatedUsd }];
    }).slice(0, 20);
  }
  if (action === "get") {
    const input2 = z22.object({ id: z22.uuid() }).strict().parse(data);
    const row2 = (yield { text: "SELECT csv,report FROM catalog_batches WHERE id=@p0 AND tenant=@p1 AND state='ai-research'", values: [input2.id, p.tenant] })[0];
    if (!row2 || JSON.parse(row2.report).actor !== p.oid) throw new ApiError(404, "Research not found.");
    return JSON.parse(row2.csv);
  }
  if (action === "cached") {
    const input2 = z22.object({ cacheKey: z22.string().regex(/^[a-f0-9]{64}$/) }).strict().parse(data);
    const rows = yield { text: "SELECT id,csv,report,created_at FROM catalog_batches WHERE tenant=@p0 AND state='ai-research' AND created_at>=@p1 ORDER BY created_at DESC", values: [p.tenant, new Date(Date.now() - 864e5).toISOString()] };
    for (const row2 of rows) {
      const payload = JSON.parse(row2.csv);
      if (payload.cacheKey === input2.cacheKey && JSON.parse(row2.report).actor === p.oid) return { id: String(row2.id).toLowerCase(), ...payload, cached: true };
    }
    return null;
  }
  throw new ApiError(404, "Unknown research ledger operation.");
}

// server/draft-list.ts
init_contracts();
import { z as z23 } from "zod";
function* query3(text4, ...values) {
  return yield { text: text4, values };
}
var draftFilters = z23.object({ text: z23.string().trim().max(120).default(""), deliveryFrom: z23.iso.date().optional(), deliveryTo: z23.iso.date().optional() }).strict().refine((f) => !f.deliveryFrom || !f.deliveryTo || f.deliveryFrom <= f.deliveryTo, "Delivery from must be on or before delivery through.");
function* listSavedDrafts(p, project2, page, filters) {
  z23.string().regex(/^[a-zA-Z0-9._-]{1,64}$/).parse(project2);
  page = z23.number().int().min(1).max(1e5).parse(page);
  const input2 = draftFilters.parse(filters);
  if (!(yield* query3("SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, project2)).length) throw new ApiError(404, "Project not found.");
  const values = [p.tenant, p.oid, project2];
  let where = "d.tenant=@p0 AND d.owner=@p1 AND d.project=@p2 AND NOT EXISTS(SELECT 1 FROM mrf_submissions s WHERE s.draft_id=d.id)";
  if (input2.text) {
    values.push("%" + input2.text.toLowerCase().replace(/[!%_\[]/g, (c) => "!" + c) + "%");
    where += ` AND LOWER(d.name) LIKE @p${values.length - 1} ESCAPE '!'`;
  }
  if (input2.deliveryFrom) {
    values.push(input2.deliveryFrom);
    where += ` AND d.delivery_date>=@p${values.length - 1}`;
  }
  if (input2.deliveryTo) {
    values.push(input2.deliveryTo);
    where += ` AND d.delivery_date<=@p${values.length - 1}`;
  }
  const total = Number((yield* query3(`SELECT COUNT(*) AS total FROM drafts d WHERE ${where}`, ...values))[0].total), pages = Math.max(1, Math.ceil(total / 25));
  page = Math.min(page, pages);
  const start = values.length;
  values.push((page - 1) * 25, page * 25);
  const rows = yield* query3(`SELECT * FROM (SELECT d.id,d.name,d.project,d.delivery_date,d.updated_at,d.version,(SELECT COUNT(*) FROM draft_lines l WHERE l.draft_id=d.id) AS item_count,ROW_NUMBER() OVER(ORDER BY d.updated_at DESC,d.id DESC) AS row_num FROM drafts d WHERE ${where}) saved WHERE row_num>@p${start} AND row_num<=@p${start + 1} ORDER BY row_num`, ...values);
  const iso = (value) => value instanceof Date ? value.toISOString() : String(value);
  return { records: rows.map((r) => ({ id: String(r.id).toLowerCase(), name: r.name, projectId: r.project, deliveryDate: iso(r.delivery_date).slice(0, 10), savedAt: iso(r.updated_at), itemCount: Number(r.item_count), version: Number(r.version) })), total, page, pages };
}

// src/mrf-form.ts
function printedTaskCode(item2, defaultCode) {
  const code = (item2 ?? "").trim();
  return code && code !== (defaultCode ?? "").trim() ? code : "";
}
function effectiveTaskCode(item2, defaultCode) {
  return (item2 ?? "").trim() || (defaultCode ?? "").trim();
}

// server/submissions.ts
init_contracts();
import { createHash as createHash10, randomUUID as randomUUID13 } from "node:crypto";
import { z as z24 } from "zod";
import { stringify } from "csv-stringify/sync";
function* q4(text4, ...values) {
  return yield { text: text4, values };
}
var identity = z24.object({ id: z24.uuid() }).strict();
var reviewInput = z24.object({ draftId: z24.uuid(), version: z24.number().int().positive() }).strict();
var submitInput = reviewInput.extend({ requestId: z24.uuid(), expectedHash: z24.string().regex(/^[a-f\d]{64}$/), confirmation: z24.literal("I reviewed this MRF and want to submit it"), acceptWarnings: z24.boolean() }).strict();
var day = (v) => v instanceof Date ? v.toISOString().slice(0, 10) : String(v);
var guid = (v) => String(v).toLowerCase();
var digest3 = (v) => createHash10("sha256").update(JSON.stringify(v)).digest("hex");
function submissionLabel(number3, revision2) {
  return `MRF-${String(number3).padStart(6, "0")}${revision2 > 1 ? `-R${revision2}` : ""}`;
}
function header(r) {
  return { id: guid(r.id), number: submissionLabel(Number(r.mrf_number), Number(r.revision)), revision: Number(r.revision), previousId: r.previous_id ? guid(r.previous_id) : null, draftId: guid(r.draft_id), draftVersion: Number(r.draft_version), projectId: r.project, submittedAt: r.submitted_at };
}
function* member(p, project2) {
  if (!(yield* q4("SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, project2)).length) throw new ApiError(404, "Project not found.");
}
function* owned(p, id2) {
  const r = (yield* q4("SELECT * FROM mrf_submissions WHERE tenant=@p0 AND owner=@p1 AND id=@p2", p.tenant, p.oid, id2))[0];
  if (!r) throw new ApiError(404, "Submitted MRF not found.");
  yield* member(p, String(r.project));
  return r;
}
function detail2(r) {
  return { ...header(r), snapshot: JSON.parse(r.snapshot), warnings: JSON.parse(r.warnings) };
}
function* prepare(p, v) {
  const d = (yield* q4("SELECT * FROM drafts WHERE tenant=@p0 AND owner=@p1 AND id=@p2", p.tenant, p.oid, v.draftId))[0];
  if (!d) throw new ApiError(404, "Draft not found.");
  yield* member(p, String(d.project));
  if (Number(d.version) !== v.version) throw new ApiError(409, "This draft changed. Save or reload it, then review again.");
  if ((yield* q4("SELECT id FROM mrf_submissions WHERE draft_id=@p0", v.draftId)).length) throw new ApiError(409, "This MRF is already submitted. Open My Submitted MRFs to view it or create a revision.");
  const stored = yield* q4("SELECT * FROM draft_lines WHERE draft_id=@p0 ORDER BY position", v.draftId);
  const lines = stored.map((l) => ({ id: guid(l.id), quantity: String(l.quantity), requestedUnit: l.requested_uom, taskCode: String(l.task_code ?? ""), description: l.description, rawInput: JSON.parse(l.raw_input), candidate: l.candidate ? JSON.parse(l.candidate) : null, source: l.source, deliveryMode: l.delivery_mode, overrideDate: l.override_date ? day(l.override_date) : null, ...l.purchasing ? { purchasing: JSON.parse(l.purchasing) } : {} }));
  const person = (yield* q4("SELECT display_name FROM application_users WHERE tenant=@p0 AND oid=@p1", p.tenant, p.oid))[0];
  let foreman = { id: String(d.foreman_oid ?? p.oid).toLowerCase(), name: String(d.foreman_name ?? p.displayName ?? person?.display_name ?? p.oid) }, foremanError = "";
  try {
    foreman = yield* resolveForeman(p, String(d.project), foreman.id);
  } catch (error) {
    if (!(error instanceof ApiError)) throw error;
    foremanError = error.message;
  }
  const jobMeta = (yield* q4("SELECT name,number,status,details,company_id FROM jobs WHERE tenant=@p0 AND id=@p1", p.tenant, d.project))[0];
  const requesterProfile = (yield* q4("SELECT details FROM user_profiles WHERE tenant=@p0 AND oid=@p1", p.tenant, p.oid))[0];
  const requesterDetails = JSON.parse(String(requesterProfile?.details ?? "{}"));
  const jobDetails = JSON.parse(String(jobMeta?.details ?? "{}"));
  const company = (yield* q4("SELECT name,details FROM companies WHERE tenant=@p0 AND id=@p1", p.tenant, jobMeta?.company_id ?? "main"))[0];
  const outputTemplate = yield* resolveDocumentTemplate(p, String(d.project), String(jobMeta?.company_id ?? "main")), companyLogo = yield* currentCompanyLogo(p, String(jobMeta?.company_id ?? "main"));
  const snapshot = { outputTemplate, companyLogo, form: JSON.parse(String(d.form_json ?? "{}")), jobDetails, companyName: String(company?.name ?? ""), createdAt: new Date(d.updated_at).toISOString(), id: guid(d.id), version: Number(d.version), projectId: String(d.project), projectName: String(jobMeta?.name ?? d.project), projectNumber: String(jobMeta?.number ?? ""), name: d.name, deliveryDate: day(d.delivery_date), foreman, preparedBy: { id: p.oid, phone: String(requesterDetails.phone ?? ""), email: String(requesterDetails.email ?? ""), name: p.displayName ?? person?.display_name ?? p.oid }, lines };
  const errors = [], warnings = [], evidence2 = [];
  if (foremanError) errors.push({ lineId: null, message: foremanError });
  const job = jobMeta;
  if (job && job.status !== "active") errors.push({ lineId: null, message: "This job is archived." });
  if (!String(d.name).trim()) errors.push({ lineId: null, message: "An MRF name is required." });
  if (!lines.length) errors.push({ lineId: null, message: "Add at least one material before submitting." });
  for (const [i, line2] of lines.entries()) {
    const id2 = stored[i].material_id ? guid(stored[i].material_id) : null;
    try {
      yield* validatePurchase(p, String(d.project), id2, line2.purchasing);
    } catch (error) {
      if (!(error instanceof ApiError)) throw error;
      errors.push({ lineId: line2.id, message: error.message });
    }
    if (line2.source.endsWith("_fixture")) warnings.push({ lineId: line2.id, message: "This item is a fictional demonstration fixture; it is not a verified real product." });
    else if (!id2) warnings.push({ lineId: line2.id, message: "This item uses a requester description; purchasing must verify its identity and specifications." });
    if (id2) {
      const material = (yield* q4("SELECT m.description,m.details,m.active,p.attributes,p.verification FROM materials m LEFT JOIN catalog_profiles p ON p.material_id=m.id AND p.tenant=m.tenant WHERE m.tenant=@p0 AND m.id=@p1", p.tenant, id2))[0];
      evidence2.push(material ?? null);
      if (material?.verification === "provisional" || line2.candidate?.verification === "provisional") warnings.push({ lineId: line2.id, message: "This catalog item has provisional facts requiring purchasing review." });
      if (material && line2.candidate && (line2.candidate.description !== material.description || JSON.stringify(line2.candidate.specs) !== JSON.stringify(JSON.parse(material.details).specs))) warnings.push({ lineId: line2.id, message: "Catalog details changed after this line was saved. Review the original requested specifications." });
    }
    if (line2.purchasing?.productId) {
      const product = (yield* q4("SELECT * FROM manufacturer_products WHERE tenant=@p0 AND id=@p1", p.tenant, line2.purchasing.productId))[0];
      evidence2.push(product ?? null);
      if (product?.verification === "provisional") warnings.push({ lineId: line2.id, message: "The manufacturer product has provisional facts requiring purchasing review." });
    } else if (line2.purchasing?.manufacturer) warnings.push({ lineId: line2.id, message: "The requested manufacturer and part number are not linked to a verified catalog product." });
  }
  const policies = yield* q4("SELECT * FROM job_restrictions WHERE tenant=@p0 AND project=@p1 AND enabled=1 ORDER BY id", p.tenant, d.project);
  let previous = null;
  if (d.revision_of) {
    previous = yield* owned(p, guid(d.revision_of));
    const latest = Number((yield* q4("SELECT MAX(revision) AS latest FROM mrf_submissions WHERE tenant=@p0 AND mrf_number=@p1", p.tenant, Number(previous.mrf_number)))[0].latest);
    if (Number(previous.revision) !== latest) errors.push({ lineId: null, message: "A newer revision was submitted. Create a revision from the latest submitted MRF." });
  }
  return { snapshot: { ...snapshot, reviewContext: { catalogEvidence: evidence2, jobRestrictions: policies } }, errors, warnings, ready: errors.length === 0, previousId: previous ? guid(previous.id) : null, revisionTarget: previous ? submissionLabel(Number(previous.mrf_number), Number(previous.revision) + 1) : null, previewHash: digest3({ snapshot, errors, warnings, evidence: evidence2, policies, previousId: previous ? guid(previous.id) : null }) };
}
function* submissions(p, action, data) {
  if (action === "list") {
    const v = z24.object({ projectId: z24.string().regex(/^[a-zA-Z0-9._-]{1,64}$/), page: z24.number().int().min(1).max(1e5).default(1) }).strict().parse(data);
    yield* member(p, v.projectId);
    const total = Number((yield* q4("SELECT COUNT(*) AS total FROM mrf_submissions WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, v.projectId))[0].total), pages = Math.max(1, Math.ceil(total / 25)), page = Math.min(v.page, pages);
    const rows = yield* q4("SELECT * FROM (SELECT id,draft_id,draft_version,mrf_number,revision,previous_id,project,submitted_at,snapshot,ROW_NUMBER() OVER(ORDER BY submitted_at DESC,mrf_number DESC,revision DESC,id) AS n FROM mrf_submissions WHERE tenant=@p0 AND owner=@p1 AND project=@p2) s WHERE n>@p3 AND n<=@p4 ORDER BY n", p.tenant, p.oid, v.projectId, (page - 1) * 25, page * 25);
    return { records: rows.map((r) => ({ ...header(r), name: JSON.parse(r.snapshot).name, itemCount: JSON.parse(r.snapshot).lines.length })), total, page, pages };
  }
  if (action === "get" || action === "export") {
    const r = yield* owned(p, identity.parse(data).id);
    if (action === "get") return detail2(r);
    const value = detail2(r);
    return { filename: value.number + ".csv", csv: submittedCsv(value) };
  }
  if (action === "review") return yield* prepare(p, reviewInput.parse(data));
  if (action === "submit") {
    const v = submitInput.parse(data);
    let prior = (yield* q4("SELECT * FROM mrf_submissions WHERE tenant=@p0 AND request_id=@p1", p.tenant, v.requestId))[0];
    if (prior && (prior.owner !== p.oid || guid(prior.draft_id) !== v.draftId.toLowerCase() || Number(prior.draft_version) !== v.version || prior.preview_hash !== v.expectedHash)) throw new ApiError(409, "Submission request identifier is already used.");
    prior = prior ?? (yield* q4("SELECT * FROM mrf_submissions WHERE tenant=@p0 AND owner=@p1 AND draft_id=@p2", p.tenant, p.oid, v.draftId))[0];
    if (prior) {
      if (Number(prior.draft_version) !== v.version || prior.preview_hash !== v.expectedHash) throw new ApiError(409, "The submitted MRF differs from this review. Open the saved submission.");
      yield* member(p, String(prior.project));
      return { ...detail2(prior), unchanged: true };
    }
    const review = yield* prepare(p, v);
    if (!review.ready) throw new ApiError(400, "Resolve the review errors before submitting.");
    if (review.previewHash !== v.expectedHash) throw new ApiError(409, "The MRF or purchasing requirements changed. Review it again; nothing was submitted.");
    if (review.warnings.length && !v.acceptWarnings) throw new ApiError(400, "Acknowledge the unverified-item warnings before submitting.");
    const previous = review.previousId ? yield* owned(p, review.previousId) : null;
    const number3 = previous ? Number(previous.mrf_number) : Number((yield* q4("SELECT MAX(mrf_number) AS last_number FROM mrf_submissions WHERE tenant=@p0", p.tenant))[0].last_number ?? 0) + 1, revision2 = previous ? Number(previous.revision) + 1 : 1, id2 = randomUUID13(), at = (/* @__PURE__ */ new Date()).toISOString();
    if (number3 > 2e9) throw new ApiError(409, "MRF numbering capacity requires administrator review.");
    yield* q4("INSERT INTO mrf_submissions(id,tenant,owner,project,draft_id,draft_version,mrf_number,revision,previous_id,request_id,preview_hash,snapshot,warnings,submitted_at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10,@p11,@p12,@p13)", id2, p.tenant, p.oid, review.snapshot.projectId, v.draftId, v.version, number3, revision2, review.previousId, v.requestId, v.expectedHash, JSON.stringify(review.snapshot), JSON.stringify(review.warnings), at);
    yield* q4("INSERT INTO audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", randomUUID13(), p.tenant, p.oid, "mrf.submitted", id2, at);
    return detail2(yield* owned(p, id2));
  }
  if (action === "revise") {
    const source = yield* owned(p, identity.parse(data).id), latest = Number((yield* q4("SELECT MAX(revision) AS latest FROM mrf_submissions WHERE tenant=@p0 AND mrf_number=@p1", p.tenant, Number(source.mrf_number)))[0].latest);
    if (latest !== Number(source.revision)) throw new ApiError(409, "Create a revision from the latest submitted MRF.");
    const pending = (yield* q4("SELECT id FROM drafts WHERE tenant=@p0 AND owner=@p1 AND revision_of=@p2", p.tenant, p.oid, source.id))[0];
    if (pending) return { draftId: guid(pending.id), unchanged: true };
    const snapshot = JSON.parse(source.snapshot), id2 = randomUUID13();
    yield* q4("INSERT INTO drafts(id,tenant,owner,project,delivery_date,version,updated_at,name,revision_of) VALUES(@p0,@p1,@p2,@p3,@p4,1,@p5,@p6,@p7)", id2, p.tenant, p.oid, source.project, snapshot.deliveryDate, (/* @__PURE__ */ new Date()).toISOString(), snapshot.name, source.id);
    yield* q4("UPDATE drafts SET foreman_oid=@p0,foreman_name=@p1 WHERE id=@p2 AND tenant=@p3", snapshot.foreman?.id ?? source.owner, snapshot.foreman?.name ?? source.owner, id2, p.tenant);
    yield* q4("UPDATE drafts SET form_json=@p0 WHERE id=@p1 AND tenant=@p2", JSON.stringify(snapshot.form ?? {}), id2, p.tenant);
    for (const [i, line2] of snapshot.lines.entries()) yield* q4("INSERT INTO draft_lines(id,draft_id,position,material_id,quantity,requested_uom,description,raw_input,candidate,source,delivery_mode,override_date,purchasing,task_code) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10,@p11,@p12,@p13)", line2.id, id2, i, line2.candidate && ["verified", "verified_fixture"].includes(line2.source) ? line2.candidate.id : null, line2.quantity, line2.requestedUnit, line2.description, JSON.stringify(line2.rawInput), line2.candidate ? JSON.stringify(line2.candidate) : null, line2.source, line2.deliveryMode, line2.overrideDate, line2.purchasing ? JSON.stringify(line2.purchasing) : null, line2.taskCode ?? "");
    return { draftId: id2, unchanged: false };
  }
  throw new ApiError(404, "Submission operation not found.");
}
function submittedCsv(value) {
  const s = value.snapshot;
  const rows = s.lines.map((l, i) => ({ mrf: value.number, revision: value.revision, name: s.name, project: s.projectId, job_name: s.projectName ?? s.projectId, job_number: s.projectNumber ?? "", foreman: s.foreman.name, prepared_by: s.preparedBy?.name ?? s.foreman.name, submitted_at: value.submittedAt, item: i + 1, description: l.description, default_task_code: s.form?.defaultTaskCode ?? "", task_code: printedTaskCode(l.taskCode, s.form?.defaultTaskCode), effective_task_code: effectiveTaskCode(l.taskCode, s.form?.defaultTaskCode), work_area: s.form?.workArea ?? "", packaging_method: s.form?.packagingMethod ?? "Standard", special_packaging_instructions: s.form?.specialPackagingInstructions ?? "", delivery_contact: s.jobDetails?.deliveryContactName ?? "", delivery_contact_phone: s.jobDetails?.deliveryContactPhone ?? "", purchasing_agent: s.jobDetails?.purchasingAgentName ?? "", ship_to_address: s.jobDetails?.address ?? "", specifications: l.candidate?.specs.join("; ") ?? "", quantity: l.quantity, unit: l.requestedUnit, product_unit: l.candidate?.productUnit ?? "", delivery_date: l.deliveryMode === "override" ? l.overrideDate : s.deliveryDate, manufacturer: l.purchasing?.manufacturer ?? "", manufacturer_part_number: l.purchasing?.partNumber ?? "", no_substitutions: l.purchasing?.noSubstitutions ? "YES" : "NO", source: l.source, verification: l.candidate?.verification ?? "unverified", original_request: l.rawInput.description, review_warnings: value.warnings.filter((w) => w.lineId === l.id).map((w) => w.message).join("; ") }));
  return stringify(rows, { header: true, escape_formulas: true });
}

// server/user-access.ts
init_contracts();
import { randomUUID as randomUUID14 } from "node:crypto";
import { z as z25 } from "zod";
function* q5(text4, ...values) {
  return yield { text: text4, values };
}
var oid = z25.string().regex(/^[a-zA-Z0-9._-]{1,64}$/).transform((value) => value.toLowerCase());
var project = z25.enum(["riverside", "northside"]);
var input = z25.object({ oid, displayName: z25.string().trim().min(1).max(200), active: z25.boolean(), roleLimit: z25.enum(["Admin", "Foreman"]).nullable(), projects: z25.array(project).max(2).refine((a) => new Set(a).size === a.length), version: z25.number().int().nonnegative(), reason: z25.string().trim().min(10).max(2e3) }).strict();
function* row(p, id2) {
  return (yield* q5("SELECT * FROM application_users WHERE tenant=@p0 AND oid=@p1", p.tenant, id2))[0];
}
function* projects(p, id2) {
  return (yield* q5("SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 ORDER BY project", p.tenant, id2)).map((r) => String(r.project));
}
function view2(r, assigned) {
  return { oid: r.oid, displayName: r.display_name, active: Boolean(r.active), roleLimit: r.role_limit, entraAdmin: Boolean(r.entra_admin), version: Number(r.version), createdAt: r.created_at, seenAt: r.seen_at, projects: assigned };
}
function admin3(p) {
  if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
}
function* admitUser(p, localBootstrap = false) {
  p = { ...p, oid: p.oid.toLowerCase() };
  let user = yield* row(p, p.oid);
  const now3 = (/* @__PURE__ */ new Date()).toISOString(), isAdmin = p.roles.includes("Admin");
  if (!user) {
    yield* q5("INSERT INTO application_users(tenant,oid,display_name,active,role_limit,entra_admin,version,created_at,seen_at) VALUES(@p0,@p1,@p2,1,NULL,@p3,1,@p4,@p4)", p.tenant, p.oid, p.displayName ?? p.oid, Number(isAdmin), now3);
    if (localBootstrap) {
      for (const id2 of ["riverside", "northside"]) if (!(yield* q5("SELECT project FROM memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, id2)).length) yield* q5("INSERT INTO memberships(tenant,owner,project) VALUES(@p0,@p1,@p2)", p.tenant, p.oid, id2);
    }
    user = yield* row(p, p.oid);
  }
  if (!user.active) throw new ApiError(403, "Your EtalonOps access is deactivated. Contact an administrator.");
  if (Boolean(user.entra_admin) !== isAdmin || !user.seen_at || String(user.seen_at) < new Date(Date.now() - 15 * 60 * 1e3).toISOString()) yield* q5("UPDATE application_users SET entra_admin=@p0,seen_at=@p1 WHERE tenant=@p2 AND oid=@p3", Number(isAdmin), now3, p.tenant, p.oid);
  const roles = user.role_limit === "Foreman" ? ["Foreman"] : p.roles;
  if (user.role_limit === "Admin" && !isAdmin) throw new ApiError(403, "Microsoft administrator assignment is required for this account.");
  const profile = (yield* q5("SELECT access_role,company_id FROM user_profiles WHERE tenant=@p0 AND oid=@p1", p.tenant, p.oid))[0];
  if (profile) {
    const company = (yield* q5("SELECT active FROM companies WHERE tenant=@p0 AND id=@p1", p.tenant, profile.company_id))[0];
    if (!company?.active) throw new ApiError(403, "Your company access is inactive. Contact your administrator.");
  }
  return { ...p, roles: [...roles.filter((role) => role !== "CompanyAdmin"), ...profile?.access_role === "CompanyAdmin" ? ["CompanyAdmin"] : []] };
}
function* userAccess(p, action, data) {
  if (["assigned-jobs", "directory", "company-save", "job-save", "workforce-save", "revoke-sessions"].includes(action)) return yield* workforce(p, action, data);
  if (action === "foremen") {
    const { projectId } = z25.object({ projectId: z25.string().regex(/^[a-zA-Z0-9._-]{1,64}$/) }).strict().parse(data);
    return yield* foremanRoster(p, projectId);
  }
  if (action === "history" && !p.roles.includes("Admin") && p.roles.includes("CompanyAdmin")) {
    const target = z25.object({ oid }).passthrough().parse(data);
    const mine = (yield* q5("SELECT company_id FROM user_profiles WHERE tenant=@p0 AND oid=@p1", p.tenant, p.oid))[0], other = (yield* q5("SELECT company_id FROM user_profiles WHERE tenant=@p0 AND oid=@p1", p.tenant, target.oid))[0];
    if (!mine || !other || mine.company_id !== other.company_id) throw new ApiError(404, "User not found.");
  } else admin3(p);
  if (action === "list") {
    const v2 = z25.object({ page: z25.number().int().min(1).max(1e5).default(1), text: z25.string().trim().max(200).default("") }).strict().parse(data);
    const pattern = "%" + v2.text.toLowerCase().replace(/[!%_]/g, (c) => "!" + c) + "%";
    const where = "tenant=@p0 AND (LOWER(display_name) LIKE @p1 ESCAPE '!' OR LOWER(oid) LIKE @p1 ESCAPE '!')";
    const total = Number((yield* q5(`SELECT COUNT(*) AS total FROM application_users WHERE ${where}`, p.tenant, pattern))[0].total), pages = Math.max(1, Math.ceil(total / 25)), page = Math.min(v2.page, pages);
    const rows = yield* q5(`SELECT * FROM (SELECT *,ROW_NUMBER() OVER(ORDER BY display_name,oid) AS n FROM application_users WHERE ${where}) u WHERE n>@p2 AND n<=@p3 ORDER BY n`, p.tenant, pattern, (page - 1) * 25, page * 25);
    const assignments = rows.length ? yield* q5("SELECT owner,project FROM memberships WHERE tenant=@p0 AND owner IN (" + rows.map((_, i) => "@p" + (i + 1)).join(",") + ") ORDER BY owner,project", p.tenant, ...rows.map((r) => r.oid)) : [];
    const records = rows.map((r) => view2(r, assignments.filter((a) => String(a.owner).toLowerCase() === String(r.oid).toLowerCase()).map((a) => String(a.project))));
    return { records, total, page, pages };
  }
  if (action === "detail" || action === "history") {
    const v2 = z25.object({ oid, page: z25.number().int().min(1).max(1e5).default(1) }).strict().parse(data);
    const user = yield* row(p, v2.oid);
    if (!user) throw new ApiError(404, "User not found.");
    if (action === "detail") return view2(user, yield* projects(p, v2.oid));
    const total = Number((yield* q5("SELECT COUNT(*) AS total FROM user_access_changes WHERE tenant=@p0 AND oid=@p1", p.tenant, v2.oid))[0].total), pages = Math.max(1, Math.ceil(total / 25)), page = Math.min(v2.page, pages);
    const records = yield* q5("SELECT * FROM (SELECT *,ROW_NUMBER() OVER(ORDER BY created_at DESC,id) AS n FROM user_access_changes WHERE tenant=@p0 AND oid=@p1) h WHERE n>@p2 AND n<=@p3 ORDER BY n", p.tenant, v2.oid, (page - 1) * 25, page * 25);
    return { records: records.map(({ n, before_json, after_json, ...r }) => ({ ...r, before: JSON.parse(before_json)?.registered === false ? null : JSON.parse(before_json), after: JSON.parse(after_json) })), total, page, pages };
  }
  if (action !== "save") throw new ApiError(404, "User operation not found.");
  const v = input.parse(data);
  if ((yield* q5("SELECT oid FROM user_profiles WHERE tenant=@p0 AND oid=@p1", p.tenant, v.oid)).length || (yield* q5("SELECT owner FROM memberships WHERE tenant=@p0 AND supervisor_oid=@p1", p.tenant, v.oid)).length) throw new ApiError(409, "Use the workforce editor to preserve job roles and reporting relationships.");
  const prior = yield* row(p, v.oid);
  if (prior && Number(prior.version) !== v.version || !prior && v.version !== 0) throw new ApiError(409, "User access changed elsewhere. Reload the user before saving.");
  if (v.roleLimit === "Admin" && !prior?.entra_admin) throw new ApiError(400, "Assign the Admin application role in Microsoft first, then have the user sign in. This screen cannot grant Microsoft roles.");
  if (v.oid === p.oid.toLowerCase() && (!v.active || v.roleLimit === "Foreman")) throw new ApiError(409, "You cannot deactivate or demote your own administrator access.");
  const removesAdmin = prior?.active && prior.entra_admin && prior.role_limit !== "Foreman" && (!v.active || v.roleLimit === "Foreman");
  if (removesAdmin && Number((yield* q5("SELECT COUNT(*) AS total FROM application_users WHERE tenant=@p0 AND active=1 AND entra_admin=1 AND (role_limit IS NULL OR role_limit='Admin')", p.tenant))[0].total) <= 1) throw new ApiError(409, "Keep at least one active administrator.");
  const before = prior ? view2(prior, yield* projects(p, v.oid)) : null, now3 = (/* @__PURE__ */ new Date()).toISOString();
  if (prior) yield* q5("UPDATE application_users SET display_name=@p0,active=@p1,role_limit=@p2,version=version+1 WHERE tenant=@p3 AND oid=@p4", v.displayName, Number(v.active), v.roleLimit, p.tenant, v.oid);
  else yield* q5("INSERT INTO application_users(tenant,oid,display_name,active,role_limit,entra_admin,version,created_at) VALUES(@p0,@p1,@p2,@p3,@p4,0,1,@p5)", p.tenant, v.oid, v.displayName, Number(v.active), v.roleLimit, now3);
  yield* q5("DELETE FROM memberships WHERE tenant=@p0 AND owner=@p1", p.tenant, v.oid);
  for (const id2 of v.projects) yield* q5("INSERT INTO memberships(tenant,owner,project) VALUES(@p0,@p1,@p2)", p.tenant, v.oid, id2);
  const after = view2(yield* row(p, v.oid), v.projects);
  yield* q5("INSERT INTO user_access_changes(id,tenant,oid,before_json,after_json,reason,actor,created_at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7)", randomUUID14(), p.tenant, v.oid, JSON.stringify(before ?? { registered: false }), JSON.stringify(after), v.reason, p.oid, now3);
  return after;
}

// server/catalog-history.ts
init_contracts();
function historicalSnapshot(previous, line2) {
  if (!previous || !line2.candidate || String(previous.materialId).toLowerCase() !== line2.candidate.id.toLowerCase() || previous.source !== line2.source || !previous.candidate) return null;
  try {
    const stored = JSON.parse(String(previous.candidate));
    const parsed = candidate.safeParse(stored);
    if (!parsed.success || JSON.stringify(parsed.data) !== JSON.stringify(candidate.parse(line2.candidate))) return null;
    return stored;
  } catch {
    return null;
  }
}

// server/sql-store.ts
init_contracts();
import sql from "mssql";
import { createHash as createHash11, randomUUID as randomUUID15 } from "node:crypto";
import { stringify as stringify2 } from "csv-stringify/sync";

// server/catalog.ts
init_contracts();
import { parse as parse4 } from "csv-parse/sync";
function parseCatalog(file) {
  const rows = [], errors = [];
  let records;
  try {
    records = parse4(file, { bom: true, columns: (header2) => {
      if (header2.length !== csvColumns.length || new Set(header2).size !== header2.length || csvColumns.some((name4) => !header2.includes(name4))) throw new Error("CSV headers must exactly match the v1 contract.");
      return header2;
    }, skip_empty_lines: true, max_record_size: 25e3 });
  } catch {
    return { rows, report: { rows: 0, kind: "", errors: [{ row: 1, message: "Malformed CSV or invalid header." }] } };
  }
  if (!records.length || records.length > 1e3) errors.push({ row: 1, message: "Import must contain 1\u20131000 records." });
  const keys = /* @__PURE__ */ new Set(), aliasOwners = /* @__PURE__ */ new Map();
  records.forEach((record2, i) => {
    try {
      for (const key3 of Object.keys(record2)) if (/^'[\t\r\n =+@\-']/.test(record2[key3])) record2[key3] = record2[key3].slice(1);
      const row2 = importRow.parse(record2);
      if (keys.has(row2.external_key.toLowerCase())) throw new Error("Duplicate external_key.");
      keys.add(row2.external_key.toLowerCase());
      const list = JSON.parse(row2.aliases_json), specs = JSON.parse(row2.specifications_json), conversion = JSON.parse(row2.conversion_basis_json);
      if (!Array.isArray(list) || !list.length || list.length > 50 || !list.every((a) => typeof a === "string" && a.trim() && a.length <= 200)) throw new Error("Aliases must be a nonempty JSON string array.");
      if (!Array.isArray(specs) || specs.length > 30 || !specs.every((s) => typeof s === "string" && s.length <= 500)) throw new Error("Specifications must be a JSON string array.");
      if (conversion !== null) throw new Error("CSV v1 supports null conversion basis only; no conversions are inferred.");
      if (row2.dataset_kind === "reviewed" && !/^https:\/\//.test(row2.source_url)) throw new Error("Reviewed records require an HTTPS evidence URL.");
      if (row2.source_url && new URL(row2.source_url).protocol !== "https:") throw new Error("Source URL must be HTTPS.");
      for (const alias of list) {
        if (!normalize(alias) || normalize(alias).length > 200) throw new Error("Aliases must normalize to 1\u2013200 searchable characters.");
        const key3 = `${normalize(alias)}|${row2.requested_uom}`;
        if (aliasOwners.has(key3) && aliasOwners.get(key3) !== row2.external_key) throw new Error("Ambiguous alias within this file.");
        aliasOwners.set(key3, row2.external_key);
      }
      rows.push(row2);
    } catch (error) {
      errors.push({ row: i + 2, message: error instanceof Error && !("issues" in error) ? error.message : "Invalid fields or unit." });
    }
  });
  const kinds = new Set(rows.map((row2) => row2.dataset_kind));
  if (kinds.size > 1) errors.push({ row: 1, message: "Do not mix fixtures and reviewed records in one batch." });
  return { rows, report: { rows: records.length, errors, kind: rows[0]?.dataset_kind ?? "" } };
}

// server/ai-policy.ts
init_contracts();
var aiLimits = { monthlySessions: 200, monthlyRequests: 400, sessionRequests: 2, userDailyRequests: 20, maxRequestBytes: 12e3, maxOutputTokens: 600, timeoutMs: 15e3 };
function aiPeriod(date2 = /* @__PURE__ */ new Date()) {
  return date2.toISOString().slice(0, 7);
}
function checkAIReservation(rows, p, session, turn, date2 = /* @__PURE__ */ new Date()) {
  const prefix = `${aiPeriod(date2)}/`, target = `${prefix}${session}/${turn}`;
  if (rows.some((row2) => row2.target === target)) throw new ApiError(409, "This AI request was already reserved. It will not be charged or sent again automatically.");
  const month = rows.filter((row2) => row2.target.startsWith(prefix)), sessionRows = month.filter((row2) => row2.target.startsWith(`${prefix}${session}/`));
  if (sessionRows.some((row2) => row2.actor !== p.oid)) throw new ApiError(404, "Lookup session not found.");
  if (month.length >= aiLimits.monthlyRequests) throw new ApiError(429, "The monthly AI request limit has been reached. Use My Description.");
  if (sessionRows.length >= aiLimits.sessionRequests) throw new ApiError(429, "This lookup reached its two AI turns. Use My Description to keep your details.");
  const sessions = new Set(month.map((row2) => row2.target.split("/")[1]));
  if (!sessions.has(session) && sessions.size >= aiLimits.monthlySessions) throw new ApiError(429, "The monthly AI discovery-session limit has been reached.");
  const day2 = date2.toISOString().slice(0, 10);
  if (month.filter((row2) => row2.actor === p.oid && row2.at.startsWith(day2)).length >= aiLimits.userDailyRequests) throw new ApiError(429, "Your daily AI request limit has been reached. Use My Description.");
  return target;
}
function aiUsage(rows, date2 = /* @__PURE__ */ new Date()) {
  return { period: aiPeriod(date2), sessions: new Set(rows.map((row2) => row2.target.split("/")[1])).size, requests: rows.length, limits: aiLimits };
}

// server/image-contracts.ts
import { z as z26 } from "zod";
var imageEvidence = z26.object({
  sourceUrl: z26.url().max(2e3).refine((value) => {
    const u = new URL(value);
    return u.protocol === "https:" && !u.username && !u.password;
  }, "Use a public HTTPS evidence URL without embedded credentials."),
  rightsBasis: z26.string().trim().min(10).max(2e3)
}).strict();
var imageDecision = z26.object({ status: z26.enum(["approved", "rejected"]), approval: z26.string().optional() }).strict().superRefine((value, context) => {
  if (value.status === "approved" && value.approval !== "I verified the product image and usage rights") context.addIssue({ code: "custom", message: "Explicit product and rights review is required." });
});
var imageLimits = { maxAssociations: 500, maxSourceBytes: 5 * 1024 * 1024, maxStoredBytes: 2 * 1024 * 1024, maxPixels: 16e6, maxDimension: 1024 };

// server/sql-store.ts
var now2 = () => (/* @__PURE__ */ new Date()).toISOString();
var isGuid = (value) => /^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/i.test(value);
var dateOnly = (value) => value instanceof Date ? value.toISOString().slice(0, 10) : value;
var SqlStore = class _SqlStore {
  constructor(pool, session) {
    this.pool = pool;
    this.session = session;
  }
  pool;
  session;
  engine = "SQL Server local development";
  async q(text4, ...values) {
    const request = this.session ? new sql.Request(this.session) : this.pool.request();
    values.forEach((value, index) => {
      if (typeof value === "number") request.input(`p${index}`, sql.Int, value);
      else request.input(`p${index}`, sql.NVarChar(sql.MAX), value === null || value === void 0 ? null : String(value));
    });
    return request.query(text4);
  }
  async transaction(work, isolation = sql.ISOLATION_LEVEL.SERIALIZABLE) {
    for (let attempt = 0; ; attempt++) {
      const tx = this.pool.transaction();
      await tx.begin(isolation);
      try {
        const result = await work(new _SqlStore(this.pool, tx));
        await tx.commit();
        return result;
      } catch (error) {
        try {
          await tx.rollback();
        } catch {
        }
        if (attempt >= 2 || !(error instanceof sql.RequestError) || error.number !== 1205) throw error;
        await new Promise((resolve2) => setTimeout(resolve2, 25 * (attempt + 1)));
      }
    }
  }
  async health() {
    await this.q("SELECT 1 AS ready");
  }
  requireAdmin(p) {
    if (!p.roles.includes("Admin")) throw new ApiError(403, "Administrator role required.");
  }
  async member(p, project2) {
    if (!this.session) {
      await this.transaction((tx) => tx.member(p, project2));
      return;
    }
    await this.q("IF NOT EXISTS(SELECT 1 FROM dbo.memberships WITH(UPDLOCK,HOLDLOCK) WHERE tenant=@p0 AND owner=@p1 AND project=@p2) INSERT dbo.memberships(tenant,owner,project) VALUES(@p0,@p1,@p2)", p.tenant, p.oid, project2);
  }
  async requireProject(p, project2) {
    if (!(await this.q("SELECT 1 FROM dbo.memberships WHERE tenant=@p0 AND owner=@p1 AND project=@p2", p.tenant, p.oid, project2)).recordset.length) throw new ApiError(404, "Project not found.");
  }
  async audit(p, action, target, at = now2()) {
    await this.q("INSERT dbo.audit_events(id,tenant,actor,action,target,at) VALUES(@p0,@p1,@p2,@p3,@p4,@p5)", randomUUID15(), p.tenant, p.oid, action, target, at);
  }
  async mapDraft(row2) {
    const submission = (await this.q("SELECT id,mrf_number,revision,submitted_at FROM dbo.mrf_submissions WHERE draft_id=@p0 AND tenant=@p1 AND owner=@p2", row2.id, row2.tenant, row2.owner)).recordset[0];
    const result = await this.q("SELECT * FROM dbo.draft_lines WHERE draft_id=@p0 ORDER BY position", row2.id);
    const lines = result.recordset.map((line2) => ({
      id: String(line2.id).toLowerCase(),
      quantity: String(line2.quantity),
      requestedUnit: line2.requested_uom,
      taskCode: String(line2.task_code ?? ""),
      description: line2.description,
      rawInput: JSON.parse(line2.raw_input),
      candidate: line2.candidate ? JSON.parse(line2.candidate) : null,
      source: line2.source,
      purchasing: line2.purchasing ? JSON.parse(line2.purchasing) : void 0,
      deliveryMode: line2.delivery_mode,
      overrideDate: dateOnly(line2.override_date)
    }));
    return { form: JSON.parse(String(row2.form_json ?? "{}")), ...submission ? { submitted: { id: String(submission.id).toLowerCase(), number: submissionLabel(Number(submission.mrf_number), Number(submission.revision)), revision: Number(submission.revision), submittedAt: String(submission.submitted_at) } } : {}, foreman: { id: String(row2.foreman_oid ?? row2.owner).toLowerCase(), name: String(row2.foreman_name ?? row2.owner) }, revisionOf: row2.revision_of ? String(row2.revision_of).toLowerCase() : null, id: String(row2.id).toLowerCase(), projectId: row2.project, name: row2.name, deliveryDate: String(dateOnly(row2.delivery_date)), version: Number(row2.version), savedAt: new Date(row2.updated_at).toISOString(), lines };
  }
  async getDraft(p, id2) {
    if (!this.session) return this.transaction((tx) => tx.getDraft(p, id2), sql.ISOLATION_LEVEL.READ_COMMITTED);
    if (!isGuid(id2)) throw new ApiError(404, "Draft not found.");
    const row2 = (await this.q("SELECT * FROM dbo.drafts WITH(UPDLOCK,HOLDLOCK) WHERE id=@p0 AND tenant=@p1 AND owner=@p2", id2, p.tenant, p.oid)).recordset[0];
    if (!row2) throw new ApiError(404, "Draft not found.");
    await this.requireProject(p, row2.project);
    return this.mapDraft(row2);
  }
  async listDrafts(p, project2, page = 1, filters = {}) {
    if (!this.session) return this.transaction((tx) => tx.listDrafts(p, project2, page, filters), sql.ISOLATION_LEVEL.READ_COMMITTED);
    return this.catalogRun(listSavedDrafts(p, project2, page, filters));
  }
  async getProjectDraft(p, project2) {
    if (!this.session) return this.transaction((tx) => tx.getProjectDraft(p, project2), sql.ISOLATION_LEVEL.READ_COMMITTED);
    await this.requireProject(p, project2);
    const row2 = (await this.q("SELECT TOP(1) * FROM dbo.drafts WITH(UPDLOCK,HOLDLOCK) WHERE project=@p0 AND tenant=@p1 AND owner=@p2 AND NOT EXISTS(SELECT 1 FROM dbo.mrf_submissions s WHERE s.draft_id=drafts.id) ORDER BY updated_at DESC,id DESC", project2, p.tenant, p.oid)).recordset[0];
    return row2 ? this.mapDraft(row2) : null;
  }
  async saveDraft(p, body, id2) {
    await this.requireProject(p, body.projectId);
    return this.transaction(async (tx) => {
      const existing = id2 ? await tx.getDraft(p, id2) : null;
      if (existing && existing.version !== body.version || !existing && body.version !== 0) throw new ApiError(409, "This draft changed elsewhere. Reload before saving; your on-screen items are preserved.");
      if (existing?.submitted) throw new ApiError(409, "Submitted MRFs cannot be changed. Create a revision from the submitted record.");
      if (existing && existing.projectId !== body.projectId) throw new ApiError(409, "A draft cannot be moved between projects.");
      const job = (await tx.q("SELECT status FROM jobs WHERE tenant=@p0 AND id=@p1", p.tenant, body.projectId)).recordset[0];
      if (job && job.status !== "active") throw new ApiError(409, "This job is archived. Its MRF history is retained.");
      const foreman = await tx.catalogRun(resolveForeman(p, body.projectId, body.foremanId === void 0 ? existing?.foreman?.id ?? p.oid : body.foremanId ?? p.oid));
      const draftId = String(existing?.id ?? randomUUID15());
      if (existing) await tx.q("UPDATE dbo.drafts SET delivery_date=@p0,version=version+1,updated_at=@p1,name=@p5 WHERE id=@p2 AND tenant=@p3 AND owner=@p4", body.deliveryDate, now2(), draftId, p.tenant, p.oid, body.name ?? existing?.name ?? "Untitled MRF");
      else await tx.q("INSERT dbo.drafts(id,tenant,owner,project,delivery_date,version,updated_at,name) VALUES(@p0,@p1,@p2,@p3,@p4,1,@p5,@p6)", draftId, p.tenant, p.oid, body.projectId, body.deliveryDate, now2(), body.name ?? "Untitled MRF");
      await tx.q("UPDATE dbo.drafts SET form_json=@p0 WHERE id=@p1 AND tenant=@p2 AND owner=@p3", JSON.stringify(body.form ?? existing?.form ?? {}), draftId, p.tenant, p.oid);
      await tx.q("UPDATE dbo.drafts SET foreman_oid=@p0,foreman_name=@p1 WHERE id=@p2 AND tenant=@p3 AND owner=@p4", foreman.id, foreman.name, draftId, p.tenant, p.oid);
      const previous = new Map((await tx.q("SELECT id,material_id,purchasing,candidate,source FROM dbo.draft_lines WHERE draft_id=@p0", draftId)).recordset.map((line2) => [String(line2.id).toLowerCase(), { materialId: String(line2.material_id).toLowerCase(), purchasing: line2.purchasing, candidate: line2.candidate, source: line2.source }]));
      await tx.q("DELETE dbo.draft_lines WHERE draft_id=@p0", draftId);
      for (const [index, line2] of body.lines.entries()) {
        let materialId = null;
        let snapshot = line2.candidate;
        const historical = historicalSnapshot(previous.get(line2.id.toLowerCase()), line2);
        if (line2.source === "verified" || line2.source === "verified_fixture") {
          if (!isGuid(line2.candidate.id)) throw new ApiError(400, "Invalid catalog candidate.");
          const material = (await tx.q("SELECT * FROM dbo.materials WHERE id=@p0 AND tenant=@p1", line2.candidate.id, p.tenant)).recordset[0];
          if (!material || !material.active && previous.get(line2.id.toLowerCase())?.materialId !== String(material.id).toLowerCase()) throw new ApiError(400, "Catalog candidate no longer exists. Re-run matching.");
          const details2 = JSON.parse(material.details);
          if (!historical && (line2.source !== (material.dataset_kind === "fixture" ? "verified_fixture" : "verified") || line2.candidate.description !== material.description || line2.candidate.productUnit !== material.product_uom || JSON.stringify(line2.candidate.specs) !== JSON.stringify(details2.specs) || line2.candidate.category !== details2.category)) throw new ApiError(400, "Catalog snapshot does not match its source record.");
          materialId = material.id;
          const profile = (await tx.q("SELECT verification FROM catalog_profiles WHERE tenant=@p0 AND material_id=@p1", p.tenant, materialId)).recordset[0];
          snapshot = historical ?? { ...line2.candidate, verification: profile?.verification ?? "reviewed", provenance: { sourceUrl: details2.row.source_url, verificationBasis: details2.row.verification_basis, datasetKind: material.dataset_kind } };
        }
        await tx.catalogRun(validatePurchase(p, body.projectId, materialId ? String(materialId).toLowerCase() : null, line2.purchasing, false, previous.get(line2.id.toLowerCase())?.materialId === String(materialId).toLowerCase() && previous.get(line2.id.toLowerCase())?.purchasing === JSON.stringify(line2.purchasing)));
        await tx.q(
          "INSERT dbo.draft_lines(id,draft_id,position,material_id,quantity,requested_uom,description,raw_input,candidate,source,delivery_mode,override_date,purchasing) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10,@p11,@p12)",
          line2.id,
          draftId,
          index,
          materialId,
          line2.quantity,
          line2.requestedUnit,
          line2.description,
          JSON.stringify(line2.rawInput),
          snapshot ? JSON.stringify(snapshot) : null,
          line2.source,
          line2.deliveryMode,
          line2.overrideDate,
          line2.purchasing ? JSON.stringify(line2.purchasing) : null
        );
        await tx.q("UPDATE dbo.draft_lines SET task_code=@p0 WHERE id=@p1 AND draft_id=@p2", line2.taskCode ?? "", line2.id, draftId);
      }
      await tx.audit(p, "draft.saved", draftId);
      return tx.getDraft(p, draftId);
    }, sql.ISOLATION_LEVEL.READ_COMMITTED);
  }
  async catalogRun(operation) {
    let step = operation.next();
    while (!step.done) {
      const rows = (await this.q(step.value.text, ...step.value.values)).recordset;
      step = operation.next(rows);
    }
    return step.value;
  }
  async submissions(p, action, data) {
    return this.transaction(async (tx) => {
      const id2 = data?.draftId;
      if ((action === "review" || action === "submit") && typeof id2 === "string") await tx.getDraft(p, id2);
      return tx.catalogRun(submissions(p, action, data));
    });
  }
  async admit(p, localBootstrap = false) {
    return this.transaction((tx) => tx.catalogRun(admitUser(p, localBootstrap)));
  }
  async account(tenant, action, data, p) {
    return this.transaction(async (tx) => {
      await tx.catalogLock({ tenant, oid: p?.oid ?? "site-auth", roles: [] });
      return tx.catalogRun(accountAction(tenant, action, data, p));
    });
  }
  async users(p, action, data) {
    return this.transaction(async (tx) => {
      await tx.catalogLock(p);
      return tx.catalogRun(userAccess(p, action, data));
    });
  }
  async selectResearch(p, data) {
    return this.transaction(async (tx) => {
      await tx.catalogLock(p);
      return tx.catalogRun(selectResearchedProduct(p, data));
    });
  }
  async paidResearch(p, action, data) {
    return this.transaction((tx) => tx.catalogRun(researchLedger(p, action, data)));
  }
  async catalogLock(p) {
    const resource = "etalonops-catalog:" + createHash11("sha256").update(p.tenant).digest("hex");
    const lock = await this.q("DECLARE @result int; EXEC @result=sys.sp_getapplock @Resource=@p0,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000; SELECT @result AS lock_result", resource);
    if (Number(lock.recordset[0].lock_result) < 0) throw new ApiError(409, "Another catalog update is still running. Try again after it finishes.");
  }
  async catalogCommand(p, action, data) {
    return this.transaction(async (tx) => {
      await tx.catalogLock(p);
      return tx.catalogRun(catalogAction(p, action, data));
    });
  }
  async search(p, query4, projectId) {
    return this.catalogRun(searchCatalog(p, query4, projectId));
  }
  async conflicts(p, rows) {
    const errors = [];
    for (const [index, row2] of rows.entries()) {
      if ((await this.q("SELECT 1 FROM dbo.materials WHERE tenant=@p0 AND external_key=@p1", p.tenant, row2.external_key)).recordset.length) errors.push({ row: index + 2, message: "Existing external key: updates require a separate reviewed correction." });
      for (const alias of JSON.parse(row2.aliases_json)) if ((await this.q("SELECT 1 FROM dbo.aliases a JOIN dbo.materials m ON a.material_id=m.id WHERE m.tenant=@p0 AND a.normalized=@p1 AND a.requested_uom=@p2 AND m.active=1", p.tenant, normalize(alias), row2.requested_uom)).recordset.length) errors.push({ row: index + 2, message: "Alias conflicts with an active material." });
    }
    return errors;
  }
  async previewImport(p, file) {
    this.requireAdmin(p);
    return this.transaction(async (tx) => {
      const hash2 = createHash11("sha256").update(file).digest("hex");
      const prior = (await tx.q("SELECT * FROM dbo.import_batches WITH(UPDLOCK,HOLDLOCK) WHERE tenant=@p0 AND hash=@p1", p.tenant, hash2)).recordset[0];
      if (prior) return { id: String(prior.id).toLowerCase(), state: String(prior.state), report: JSON.parse(prior.report) };
      const { rows, report } = parseCatalog(file);
      report.errors.push(...await tx.conflicts(p, rows));
      const id2 = randomUUID15();
      await tx.q("INSERT dbo.import_batches(id,tenant,hash,state,[file],report) VALUES(@p0,@p1,@p2,'preview',@p3,@p4)", id2, p.tenant, hash2, file, JSON.stringify(report));
      await tx.audit(p, "import.previewed", id2);
      return { id: id2, state: "preview", report };
    });
  }
  async applyImport(p, id2, approval, allowFixtures) {
    this.requireAdmin(p);
    if (!isGuid(id2)) throw new ApiError(404, "Import batch not found.");
    return this.transaction(async (tx) => {
      const batch = (await tx.q("SELECT * FROM dbo.import_batches WITH(UPDLOCK,HOLDLOCK) WHERE id=@p0 AND tenant=@p1", id2, p.tenant)).recordset[0];
      if (!batch) throw new ApiError(404, "Import batch not found.");
      if (batch.state === "applied") return { id: id2, state: "applied", unchanged: true };
      if (batch.state !== "preview") throw new ApiError(409, "Rolled-back batches cannot be reapplied.");
      const { rows, report } = parseCatalog(batch.file);
      report.errors.push(...await tx.conflicts(p, rows));
      if (report.errors.length) throw new ApiError(409, "Import has validation/conflict errors. Preview the report.");
      if (approval !== "I reviewed this batch" || report.kind === "fixture" && !allowFixtures) throw new ApiError(400, "Explicit review confirmation required; fixtures cannot enter the production catalog.");
      for (const row2 of rows) {
        const id3 = randomUUID15(), specs = JSON.parse(row2.specifications_json);
        await tx.q(
          "INSERT dbo.materials(id,tenant,external_key,description,product_uom,details,dataset_kind,batch_id) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7)",
          id3,
          p.tenant,
          row2.external_key,
          row2.description,
          row2.product_uom,
          JSON.stringify({ row: row2, specs, category: /pvc|conduit/i.test(row2.description) ? "conduit" : /tape/i.test(row2.description) ? "tape" : "general" }),
          row2.dataset_kind,
          batch.id
        );
        for (const alias of new Set(JSON.parse(row2.aliases_json).map(normalize))) await tx.q("INSERT dbo.aliases VALUES(@p0,@p1,@p2)", id3, alias, row2.requested_uom);
      }
      await tx.q("UPDATE dbo.import_batches SET state='applied',reviewer=@p0,approved_at=@p1 WHERE id=@p2", p.oid, now2(), id2);
      await tx.audit(p, "import.approved", id2);
      return { id: id2, state: "applied", inserted: rows.length };
    });
  }
  async rollbackImport(p, id2) {
    this.requireAdmin(p);
    if (!isGuid(id2)) throw new ApiError(404, "Import batch not found.");
    return this.transaction(async (tx) => {
      const batch = (await tx.q("SELECT * FROM dbo.import_batches WITH(UPDLOCK,HOLDLOCK) WHERE id=@p0 AND tenant=@p1", id2, p.tenant)).recordset[0];
      if (!batch) throw new ApiError(404, "Import batch not found.");
      if (batch.hash === createHash11("sha256").update("catalog-v2-materials").digest("hex")) throw new ApiError(409, "Use structured import history for catalog relationship rollback.");
      if (batch.state === "rolled_back") return { state: "rolled_back", unchanged: true };
      if (batch.state !== "applied") throw new ApiError(409, "Only applied batches can be rolled back.");
      await tx.q("UPDATE dbo.materials SET active=0 WHERE tenant=@p0 AND batch_id=@p1", p.tenant, id2);
      await tx.q("UPDATE dbo.import_batches SET state='rolled_back' WHERE id=@p0", id2);
      await tx.audit(p, "import.rolled_back", id2);
      return { state: "rolled_back", historyPreserved: true };
    });
  }
  async aiReservations(p, period = aiPeriod()) {
    return (await this.q("SELECT actor,target,at FROM dbo.audit_events WITH(UPDLOCK,HOLDLOCK) WHERE tenant=@p0 AND action='ai.reserved' AND target LIKE @p1", p.tenant, `${period}/%`)).recordset.map((row2) => ({ actor: row2.actor, target: row2.target, at: new Date(row2.at).toISOString() }));
  }
  async reserveAI(p, project2, session, turn) {
    return this.transaction(async (tx) => {
      await tx.requireProject(p, project2);
      const date2 = /* @__PURE__ */ new Date();
      const target = checkAIReservation(await tx.aiReservations(p, aiPeriod(date2)), p, session, turn, date2);
      await tx.audit(p, "ai.reserved", target, date2.toISOString());
      return target;
    });
  }
  async aiUsage(p) {
    this.requireAdmin(p);
    const date2 = /* @__PURE__ */ new Date();
    return aiUsage(await this.aiReservations(p, aiPeriod(date2)), date2);
  }
  async imageMaterial(p, id2, activeOnly = false) {
    if (!isGuid(id2)) throw new ApiError(404, "Material not found.");
    const row2 = (await this.q("SELECT id,active FROM dbo.materials WHERE tenant=@p0 AND id=@p1", p.tenant, id2)).recordset[0];
    if (!row2 || activeOnly && !row2.active) throw new ApiError(404, "Material not found.");
  }
  mapImage(row2) {
    return { id: String(row2.id).toLowerCase(), materialId: String(row2.material_id).toLowerCase(), productId: row2.product_id ? String(row2.product_id).toLowerCase() : null, contentHash: row2.content_hash, sourceUrl: row2.source_url, rightsBasis: row2.rights_basis, status: row2.status, reviewer: row2.reviewer ?? null, reviewedAt: row2.reviewed_at ? new Date(row2.reviewed_at).toISOString() : null };
  }
  async listImages(p, id2) {
    this.requireAdmin(p);
    await this.imageMaterial(p, id2);
    return (await this.q("SELECT * FROM dbo.image_associations WHERE tenant=@p0 AND material_id=@p1 ORDER BY reviewed_at DESC,id", p.tenant, id2)).recordset.map((row2) => this.mapImage(row2));
  }
  async approvedImage(p, id2, productId = null) {
    await this.imageMaterial(p, id2);
    const rows = (await this.q("SELECT i.* FROM dbo.image_associations i LEFT JOIN dbo.manufacturer_products p ON p.id=i.product_id AND p.tenant=i.tenant AND p.material_id=i.material_id WHERE i.tenant=@p0 AND i.material_id=@p1 AND i.status='approved' AND (i.product_id IS NULL OR p.active=1)", p.tenant, id2)).recordset;
    const row2 = selectImage(rows, productId);
    return row2 ? this.mapImage(row2) : null;
  }
  async submitImage(p, id2, hash2, evidence2, productId = null) {
    this.requireAdmin(p);
    return this.transaction(async (tx) => {
      await tx.imageMaterial(p, id2, true);
      if (productId) await tx.catalogRun(productForMaterial(p, id2, productId));
      const prior = (await tx.q("SELECT * FROM dbo.image_associations WITH(UPDLOCK,HOLDLOCK) WHERE tenant=@p0 AND material_id=@p1 AND content_hash=@p2", p.tenant, id2, hash2)).recordset[0];
      if (prior) {
        if ((prior.product_id ? String(prior.product_id).toLowerCase() : null) !== productId) throw new ApiError(409, "These bytes already belong to another image scope; select a different photo.");
        if (prior.status === "rejected") throw new ApiError(409, "This image was rejected for this product; choose a different image.");
        return tx.mapImage(prior);
      }
      const count = (await tx.q("SELECT COUNT(*) AS count FROM dbo.image_associations WITH(UPDLOCK,HOLDLOCK) WHERE tenant=@p0", p.tenant)).recordset[0];
      if (Number(count.count) >= imageLimits.maxAssociations) throw new ApiError(429, "The pilot limit of 500 retained image associations has been reached.");
      const imageId = randomUUID15();
      await tx.q("INSERT dbo.image_associations(id,tenant,material_id,content_hash,source_url,rights_basis,status,product_id) VALUES(@p0,@p1,@p2,@p3,@p4,@p5,'pending',@p6)", imageId, p.tenant, id2, hash2, evidence2.sourceUrl, evidence2.rightsBasis, productId);
      await tx.audit(p, "image.uploaded", imageId);
      return (await tx.listImages(p, id2)).find((image) => image.id === imageId);
    });
  }
  async reviewImage(p, id2, imageId, status) {
    this.requireAdmin(p);
    if (!isGuid(imageId)) throw new ApiError(404, "Image association not found.");
    return this.transaction(async (tx) => {
      await tx.imageMaterial(p, id2);
      await tx.q("SELECT id FROM dbo.materials WITH(UPDLOCK,HOLDLOCK) WHERE id=@p0 AND tenant=@p1", id2, p.tenant);
      const row2 = (await tx.q("SELECT * FROM dbo.image_associations WHERE tenant=@p0 AND material_id=@p1 AND id=@p2", p.tenant, id2, imageId)).recordset[0];
      if (!row2) throw new ApiError(404, "Image association not found.");
      if (row2.status === status) return tx.mapImage(row2);
      if (row2.status === "rejected" && status === "approved") throw new ApiError(409, "Rejected associations cannot be silently reapproved. Upload a different reviewed image.");
      if (status === "approved") {
        await tx.imageMaterial(p, id2, true);
        const replaced = (await tx.q("SELECT id FROM dbo.image_associations WHERE tenant=@p0 AND material_id=@p1 AND status='approved' AND ((product_id IS NULL AND @p2 IS NULL) OR product_id=@p2)", p.tenant, id2, row2.product_id)).recordset;
        await tx.q("UPDATE dbo.image_associations SET status='rejected',reviewer=@p0,reviewed_at=@p1 WHERE tenant=@p2 AND material_id=@p3 AND status='approved' AND ((product_id IS NULL AND @p4 IS NULL) OR product_id=@p4)", p.oid, now2(), p.tenant, id2, row2.product_id);
        for (const old of replaced) await tx.audit(p, "image.replaced", String(old.id));
      }
      await tx.q("UPDATE dbo.image_associations SET status=@p0,reviewer=@p1,reviewed_at=@p2 WHERE tenant=@p3 AND material_id=@p4 AND id=@p5", status, p.oid, now2(), p.tenant, id2, imageId);
      await tx.audit(p, `image.${status}`, imageId);
      return (await tx.listImages(p, id2)).find((image) => image.id === imageId);
    });
  }
  async listImports(p) {
    this.requireAdmin(p);
    const rows = (await this.q("SELECT TOP (50) id,state,report,reviewer,approved_at FROM dbo.import_batches WHERE tenant=@p0 AND hash<>@p1 ORDER BY approved_at DESC,id", p.tenant, createHash11("sha256").update("catalog-v2-materials").digest("hex"))).recordset;
    return rows.map((row2) => ({ id: String(row2.id).toLowerCase(), state: String(row2.state), report: JSON.parse(row2.report), reviewer: row2.reviewer ? String(row2.reviewer) : null, approvedAt: row2.approved_at ? new Date(row2.approved_at).toISOString() : null }));
  }
  async exportCsv(p) {
    this.requireAdmin(p);
    const records = (await this.q("SELECT details FROM dbo.materials WHERE tenant=@p0 AND active=1 ORDER BY external_key", p.tenant)).recordset;
    return stringify2(records.map((record2) => {
      const row2 = JSON.parse(record2.details).row;
      return Object.fromEntries(csvColumns.map((column) => {
        const value = row2[column];
        return [column, /^[\t\r\n =+@\-']/.test(value) ? `'${value}` : value];
      }));
    }), { header: true, columns: csvColumns });
  }
};

// scripts/publication-import/run.ts
init_image_assets();

// scripts/publication-import/core.ts
import { createHash as createHash13 } from "node:crypto";
import { z as z27 } from "zod";
var importRecordSchema = z27.object({ ref: z27.string().min(1).max(200), originalKey: z27.string().max(100), row: z27.record(z27.string(), z27.string()), material: materialInput, phrases: z27.array(z27.string().min(1).max(500)).max(100), baselineSignature: z27.string().optional(), image: z27.object({ file: z27.string().regex(/^images\/[a-zA-Z0-9_.-]+$/), sha256: z27.string().regex(/^[a-f0-9]{64}$/), sourceUrl: z27.url(), width: z27.number().positive(), height: z27.number().positive() }).strict().optional() }).strict();
var packageSchema = z27.object({ format: z27.literal("etalonops-publication-import-v1"), source: z27.literal("Publication Review R2"), expectedTenantHash: z27.string().regex(/^[a-f0-9]{64}$/), held: z27.literal(28), records: z27.array(importRecordSchema).min(1).max(1e3) }).strict();
function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map((k) => [k, stable(value[k])]));
  return value;
}
var hash = (v) => createHash13("sha256").update(JSON.stringify(stable(v))).digest("hex");
var normId = (v) => String(v ?? "").toLowerCase();
function signature(m, profile) {
  const details2 = JSON.parse(m.details ?? "{}"), a = profile ? JSON.parse(profile.attributes) : {};
  return hash({ key: m.external_key, description: m.description, unit: m.product_uom, identity: materialIdentity(a.category ?? "general", m.product_uom, a), source: details2.row?.source_url ?? "", notes: details2.row?.verification_basis ?? "" });
}
function desiredSignature(m) {
  return hash({ key: m.externalKey, description: m.displayDescription, unit: m.productUnit, identity: materialIdentity(m.category, m.productUnit, m.attributes), source: m.sourceUrl, notes: m.verificationBasis });
}
function reconcile(records, snapshot) {
  const tables = snapshot.tables, mats = tables.materials, profiles = new Map(tables.catalog_profiles.map((p) => [normId(p.material_id), p]));
  const identities = /* @__PURE__ */ new Map();
  for (const m of mats) {
    const p = profiles.get(normId(m.id));
    if (!p) continue;
    const a = JSON.parse(p.attributes), id2 = materialIdentity(a.category ?? "general", m.product_uom, a);
    identities.set(id2, [...identities.get(id2) ?? [], m]);
  }
  const prepared = [], seen = /* @__PURE__ */ new Set(), matches = [];
  for (const [i, r] of records.entries()) {
    const identity2 = materialIdentity(r.material.category, r.material.productUnit, r.material.attributes);
    if (seen.has(identity2)) throw Error("Duplicate physical identity in package: " + r.ref);
    seen.add(identity2);
    const byKey = r.originalKey ? mats.find((m) => normId(m.external_key) === normId(r.originalKey)) : void 0;
    if (r.originalKey && !byKey) throw Error("Previously exported key is missing from live catalog: " + r.originalKey);
    const candidates = identities.get(identity2) ?? [];
    if (candidates.length > 1) throw Error("Multiple catalog materials match " + r.ref + "; resolve the duplicate first.");
    const match = byKey ?? candidates[0];
    if (match && !match.active) throw Error("Matching material is retired: " + match.external_key);
    if (byKey) {
      const p = profiles.get(normId(byKey.id));
      if (!p || !candidates.some((m) => normId(m.id) === normId(byKey.id))) throw Error("Existing key now has different physical specifications: " + r.originalKey);
      const current = signature(byKey, p);
      if (r.baselineSignature && current !== r.baselineSignature && current !== desiredSignature(r.material)) throw Error("Existing material changed after the supplied snapshot: " + r.originalKey + ". Refresh the export before overwriting it.");
    }
    const row2 = byKey ? { ...r.row } : match ? { key: match.external_key, phrases: r.phrases.join("\n"), image: r.row.image ?? "" } : { ...r.row };
    if (match) {
      row2.key = match.external_key;
      const uploaded = (tables.image_associations ?? []).some((x) => normId(x.material_id) === normId(match.id) && x.status === "approved");
      const reference2 = (tables.image_references ?? []).some((x) => normId(x.material_id) === normId(match.id) && !x.product_id && x.status === "approved");
      if (uploaded || reference2) row2.image = "";
    }
    row2._row = String(i + 2);
    prepared.push(row2);
    matches.push({ ref: r.ref, identity: identity2, existingId: match ? normId(match.id) : null, existingKey: match?.external_key ?? null, kind: byKey ? "reviewed metadata" : match ? "reuse" : "new" });
  }
  return { prepared, matches };
}
async function validateChunks(store, p, rows, progress = () => {
}) {
  const chunks = [];
  for (let i = 0; i < rows.length; i += 50) {
    const part = rows.slice(i, i + 50), filename = "R2-ready-" + String(i / 50 + 1).padStart(2, "0") + ".xlsx";
    const preview = await store.catalogCommand(p, "material-workbook-preview", { filename, rows: part });
    if (preview.summary.errors || preview.summary.duplicates) throw Error("Import conflicts: " + JSON.stringify(preview.results.filter((r) => ["Needs correction", "Duplicate in workbook"].includes(r.status))));
    chunks.push({ rows: part, preview });
    progress(`Validated ${Math.min(i + 50, rows.length)} / ${rows.length} materials`);
  }
  return chunks;
}
async function applyChunk(store, p, rows, filename, approveImages) {
  const preview = await store.catalogCommand(p, "material-workbook-preview", { filename, rows });
  if (preview.summary.errors || preview.summary.duplicates) throw Error("Catalog changed; a batch now has conflicts. Nothing further was applied.");
  if (!preview.summary.new && !preview.summary.updated) return { summary: preview.summary, publication: null };
  const batch = await store.catalogCommand(p, "material-workbook-apply", { filename, rows, previewHash: preview.previewHash });
  if (!batch.id) return { summary: batch.workbookSummary, publication: null };
  const itemIds = batch.items.filter((r) => r.state === "unpublished" && (approveImages || r.kind !== "image")).map((r) => r.id);
  if (!itemIds.length) return { summary: batch.workbookSummary, publication: null, pendingImages: true };
  const plan = await store.catalogCommand(p, "inbox-plan", { id: batch.id, version: batch.version, itemIds });
  if (plan.held.length) throw Error("Publication has held records: " + JSON.stringify(plan.held));
  const published = await store.catalogCommand(p, "inbox-publish-ready", { id: batch.id, version: batch.version, itemIds, planHash: plan.planHash, approval: "I approve and publish these records" });
  return { summary: batch.workbookSummary, publication: published.publication };
}
async function attachReviewedImages(store, p, records, matches, images, assets, approve, progress = () => {
}) {
  const { imageKey: imageKey2 } = await Promise.resolve().then(() => (init_image_assets(), image_assets_exports));
  const stats = { uploaded: 0, preserved: 0, alreadyApproved: 0, pending: 0 };
  for (const [i, r] of records.entries()) {
    if (!r.image) continue;
    const id2 = matches[i].existingId;
    if (!id2) throw Error("Imported material cannot be found for " + r.ref);
    const image = images.get(r.image.file);
    if (!image) throw Error("Normalized image is unavailable: " + r.image.file);
    const stored = await store.listImages(p, id2);
    if (stored.some((x) => x.status === "approved")) {
      if (stored.some((x) => x.status === "approved" && x.contentHash === image.hash)) stats.alreadyApproved++;
      else stats.preserved++;
      continue;
    }
    const key3 = imageKey2(p.tenant, id2, image.hash);
    await assets.put(key3, image.bytes);
    const association = await store.submitImage(p, id2, image.hash, { sourceUrl: r.image.sourceUrl, rightsBasis: "Owner-managed representative catalog image from the reviewed R2 package; no independent license assertion." }, null);
    if (approve) {
      if (createHash13("sha256").update(await assets.get(key3)).digest("hex") !== image.hash) throw Error("Stored image verification failed.");
      await store.reviewImage(p, id2, association.id, "approved");
      stats.uploaded++;
    } else stats.pending++;
    progress({ ...stats });
  }
  return stats;
}

// scripts/publication-import/run.ts
process.umask(63);
var args = new Set(process.argv.slice(2));
var root = resolve(process.env.ETALONOPS_IMPORT_ROOT ?? ".");
var statePath = join2(root, ".runtime", "state.json");
mkdirSync(dirname(statePath), { recursive: true });
function az(values) {
  try {
    return JSON.parse(execFileSync("az", [...values, "--output", "json"], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }));
  } catch {
    throw Error("An authenticated Azure CLI read failed. Check Cloud Shell sign-in; no credential output is needed.");
  }
}
var fail2 = (message) => {
  throw Error(message);
};
async function main() {
  if (args.has("--check-package")) {
    const bytes = readFileSync(join2(root, "materials.json"));
    if (createHash14("sha256").update(bytes).digest("hex") !== readFileSync(join2(root, "materials.sha256"), "utf8").trim()) fail2("Material checksum mismatch.");
    const d = packageSchema.parse(JSON.parse(bytes.toString())), seen = /* @__PURE__ */ new Set();
    for (const r of d.records) {
      if (!r.image || seen.has(r.image.file)) continue;
      const bytes2 = readFileSync(join2(root, r.image.file));
      if (createHash14("sha256").update(bytes2).digest("hex") !== r.image.sha256) fail2("Image checksum mismatch.");
      await normalizeImage(bytes2);
      seen.add(r.image.file);
    }
    console.log("Package verified without Azure access: " + d.records.length + " materials, " + seen.size + " assets, 28 held records excluded.");
    return;
  }
  if (args.has("--prepare-state")) {
    const account2 = az(["account", "show"]);
    if (account2.id !== "a428f249-9b2a-4314-8619-6b3fd33c805e") fail2("Select the existing Azure Standard subscription first.");
    const owner = az(["ad", "signed-in-user", "show"]), resourceGroup = "rg-etalonops-poc", appName = "etalonops-954bb4a3", sqlName = "etalonops-954bb4a3-sql";
    const admins = az(["sql", "server", "ad-admin", "list", "-g", resourceGroup, "--server-name", sqlName]);
    if (admins.length !== 1 || normId(admins[0].sid) !== normId(owner.id)) fail2("The signed-in user must be the existing SQL administrator. No permissions are changed.");
    const rows = az(["webapp", "config", "appsettings", "list", "-g", resourceGroup, "-n", appName, "--query", "[?name=='ETALONOPS_TENANT_ID' || name=='ETALONOPS_SQL_HOST' || name=='ETALONOPS_STORAGE_ACCOUNT'].{name:name,value:value}"]), settings = Object.fromEntries(rows.map((r) => [r.name, r.value]));
    if (normId(settings.ETALONOPS_TENANT_ID) !== normId(account2.tenantId) || settings.ETALONOPS_SQL_HOST !== sqlName + ".database.windows.net" || !/^[a-z0-9]{3,24}$/.test(settings.ETALONOPS_STORAGE_ACCOUNT ?? "")) fail2("Existing app tenant, SQL server or storage settings did not match.");
    writeFileSync(statePath, JSON.stringify({ tenant: account2.tenantId, ownerId: owner.id, resourceGroup, appName, sqlName, storageName: settings.ETALONOPS_STORAGE_ACCOUNT }, null, 2), { mode: 384 });
    console.log("Verified the existing pilot and Cloud Shell owner. No Azure resource or permission changes.");
    return;
  }
  const state = JSON.parse(readFileSync(statePath, "utf8")), account = az(["account", "show"]);
  if (account.id !== "a428f249-9b2a-4314-8619-6b3fd33c805e" || normId(account.tenantId) !== normId(state.tenant)) fail2("Azure account changed; stopped.");
  const tokenResult = az(["account", "get-access-token", "--resource", "https://database.windows.net/"]);
  const claims = JSON.parse(Buffer.from(String(tokenResult.accessToken).split(".")[1], "base64url").toString());
  if (normId(claims.oid) !== normId(state.ownerId) || normId(claims.tid) !== normId(state.tenant)) fail2("SQL token identity changed; stopped.");
  const pool = new sql2.ConnectionPool({ server: state.sqlName + ".database.windows.net", database: "EtalonOps", authentication: { type: "azure-active-directory-access-token", options: { token: tokenResult.accessToken } }, options: { encrypt: true, trustServerCertificate: false }, connectionTimeout: 3e4, requestTimeout: 6e4, pool: { max: 5, min: 0, idleTimeoutMillis: 1e3 } });
  try {
    await pool.connect();
  } catch (e) {
    await pool.close();
    if (args.has("--probe")) {
      const match = String(e.message).match(/Client with IP address '([\d.]+)'/i);
      if (match) {
        console.log(match[1]);
        return;
      }
    }
    throw Error("Azure SQL connection failed. No catalog data was changed.");
  }
  if (args.has("--probe")) {
    console.log("already-allowed");
    await pool.close();
    return;
  }
  const store = new SqlStore(pool), p = { tenant: String(state.tenant), oid: normId(state.ownerId), roles: ["Admin"] };
  const report = { format: "etalonops-publication-run-v1", startedAt: (/* @__PURE__ */ new Date()).toISOString(), state: "validating", batches: [], images: { uploaded: 0, preserved: 0, alreadyApproved: 0, pending: 0 }, heldExcluded: 28 };
  const reportFile = join2(root, ".runtime", "result.json"), save2 = () => writeFileSync(reportFile, JSON.stringify(report, null, 2), { mode: 384 });
  try {
    const user = (await store.q("SELECT active,role_limit,entra_admin FROM application_users WHERE tenant=@p0 AND oid=@p1", p.tenant, p.oid)).recordset[0];
    if (!user?.active || !user.entra_admin || user.role_limit === "Foreman") fail2("Cloud Shell owner must already be an active Microsoft administrator in EtalonOps. Sign in to the app as that administrator; this script does not grant roles.");
    const bytes = readFileSync(join2(root, "materials.json")), expected = readFileSync(join2(root, "materials.sha256"), "utf8").trim();
    if (createHash14("sha256").update(bytes).digest("hex") !== expected) fail2("Material package checksum mismatch.");
    const data = packageSchema.parse(JSON.parse(bytes.toString()));
    if (createHash14("sha256").update(normId(p.tenant)).digest("hex") !== data.expectedTenantHash) fail2("Package belongs to another tenant.");
    report.packageHash = hash(data);
    const images = /* @__PURE__ */ new Map();
    for (const r of data.records) {
      if (!r.image || images.has(r.image.file)) continue;
      const file = join2(root, r.image.file), raw = readFileSync(file);
      if (createHash14("sha256").update(raw).digest("hex") !== r.image.sha256) fail2("Image checksum mismatch: " + r.image.file);
      images.set(r.image.file, await normalizeImage(raw));
    }
    console.log(`Checked ${data.records.length} ready material records and ${images.size} local image assets. The 28 held records are excluded.`);
    let snapshot = await store.catalogCommand(p, "export-snapshot", {});
    const backup = join2(root, ".runtime", "catalog-before-" + (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-") + ".json");
    writeFileSync(backup, JSON.stringify(snapshot, null, 2), { mode: 384 });
    report.backup = backup;
    const initial = reconcile(data.records, snapshot), checks = await validateChunks(store, p, initial.prepared, console.log);
    report.preview = checks.reduce((a, c) => {
      for (const [k, v] of Object.entries(c.preview.summary)) a[k] = (a[k] ?? 0) + Number(v);
      return a;
    }, {});
    report.images.expectedAssignments = data.records.filter((r) => r.image).length;
    const associations = snapshot.tables.image_associations ?? [];
    const expectedNewImages = data.records.filter((r, i) => {
      if (!r.image) return false;
      const existing = associations.filter((x) => normId(x.material_id) === initial.matches[i].existingId);
      return !existing.some((x) => x.status === "approved" || x.content_hash === images.get(r.image.file).hash);
    }).length;
    if (associations.length + expectedNewImages > imageLimits.maxAssociations) fail2("The existing 500-image-association limit would be exceeded. No material changes were applied.");
    report.state = "validated";
    save2();
    console.log("Preflight passed: " + JSON.stringify(report.preview));
    if (!args.has("--apply")) {
      console.log("Read-only preflight complete. Result: " + reportFile);
      return;
    }
    const credential = new AzureCliCredential();
    let container = new ContainerClient2(`https://${state.storageName}.blob.core.windows.net/catalog-images`, credential), assets = new BlobImageAssets(state.storageName, credential);
    let probe = container.getBlockBlobClient("publication-import-probe/" + randomUUID16());
    try {
      await probe.uploadData(Buffer.from("EtalonOps import readiness"), { conditions: { ifNoneMatch: "*" } });
      await probe.delete();
    } catch {
      try {
        const keys = az(["storage", "account", "keys", "list", "-g", state.resourceGroup, "-n", state.storageName]), key3 = keys.find((k) => k.permissions === "FULL")?.value ?? keys[0]?.value;
        if (!key3) throw Error();
        const shared = new StorageSharedKeyCredential(state.storageName, key3);
        container = new ContainerClient2(`https://${state.storageName}.blob.core.windows.net/catalog-images`, shared);
        probe = container.getBlockBlobClient("publication-import-probe/" + randomUUID16());
        await probe.uploadData(Buffer.from("EtalonOps import readiness"), { conditions: { ifNoneMatch: "*" } });
        await probe.delete();
        assets = { put: async (key4, bytes2) => {
          const blob = container.getBlockBlobClient(key4);
          try {
            await blob.uploadData(bytes2, { conditions: { ifNoneMatch: "*" }, blobHTTPHeaders: { blobContentType: "image/webp" }, metadata: { sha256: createHash14("sha256").update(bytes2).digest("hex") } });
          } catch (e) {
            if (![409, 412].includes(e.statusCode)) throw e;
            if (!Buffer.from(await blob.downloadToBuffer()).equals(bytes2)) throw Error("Existing stored image checksum mismatch.");
          }
        }, get: async (key4) => container.getBlockBlobClient(key4).downloadToBuffer() };
      } catch {
        fail2("Existing storage write access unavailable. No roles were granted and no material changes were applied.");
      }
    }
    report.state = "applying materials";
    save2();
    for (let i = 0; i < data.records.length; i += 50) {
      snapshot = await store.catalogCommand(p, "export-snapshot", {});
      const current = reconcile(data.records, snapshot), rows = current.prepared.slice(i, i + 50), name4 = "R2-ready-" + String(i / 50 + 1).padStart(2, "0") + ".xlsx";
      const applied = await applyChunk(store, p, rows, name4, args.has("--approve-images"));
      report.batches.push({ first: i + 1, last: Math.min(i + 50, data.records.length), ...applied });
      save2();
      console.log(`Saved materials ${i + 1}\u2013${Math.min(i + 50, data.records.length)} / ${data.records.length}`);
    }
    snapshot = await store.catalogCommand(p, "export-snapshot", {});
    const matched = reconcile(data.records, snapshot);
    report.state = "attaching images";
    save2();
    report.images = { ...report.images, ...await attachReviewedImages(store, p, data.records, matched.matches, images, assets, args.has("--approve-images"), (stats) => {
      report.images = { ...report.images, ...stats };
      if ((stats.uploaded + stats.pending) % 25 === 0) {
        save2();
        console.log("Attached " + (stats.uploaded + stats.pending) + " local image assignments.");
      }
    }) };
    snapshot = await store.catalogCommand(p, "export-snapshot", {});
    report.activeMaterials = snapshot.tables.materials.filter((m) => m.active).length;
    report.catalogRowsVerified = reconcile(data.records, snapshot).matches.filter((m) => m.existingId).length;
    if (report.catalogRowsVerified !== data.records.length) fail2("Final material verification incomplete.");
    report.state = "complete";
    report.finishedAt = (/* @__PURE__ */ new Date()).toISOString();
    save2();
    console.log(`COMPLETE: ${report.catalogRowsVerified} ready materials present; ${report.activeMaterials} total active materials. Local images: ${report.images.uploaded} approved, ${report.images.alreadyApproved} already approved, ${report.images.preserved} existing images preserved. Report: ${reportFile}`);
  } catch (e) {
    report.state = "stopped";
    report.error = e instanceof Error ? e.message : "Import stopped.";
    save2();
    console.error("STOPPED: " + report.error + " Completed batches are retained. Rerun the same command to revalidate and resume; do not delete the report or existing data.");
    process.exitCode = 1;
  } finally {
    await pool.close();
  }
}
main().catch((e) => {
  console.error(e instanceof Error ? e.message : "Import stopped.");
  process.exitCode = 1;
});
