EtalonOps R2 catalog import

Run bash run-import.sh --apply --approve-images in Azure Cloud Shell under the existing Azure SQL administrator account. The helper installs the compatible v45 app update when necessary, backs up the live catalog privately, checks all records, then publishes ready materials and reviewed photos.

Rehearsal against the supplied snapshot: 825 additions, 42 metadata updates, 872 total active materials; all 89 manufacturer products and original material IDs preserved. 28 held records excluded. 311 local-image assignments use 80 bundled assets. 485 ready materials have supplied photo references; 382 reference materials still lack photos.

Wait for COMPLETE. A rerun is supported and checks for existing records. Completed batches remain if interrupted; rerun the same command to continue. Reports and backup are in .runtime and must remain private. No AI or Bing requests are made.

Storage access uses OAuth, with a temporary container-scoped Storage Blob Data Contributor assignment when needed. It is removed on normal exit. No storage keys or public image access are enabled.
