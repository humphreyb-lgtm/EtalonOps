import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: { rollupOptions: { input: { main: 'index.html', callback: 'auth-callback.html' } } },
  server: { port: 5173, strictPort: true, proxy: { '/api': `http://127.0.0.1:${process.env.ETALONOPS_API_PORT ?? '3001'}` } },
  preview: { port: 4173, strictPort: true },
});
