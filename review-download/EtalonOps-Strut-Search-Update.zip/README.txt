EtalonOps v49.2 search coverage update
Run start-import.sh in the existing owner Azure Bash Cloud Shell.
Requires the original 297 strut materials to be installed. Resolves their live Material Keys.
Appends reviewed phrases only; preserves catalog metadata, images and existing translations.
Installer updates only recognized older app versions; it refuses unknown newer releases.
Temporary container OAuth access and an exact-source-IP SQL rule, if needed, are removed on exit.
The existing container lease prevents overlap with the original import. Backups and progress reports are private.
No AI/Bing calls. Rerun safely after interruption.
See REVIEW.json for withheld phrases and acceptance corrections.
