import type { Store } from './store';
type AsyncCompatible<T> = { [K in keyof T]: T[K] extends (...args: infer A) => infer R ? (...args: A) => R | Promise<R> : T[K] };
export type Repository = AsyncCompatible<Pick<Store, 'admit' | 'users' | 'catalogCommand' | 'engine' | 'health' | 'member' | 'requireAdmin' | 'audit' | 'search' | 'listDrafts' | 'getProjectDraft' | 'getDraft' | 'saveDraft' | 'previewImport' | 'applyImport' | 'rollbackImport' | 'exportCsv' | 'listImports' | 'imageMaterial' | 'listImages' | 'approvedImage' | 'submitImage' | 'reviewImage' | 'reserveAI' | 'aiUsage'>>;
