EtalonOps — approved strut import
297 materials, 94 unique representative image assets, 297 approved image assignments.
One deferred scope record excluded.

start-import.sh starts/resumes the job in the background in Azure Bash Cloud Shell.
status.sh prints its status and the most recent log lines.

The job checks the existing Azure Standard subscription, tenant, SQL administrator
and application membership. It upgrades recognized earlier pilot releases to the
bundled CMS v49.1 maintenance release, preserving CMS content. The maintenance
release raises image capacity and fixes generic angle-value publication typing.

Before writing materials it validates all rows against the current live catalog,
backs up the catalog locally, checks image-storage OAuth access and obtains an
expiring catalog-import lease. It publishes batches of 50 using the application
workflow, preserving matched keys and existing approved images. Local image bytes
are normalized and verified before approval. Progress is saved after each batch
and every ten new image attachments, locally and privately in Azure Blob Storage.

It may temporarily grant the existing owner OAuth upload access only to the
existing catalog-images container, and add a temporary exact-IP SQL firewall
rule if necessary. These additions are removed on normal exit. Existing roles
and rules are preserved. No resource/SKU provisioning, storage keys, Azure AI or
Bing calls are used. Access credentials and the catalog snapshot are not packaged.

A browser disconnect does not intentionally stop the nohup process. A recycled
Cloud Shell machine can still interrupt it. Rerun the installer to revalidate and
resume; do not delete existing catalog data or progress files.

With the supplied 872-material baseline and no concurrent changes, completion
should report 297 verified imported materials, 1,169 total active materials and
297 approved image assignments. Actual live totals can differ if other materials
were added while this job was prepared. Specifications remain provisional for
later administrator review; representative images were approved by the owner.
