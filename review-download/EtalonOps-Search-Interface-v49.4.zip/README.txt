EtalonOps v49.4 search interface update
Run start-import.sh in the existing owner Azure Bash Cloud Shell.
Application-only: no catalog/translation import and no temporary image-storage role.
Existing CMS content, catalog specifications, translations and images are retained.
Status: bash status.sh. Rerun safely after an interrupted session.
